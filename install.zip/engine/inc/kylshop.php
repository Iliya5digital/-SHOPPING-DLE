<?php
if (!defined('DATALIFEENGINE') OR !defined('LOGGED_IN')) {
    header("HTTP/1.1 403 Forbidden");
    header('Location: ../../');
    die("Hacking attempt!");
}

if ($member_id['user_group'] != 1) msg("error", $lang['index_denied'], $lang['index_denied']);


include_once (DLEPlugins::Check(ENGINE_DIR . '/modules/kylshop/init.php'));
if(!empty($_GET["act"]) && $_GET["act"] == "get_gm") include_once (DLEPlugins::Check(ENGINE_DIR . '/inc/kylshop/get_gm.php'));
if(!empty($_FILES["file"]["name"]) || !empty($_POST["delete_img"]) && $_GET["act"] == "upload_files") include_once (DLEPlugins::Check(ENGINE_DIR . '/inc/kylshop/upload_files.php'));

if($_SERVER["REQUEST_METHOD"] == "POST") // подключаем обработчик
    include_once (DLEPlugins::Check(ENGINE_DIR . '/inc/kylshop/action.php'));



if(!isset($_GET["print"]) && !isset($_POST["search"])){

	echoheader("<link href=\"engine/skins/kylshop/kylshop.css\" rel=\"stylesheet\" type=\"text/css\">
<script src=\"engine/skins/kylshop/kylshop.js\"></script>
<i class=\"fa fa-shopping-basket position-left\"></i><span class=\"text-semibold\">Kylshop (магазин)</span>", "Простой и удобный в управлении модуль интернет магазина");

	echo '<div class="panel panel-default flex">

    <!-- SIDEBAR -->
    <div class="ks_sidebar">
        <ul>
            <li><a href="?mod=kylshop"><i class="fa fa-shopping-basket" aria-hidden="true"></i> Список заказов</a></li>
            <li><a href="?mod=kylshop&act=promocode" style="color:#3ab509"><i class="fa fa-magic" aria-hidden="true"></i> <b>Промо-коды</b></a></li>
            <li><a href="?mod=kylshop&act=filter"><i class="fa fa-filter" aria-hidden="true"></i> Фильтр</a></li>
            <li><a href="?mod=kylshop&act=delivery"><i class="fa fa-map" aria-hidden="true"></i> Доставка</a></li>
            <li><a href="?mod=kylshop&act=settings" style="color:#06b1e4"><i class="fa fa-wrench" aria-hidden="true"></i> Настройки</a></li>
            <li><a href="?mod=kylshop&act=payments"><i class="fa fa-credit-card-alt" aria-hidden="true"></i> Платежные системы</a></li>
            <li><a href="?mod=kylshop&act=email"><i class="fa fa-envelope" aria-hidden="true"></i> Шаблоны писем</a></li>
            <li><a href="?mod=kylshop&act=statistics"><i class="fa fa-bar-chart" aria-hidden="true"></i> Статистика</a></li>
            <li><a href="?mod=kylshop&act=applications"><i class="fa fa-puzzle-piece" aria-hidden="true"></i> Расширения</a></li>
            <li><a href="?mod=kylshop&act=info" style="color:#a0a0a0"><i class="fa fa-info" aria-hidden="true"></i> О модуле</a></li>
        </ul>
    </div>
    
    <!-- CONTENT -->
    <div id="ks_content">
        ';

}

$act = trim(htmlspecialchars(strip_tags(addslashes($_GET["act"]))));

if(file_exists(ENGINE_DIR . '/inc/kylshop/'.$act.'.php')) include_once (DLEPlugins::Check(ENGINE_DIR . '/inc/kylshop/'.$act.'.php'));
else include_once (DLEPlugins::Check(ENGINE_DIR . '/inc/kylshop/index.php'));


if(!isset($_GET["print"]) && !isset($_POST["search"])){

	echo '</div>
    
</div>';


	echofooter();
}