<?php
/**
 * @name главный файл расширений
 */
if (!defined('DATALIFEENGINE') OR !defined('LOGGED_IN')) {
    header("HTTP/1.1 403 Forbidden");
    header('Location: ../../');
    die("Hacking attempt!");
}

if ($member_id['user_group'] != 1) msg("error", $lang['index_denied'], $lang['index_denied']);


// конкретное расширение
if(!empty($_GET["app"])){

    $app_name = trim(htmlspecialchars(strip_tags(addslashes($_GET["app"]))));

    // получаем конфиг приложения
    if(file_exists(ENGINE_DIR . '/inc/kylshop/applications/' . $app_name . '/config.json')) {

        $config_app = json_decode(file_get_contents(ENGINE_DIR . '/inc/kylshop/applications/' . $app_name . '/config.json'));

        if(file_exists(ENGINE_DIR . '/inc/kylshop/applications/' . $app_name . '/index.php')){

            $app_title = '<img src="engine/skins/kylshop/applications/' . $app_name . '/' . $config_app->app_logo . '" alt="" height="30" class="app_logo"> <span class="app_title">'.$config_app->app_name.'<br><i>'.$config_app->app_description.'</i></span>';
            include_once (DLEPlugins::Check(ENGINE_DIR . '/inc/kylshop/applications/' . $app_name . '/index.php'));

            // подключаем стили
            if(!empty($config_app->styles)){
                foreach ($config_app->styles as $style) {
                    echo '<link href="engine/skins/kylshop/applications/'.$app_name.'/'.$style.'.css" rel="stylesheet" type="text/css">'.PHP_EOL;
                }
            }
            // подключаем скрипты
            if(!empty($config_app->scripts)){
                foreach ($config_app->scripts as $script) {
                    echo '<script src="engine/skins/kylshop/applications/'.$app_name.'/'.$script.'.js"></script>'.PHP_EOL;
                }
            }
        }

    }


// страница всех расширений
} else{

    echo '<div class="panel panel-default">
        <div class="panel-heading">
            <i class="fa fa-puzzle-piece" aria-hidden="true"></i> Расширения
            <div class="heading-elements">
                <ul class="icons-list">
                    <li><a href="https://kylaksizov.ru/kylshop/" target="_blank"><i class="fa fa-search"></i>Найти</a> </li>
                    <li><a href="#" class="c_grey"><i class="fa fa-download"></i>Загрузить</a></li>
                </ul>
            </div>
        </div>
        
        <div class="apps_flex">';

        foreach (scandir(ENGINE_DIR . '/inc/kylshop/applications') as $file) {
            $config_app = "";
            if($file != "." && $file != ".."){
                if(file_exists(ENGINE_DIR . '/inc/kylshop/applications/' . $file . '/config.json')){
                    $config_app = json_decode(file_get_contents(ENGINE_DIR . '/inc/kylshop/applications/' . $file . '/config.json'));

                    echo '<a href="?mod=kylshop&act=applications&app='.$file.'" class="app">
                        <img src="engine/skins/kylshop/applications/' . $file . '/' . $config_app->app_logo . '" alt="">
                        <span>'.$config_app->app_name.'</span><br>
                        <i>'.$config_app->version.'</i>
                    </a>';
                }
            }
        }

        echo '</div>
    </div>';
}