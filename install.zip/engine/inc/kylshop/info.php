<?php
/**
 * @name информация о модуле
 */
if (!defined('DATALIFEENGINE') OR !defined('LOGGED_IN')) {
    header("HTTP/1.1 403 Forbidden");
    header('Location: ../../');
    die("Hacking attempt!");
}

if ($member_id['user_group'] != 1) msg("error", $lang['index_denied'], $lang['index_denied']);

echo '<div class="panel-heading">
    <i class="fa fa-info" aria-hidden="true"></i> <b>Информация о модуле</b>
</div>

<div class="panel-body">
    <ul class="list">
        <li><span>Версия модуля</span> '.$ks_config["version"].'</li>
        <li><span>Автор:</span> Владимир Кулаксизов</li>
        <li><span>Сайт:</span> <a href="https://kylaksizov.ru/" target="_blank">kylaksizov.ru</a></li>
    </ul>
</div>';