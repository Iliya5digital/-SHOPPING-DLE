<?php
/**
 * @name настройки
 */
if (!defined('DATALIFEENGINE') OR !defined('LOGGED_IN')) {
    header("HTTP/1.1 403 Forbidden");
    header('Location: ../../');
    die("Hacking attempt!");
}

function is_checked($data){
    return $data ? " checked" : "";
}

if ($member_id['user_group'] != 1) msg("error", $lang['index_denied'], $lang['index_denied']);



/**
 * @name METHOD
 */
if(file_exists(ENGINE_DIR . "/modules/kylshop/method.json")){

	$method_data = json_decode(file_get_contents(ENGINE_DIR . "/modules/kylshop/method.json"), true);

	$method_result = '';
	foreach ( $method_data["method_name"] as $key => $method_datum ) {

		$method_result .= '<div class="row">
	        <div class="col-lg-4 col-md-6">
	            <label>Наименование</label>
	            <input type="text" name="method_name[]" class="form-control" value="'.$method_datum.'" autocomplete="off">
	        </div>
	        <div class="col-lg-4 col-md-6">
	            <label>Цена метода</label>
	            <input type="text" name="method_price[]" class="form-control" value="'.$method_data["method_price"][$key].'" autocomplete="off">
	        </div>
	        <div class="col-lg-4 col-md-6">
	            <label>Максимальная цена</label>
	            <i class="help-button visible-lg-inline-block text-primary-600 fa fa-question-circle position-right" data-rel="popover" data-trigger="hover" data-placement="right" data-content="Если общая сумма в корзине превышает указанную, цена за метод прибаляться не будет." data-original-title="" title=""></i>
	            <input type="text" name="method_max_price[]" class="form-control" value="'.$method_data["method_max_price"][$key].'" autocomplete="off">
	        </div>
	        <a href="#" class="fa fa-times delete_order del_method"></a>
	    </div>';
	}



} else{

	$method_result = '<div class="row">
        <div class="col-lg-4 col-md-6">
            <label>Наименование</label>
            <input type="text" name="method_name[]" class="form-control" value="" autocomplete="off">
        </div>
        <div class="col-lg-4 col-md-6">
            <label>Цена метода</label>
            <input type="text" name="method_price[]" class="form-control" value="" autocomplete="off">
        </div>
        <div class="col-lg-4 col-md-6">
            <label>Максимальная цена</label>
            <i class="help-button visible-lg-inline-block text-primary-600 fa fa-question-circle position-right" data-rel="popover" data-trigger="hover" data-placement="right" data-content="Если общая сумма в корзине превышает указанную, цена за метод прибаляться не будет." data-original-title="" title=""></i>
            <input type="text" name="method_max_price[]" class="form-control" value="" autocomplete="off">
        </div>
        <a href="#" class="fa fa-times delete_order del_method"></a>
    </div>';
}


/**
 * @name STATUSES
 */
if(file_exists(ENGINE_DIR . "/modules/kylshop/statuses.txt") && filesize(ENGINE_DIR . "/modules/kylshop/statuses.txt") != 0){

	$statuses_data = unserialize(file_get_contents(ENGINE_DIR . "/modules/kylshop/statuses.txt"));

	$statuses_result = '';
	foreach ( $statuses_data['status']['name'] as $key => $statuses_name ) {

        $statuses_result .= '<div class="row">
            <div class="col-lg-2 col-md-2">
                <label>Название</label>
                <input type="text" name="status[name][]" value="'.$statuses_name.'" class="form-control" autocomplete="off">
            </div>
            <div class="col-lg-9 col-md-9">
                <label>Шаблон email уведомления</label>
                <textarea name="status[email][]" class="form-control" rows="5">'.$statuses_data['status']['email'][$key].'</textarea>
            </div>
            <div class="col-lg-1 col-md-1">
                <a href="#" class="fa fa-times delete_order del_status"></a>
            </div>
        </div>';
	}

} else{

    $statuses_result .= '<div class="row">
        <div class="col-lg-2 col-md-2">
            <label>Название</label>
            <input type="text" name="status[name][]" class="form-control" autocomplete="off">
        </div>
        <div class="col-lg-9 col-md-9">
            <label>Шаблон email уведомления</label>
            <textarea name="status[email][]" class="form-control" rows="5"></textarea>
        </div>
        <div class="col-lg-1 col-md-1">
            <a href="#" class="fa fa-times delete_order del_status"></a>
        </div>
    </div>';
}


/**
 * @name ADDON
 */
if(file_exists(ENGINE_DIR . "/modules/kylshop/addon.json")){

	$addon_data = json_decode(file_get_contents(ENGINE_DIR . "/modules/kylshop/addon.json"), true);

	$addon_result = '';
	foreach ( $addon_data["addon_name"] as $key => $addon_datum ) {

		$addon_result .= '<div class="row">
	        <div class="col-lg-4 col-md-6">
	            <label>Наименование</label>
	            <input type="text" name="addon_name[]" class="form-control" value="'.$addon_datum.'" autocomplete="off">
	        </div>
	        <div class="col-lg-3 col-md-5">
	            <label>Цена товара</label>
	            <input type="text" name="addon_price[]" class="form-control" value="'.$addon_data["addon_price"][$key].'" autocomplete="off">
	        </div>
	        <div class="col-lg-5 col-md-7">
	            <label>Ссылка на изображение</label>
	            <input type="text" name="addon_image[]" class="form-control" value="'.$addon_data["addon_image"][$key].'" autocomplete="off">
	        </div>
	        <a href="#" class="fa fa-times delete_order del_addon"></a>
	    </div>';
	}



} else{

	$addon_result = '<div class="row">
        <div class="col-lg-4 col-md-6">
            <label>Наименование</label>
            <input type="text" name="addon_name[]" class="form-control" value="" autocomplete="off">
        </div>
        <div class="col-lg-3 col-md-5">
            <label>Цена товара</label>
            <input type="text" name="addon_price[]" class="form-control" value="" autocomplete="off">
        </div>
        <div class="col-lg-5 col-md-7">
            <label>Ссылка на изображение</label>
            <input type="text" name="addon_image[]" class="form-control" value="" autocomplete="off">
        </div>
        <a href="#" class="fa fa-times delete_order del_addon"></a>
    </div>';
}


/**
 * @name SALE
 */
if(file_exists(ENGINE_DIR . "/modules/kylshop/sale.json")){

	$sale_data = json_decode(file_get_contents(ENGINE_DIR . "/modules/kylshop/sale.json"), true);

	$sale_result = '';
	foreach ( $sale_data["sale_price"] as $key => $sale_datum ) {

		$sale_result .= '<div class="row">
            <div class="col-lg-4 col-md-6">
                <label>Если сумма заказа больше чем:</label>
                <input type="text" name="sale_price[]" class="form-control" value="'.$sale_datum.'" placeholder="только цифры" autocomplete="off">
            </div>
            <div class="col-lg-3 col-md-5">
                <label>отнимать N % от общей суммы</label>
                <input type="text" name="sale_percent[]" class="form-control" value="'.$sale_data["sale_percent"][$key].'" placeholder="только цифры" autocomplete="off">
            </div>
	        <a href="#" class="fa fa-times delete_order del_sale"></a>
	    </div>';
	}



} else{

	$sale_result = '<div class="row">
        <div class="col-lg-4 col-md-6">
            <label>Если сумма заказа больше чем:</label>
            <input type="text" name="sale_price[]" class="form-control" value="" placeholder="только цифры" autocomplete="off">
        </div>
        <div class="col-lg-3 col-md-5">
            <label>отнимать N % от общей суммы</label>
            <input type="text" name="sale_percent[]" class="form-control" value="" placeholder="только цифры" autocomplete="off">
        </div>
        <a href="#" class="fa fa-times delete_order del_sale"></a>
    </div>';
}




$fields = "";

// группы пользователей
$groups_sourse = $db->super_query( "SELECT id, group_name FROM " . PREFIX . "_usergroups WHERE id != 5", true );
$groups = '';
$groups_s = explode(",", $ks_config["allow_add_group"]);

foreach ($groups_sourse as $item) {
    if(array_search($item["id"], $groups_s) !== false)
        $groups .= '<option value="'.$item["id"].'" selected>'.$item["group_name"].'</option>';
    else
        $groups .= '<option value="'.$item["id"].'">'.$item["group_name"].'</option>';
}

// перебор созданных полей
if(file_exists(ENGINE_DIR . "/modules/kylshop/fields.json")){

    $fields_source = json_decode(file_get_contents(ENGINE_DIR . "/modules/kylshop/fields.json"), true);

    foreach ($fields_source as $key => $item) {

        $required = $post = $power = '';
        if(!empty($item["required"])) $required = ' checked';
        if(!empty($item["post"])) $post = ' checked';
        if(!empty($item["power"])) $power = ' checked';

        switch ($item["type"]){

            case "input":
            case "textarea":

                $type = 'Одна строка';
                if($item["type"] == "textarea") $type = 'Несколько строк';

                $fields .= '<div class="row">
                    <p class="title_field">'.$type.' <span class="code_field">{_'.$key.'}</span></p>
                    <input type="hidden" name="'.$key.'[type]" value="'.$item["type"].'">
                    <div class="col-md-3"><input type="text" name="'.$key.'[title]" value="'.$item["title"].'" class="form-control" placeholder="Название поля"></div>
                    <div class="col-md-3"><input type="text" name="'.$key.'[attr]" value=\''.str_replace("'", "*", $item["attr"]).'\' class="form-control" placeholder="Атрибуты"></div>
                    <div class="col-md-3"><input type="text" name="'.$key.'[admin]" value="'.$item["admin"].'" class="form-control" placeholder="Название для админа"></div>
                    <div class="col-md-2">
                        <label><input type="checkbox" name="'.$key.'[required]"'.$required.'> Обязательное</label><br>
                        <label><input type="checkbox" name="'.$key.'[post]"'.$post.'> Отправлять на почту</label>
                    </div>
                    <div class="col-md-1">
                        <a href="#" class="fa fa-close delete_field"></a>
                        <div class="arrows">
                            <a href="#" class="fa fa-angle-up up"></a>
                            <a href="#" class="fa fa-angle-down down"></a>
                        </div>
                    </div>
                </div>';
                break;

            case "select":

                $fields .= '<div class="row">
                    <p class="title_field">Список <span class="code_field">{_'.$key.'}</span></p>
                    <input type="hidden" name="'.$key.'[type]" value="select">
                    <div class="col-md-3"><input type="text" name="'.$key.'[title]" value="'.$item["title"].'" class="form-control" placeholder="Название поля"></div>
                    <div class="col-md-2"><input type="text" name="'.$key.'[attr]" value=\''.$item["attr"].'\' class="form-control" placeholder="Атрибуты"></div>
                    <div class="col-md-3"><input type="text" name="'.$key.'[admin]" value="'.$item["admin"].'" class="form-control" placeholder="Название для админа"></div>
                    <div class="col-md-2">
                        <textarea name="'.$key.'[values]" class="form-control" rows="4" placeholder="Каждое новое значение с новой строки. Поставьте в этой строке звездочку *, если нужно сделать его выбранным по умолчанию.">'.$item["values"].'</textarea>
                    </div>
                    <div class="col-md-1">
                        <label><input type="checkbox" name="'.$key.'[required]"'.$required.'> Обязательное</label><br>
                        <label><input type="checkbox" name="'.$key.'[post]"'.$post.'> Отправлять на почту</label>
                    </div>
                    <div class="col-md-1">
                        <a href="#" class="fa fa-close delete_field"></a>
                        <div class="arrows">
                            <a href="#" class="fa fa-angle-up up"></a>
                            <a href="#" class="fa fa-angle-down down"></a>
                        </div>
                    </div>
                </div>';
                break;

            case "checkbox":

                $fields .= '<div class="row">
                    <p class="title_field">Переключатель \'Да\' или \'Нет\' <span class="code_field">{_'.$key.'}</span></p>
                    <input type="hidden" name="'.$key.'[type]" value="checkbox">
                    <div class="col-md-3"><input type="text" name="'.$key.'[title]" value="'.$item["title"].'" class="form-control" placeholder="Название поля"></div>
                    <div class="col-md-3"><input type="text" name="'.$key.'[attr]" value=\''.$item["attr"].'\' class="form-control" placeholder="Атрибуты"></div>
                    <div class="col-md-3"><input type="text" name="'.$key.'[admin]" value="'.$item["admin"].'" class="form-control" placeholder="Название для админа"></div>
                    <div class="col-md-2">
                        <label><input type="checkbox" name="'.$key.'[required]"'.$required.'> Обязательное</label><br>
                        <label><input type="checkbox" name="'.$key.'[post]"'.$post.'> Отправлять на почту</label><br>
                        <label><input type="checkbox" name="'.$key.'[power]"'.$power.'> Включено</label>
                    </div>
                    <div class="col-md-1">
                        <a href="#" class="fa fa-close delete_field"></a>
                        <div class="arrows">
                            <a href="#" class="fa fa-angle-up up"></a>
                            <a href="#" class="fa fa-angle-down down"></a>
                        </div>
                    </div>
                </div>';
                break;

            case "file":

                $fields .= '<div class="row">
                    <p class="title_field">Файл <span class="code_field">{_'.$key.'}</span></p>
                    <input type="hidden" name="'.$key.'[type]" value="file">
                    <div class="col-md-3"><input type="text" name="'.$key.'[title]" value="'.$item["title"].'" class="form-control" placeholder="Название поля"></div>
                    <div class="col-md-6"><input type="text" name="'.$key.'[extension]" value="'.$item["extension"].'" class="form-control" placeholder="Расширения файлов через запятую"></div>
                    <div class="col-md-2">
                        <label><input type="checkbox" name="'.$key.'[required]"'.$required.'> Обязательное</label>
                    </div>
                    <div class="col-md-1">
                        <a href="#" class="fa fa-close delete_field"></a>
                        <div class="arrows">
                            <a href="#" class="fa fa-angle-up up"></a>
                            <a href="#" class="fa fa-angle-down down"></a>
                        </div>
                    </div>
                </div>';
                break;
        }
    }
}

$categories_list = CategoryNewsSelection( 0, 0 );


/**
 * @name настройки
 */
echo '<div class="panel-heading">
    <ul class="nav nav-tabs nav-tabs-solid">
        <li class="active"><a href="#main" data-toggle="tab"><i class="fa fa-home position-left"></i> Общие</a></li>
        <li><a href="#statuses" data-toggle="tab"><i class="fa fa-battery-quarter position-left"></i> Статусы</a></li>
        <li><a href="#functions" data-toggle="tab"><i class="fa fa-cog" aria-hidden="true"></i> Функции</a></li>
        <li><a href="#show" data-toggle="tab"><i class="fa fa-eye position-left"></i> Вид</a></li>
        <li><a href="#form" data-toggle="tab"><i class="fa fa-server position-left"></i> Форма оплаты</a></li>
        <li><a href="#method" data-toggle="tab"><i class="fa fa-snowflake-o" aria-hidden="true"></i> Методы</a></li>
        <li><a href="#addon" data-toggle="tab"><i class="fa fa-coffee" aria-hidden="true"></i> Дополнительные товары</a></li>
        <li><a href="#sale" data-toggle="tab"><i class="fa fa-random" aria-hidden="true"></i> Скидка</a></li>
    </ul>
    <div class="heading-elements">
        <ul class="icons-list">
            <li><a href="#" class="panel-fullscreen"><i class="fa fa-expand"></i></a></li>
        </ul>
    </div>
</div>

<div class="form-horizontal">
    <div class="panel-tab-content tab-content">
    
        <!-- Общие -->
        <div class="tab-pane active" id="main">
            <form action="?mod=kylshop&act=settings&config=main" method="POST">
                <table class="table table-striped">
                    <tr>
                        <td class="col-xs-6 col-sm-6 col-md-7"><h6 class="media-heading text-semibold">Включить оплату на сайте:</h6><span class="text-muted text-size-small hidden-xs">Если включено, то при оформлении заказа, пользователю будет предложено перейти к оплате выбранных товаров.</span></td>
                        <td class="col-xs-6 col-sm-6 col-md-5"><input class="switch" type="checkbox" name="config[payments_power]" value="1" data-switchery="true"'.is_checked($ks_config["payments_power"]).'></td>
                    </tr>
                    <tr>
                        <td class="col-xs-6 col-sm-6 col-md-7"><h6 class="media-heading text-semibold">Разрешить покупки гостям:</h6><span class="text-muted text-size-small hidden-xs">Если включено, то гости смогут покупать товары на сайте. <b>В данной версии эта функция работает не до конца. После оплаты пользователь ничего не увидет на сайте, никаких уведомлений.</b></span></td>
                        <td class="col-xs-6 col-sm-6 col-md-5"><input class="switch" type="checkbox" name="config[payment_guest]" value="1" data-switchery="true"'.is_checked($ks_config["payment_guest"]).'></td>
                    </tr>
                    <tr>
                        <td class="col-xs-6 col-sm-6 col-md-7"><h6 class="media-heading text-semibold">Разрешить оплату с баланса:</h6><span class="text-muted text-size-small hidden-xs">Если включено, то гости смогут покупать товары на сайте. <b>В данной версии эта функция работает не до конца. После оплаты пользователь ничего не увидет на сайте, никаких уведомлений.</b></span></td>
                        <td class="col-xs-6 col-sm-6 col-md-5"><input class="switch" type="checkbox" name="config[payments_balance]" value="1" data-switchery="true"'.is_checked($ks_config["payments_balance"]).'></td>
                    </tr>
                    <tr>
                        <td class="col-xs-6 col-sm-6 col-md-7"><h6 class="media-heading text-semibold">Время видимости товара/скрытого содержимого гостям после оплаты:</h6><span class="text-muted text-size-small hidden-xs">Укажите время в секундах, на протяжении которого гость сможет увидеть купленный товар. Дапускается умножение, например: <b>60*24</b></span></td>
                        <td class="col-xs-6 col-sm-6 col-md-5"><input type="text" class="form-control" name="config[order_guest_timer]" value="'.$ks_config["order_guest_timer"].'"></td>
                    </tr>
                    <tr>
                        <td class="col-xs-6 col-sm-6 col-md-7"><h6 class="media-heading text-semibold">Текст после заказа:</h6><span class="text-muted text-size-small hidden-xs">Этот текст будет выведен после формления заказа пользователем и если выключен прием платежей (настройка выше).<br>Доступные теги: <b>{id}</b> - ID заказа. <b>{order}</b> - код заказа.</span></td>
                        <td class="col-xs-6 col-sm-6 col-md-5"><textarea class="form-control" name="config[order_text]" rows="3">'.$ks_config["order_text"].'</textarea></td>
                    </tr>
                    <tr>
                        <td class="col-xs-6 col-sm-6 col-md-7"><h6 class="media-heading text-semibold">Редирект после заказа:</h6><span class="text-muted text-size-small hidden-xs">Укажите ссылку, куда будет перенаправлен пользователь после оформления заказа. <b>Работает только при выключеной опции (Включить оплату на сайте).</b></span></td>
                        <td class="col-xs-6 col-sm-6 col-md-5"><input type="text" class="form-control" name="config[order_redirect]" value="'.$ks_config["order_redirect"].'"></td>
                    </tr>
                    <tr>
                        <td class="col-xs-6 col-sm-6 col-md-7"><h6 class="media-heading text-semibold">Уведомления:</h6><span class="text-muted text-size-small hidden-xs">Если включено, в админ-панели на любой странице будет выводится уведомление при поступлении нового заказа.</span></td>
                        <td class="col-xs-6 col-sm-6 col-md-5"><input class="switch" type="checkbox" name="config[notification]" value="1" data-switchery="true"'.is_checked($ks_config["notification"]).'></td>
                    </tr>
                    <tr>
                        <td class="col-xs-6 col-sm-6 col-md-7"><h6 class="media-heading text-semibold">Дополнительные методы:</h6><span class="text-muted text-size-small hidden-xs">Если включено, то на странице офрмления заказа появится поле с выором методов, которые меняют цену в зависимости от выбора. При этом в шаблоне cart.tpl должен стоять тег <b>{method}</b>.</span></td>
                        <td class="col-xs-6 col-sm-6 col-md-5"><input class="switch" type="checkbox" name="config[method]" value="1" data-switchery="true"'.is_checked($ks_config["method"]).'></td>
                    </tr>
                    <tr>
                        <td class="col-xs-6 col-sm-6 col-md-7"><h6 class="media-heading text-semibold">Название метода:</h6><span class="text-muted text-size-small hidden-xs">Укажите название метода в таком формате: <b>способ доставки|за доставку</b></span></td>
                        <td class="col-xs-6 col-sm-6 col-md-5"><input type="text" class="form-control" name="config[method_title]" value="'.$ks_config["method_title"].'"></td>
                    </tr>
                    <tr>
                        <td class="col-xs-6 col-sm-6 col-md-7"><h6 class="media-heading text-semibold">Модерация:</h6><span class="text-muted text-size-small hidden-xs">Если включено, то после оплаты клиент будет видеть уведомление, которые вы укажете в настройке ниже,<br>а сам товар, только после вашей проверки.</span></td>
                        <td class="col-xs-6 col-sm-6 col-md-5"><input class="switch" type="checkbox" name="config[moderation]" value="1" data-switchery="true"'.is_checked($ks_config["moderation"]).'></td>
                    </tr>
                    <tr>
                        <td class="col-xs-6 col-sm-6 col-md-7"><h6 class="media-heading text-semibold">Текст при модерации:</h6><span class="text-muted text-size-small hidden-xs">Данное сообщение будет выведено после оплаты заказа. При этом настройка выше должна быть включена.<br>В противном случае будет показано содержимое поля <b>показывать после покупки</b> при редактировании новости.</span></td>
                        <td class="col-xs-6 col-sm-6 col-md-5"><textarea class="form-control" name="config[moderation_text]" rows="3">'.$ks_config["moderation_text"].'</textarea></td>
                    </tr>
                    <tr>
                        <td class="col-xs-6 col-sm-6 col-md-7"><h6 class="media-heading text-semibold">Знак валюты:</h6><span class="text-muted text-size-small hidden-xs">например: "$ или ₽"</span></td>
                        <td class="col-xs-6 col-sm-6 col-md-5"><input type="text" class="form-control" name="config[currency]" value="'.$ks_config["currency"].'"></td>
                    </tr>
                    <tr>
                        <td class="col-xs-6 col-sm-6 col-md-7"><h6 class="media-heading text-semibold">Единица измерения:</h6><span class="text-muted text-size-small hidden-xs">например: "шт."</span></td>
                        <td class="col-xs-6 col-sm-6 col-md-5"><input type="text" class="form-control" name="config[unit]" value="'.$ks_config["unit"].'"></td>
                    </tr>
                    <tr>
                        <td class="col-xs-6 col-sm-6 col-md-7"><h6 class="media-heading text-semibold">Минимальная цена в фильтре:</h6><span class="text-muted text-size-small hidden-xs">Только цифры (без пробелов)</span></td>
                        <td class="col-xs-6 col-sm-6 col-md-5"><input type="text" class="form-control" name="config[minPrice]" value="'.$ks_config["minPrice"].'"></td>
                    </tr>
                    <tr>
                        <td class="col-xs-6 col-sm-6 col-md-7"><h6 class="media-heading text-semibold">Максимальная цена в фильтре:</h6><span class="text-muted text-size-small hidden-xs">Только цифры (без пробелов)</span></td>
                        <td class="col-xs-6 col-sm-6 col-md-5"><input type="text" class="form-control" name="config[maxPrice]" value="'.$ks_config["maxPrice"].'"></td>
                    </tr>
                    <tr>
                        <td class="col-xs-6 col-sm-6 col-md-7"><h6 class="media-heading text-semibold">Код заказа:</h6><span class="text-muted text-size-small hidden-xs">Если не указывать ничего, то код каждой покупки будет произвольный и уникальный.<br>Либо Вы можете задать код в определенном формате даты и времени. Смотрите формат тут <a href="http://php.net/manual/ru/function.date.php" target="_blank">http://php.net/manual/ru/function.date.php</a><br>Например: ydmHis</span></td>
                        <td class="col-xs-6 col-sm-6 col-md-5"><input type="text" class="form-control" name="config[order_code]" value="'.$ks_config["order_code"].'"></td>
                    </tr>
                    <tr>
                        <td class="col-xs-6 col-sm-6 col-md-7"><h6 class="media-heading text-semibold">Перенаправление после списания с баланса:</h6><span class="text-muted text-size-small hidden-xs">Укажите ссылку, куда пользователь будет перенаправлен после списания средств с баланса.</span></td>
                        <td class="col-xs-6 col-sm-6 col-md-5"><input type="text" class="form-control" name="config[redirect_after_balance]" value="'.$ks_config["redirect_after_balance"].'"></td>
                    </tr>
                    <tr>
                        <td class="col-xs-6 col-sm-6 col-md-7"><h6 class="media-heading text-semibold">Активация промокода на товары со скидкой:</h6><span class="text-muted text-size-small hidden-xs">Если включено, то промокод будет дейстовать так же и на товары уже имеющие скидку.</span></td>
                        <td class="col-xs-6 col-sm-6 col-md-5"><input class="switch" type="checkbox" name="config[promo_in_sale]" value="1" data-switchery="true"'.is_checked($ks_config["promo_in_sale"]).'></td>
                    </tr>
                    <tr>
                        <td class="col-xs-6 col-sm-6 col-md-7"><h6 class="media-heading text-semibold">Применять промокод для каждого товара отдельно:</h6></td>
                        <td class="col-xs-6 col-sm-6 col-md-5"><input class="switch" type="checkbox" name="config[promo_for_goods]" value="1" data-switchery="true"'.is_checked($ks_config["promo_for_goods"]).'></td>
                    </tr>
                    <tr>
                    <tr>
                        <td class="col-xs-6 col-sm-6 col-md-7"><h6 class="media-heading text-semibold">Категории, в которых промокод не действует:</h6><span class="text-muted text-size-small hidden-xs">Выберите категории, для которых промокод не будет действовать.</span></td>
                        <td class="col-xs-6 col-sm-6 col-md-5">
                            <select name="config[promo_no_cats][]" data-selected="'.$ks_config["promo_no_cats"].'" data-placeholder="Выберете" class="categoryselect" multiple style="width:100%;max-width:350px;">
                                '.$categories_list.'
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td class="col-xs-6 col-sm-6 col-md-7"><h6 class="media-heading text-semibold">Включить продажу ключей:</h6></td>
                        <td class="col-xs-6 col-sm-6 col-md-5"><input class="switch" type="checkbox" name="config[pay_keys]" value="1" data-switchery="true"'.is_checked($ks_config["pay_keys"]).'></td>
                    </tr>
                    
                    <tr>
                        <td class="col-xs-6 col-sm-6 col-md-7"><h6 class="media-heading text-semibold">Лицензионный ключ:</h6></td>
                        <td class="col-xs-6 col-sm-6 col-md-5"><input type="text" class="form-control" name="config[key]" value="'.$ks_config["key"].'"></td>
                    </tr>
                </table>
                
                <button type="submit" class="btn bg-teal btn-raised position-left legitRipple btn_m"><i class="fa fa-floppy-o position-left"></i>Сохранить</button>
                
            </form>
        </div>
        
        <!-- Статусы -->
        <div class="tab-pane" id="statuses">
            <form action="?mod=kylshop&act=settings&config=statuses" method="POST">
                
                <div class="pad">
                	<div class="row">
	                    <div class="col-lg-2">
	                        <a href="#" class="btn bg-teal btn-sm btn-raised position-left legitRipple" id="add_status"><span class="fa fa-plus"></span> &nbsp; Добавить статус</a>
	                    </div>
	                </div>
				</div>
				
                <div class="pad statuses_row">
                	'.$statuses_result.'
				</div>
                
                <div class="clr"></div>
                
                <div class="is_helper" style="display: block">
                    <ul>
                        <li><b>{ID}</b> - номер заказа</li>
                        <li><b>{cart}</b> - корзина</li>
                        <li><b>{total}</b> - сумма заказа</li>
                        <li><b>{method}</b> - методы</li>
                        <li><b>{form}</b> - заполненная форма</li>
                        <li><b>{date}</b> - дата заказа</li>
                        <li><b>{status}</b> - статус заказа</li>
                    </ul>
                </div>
                
                <button type="submit" id="save_statuses" class="btn bg-teal btn-raised position-left legitRipple btn_m"><i class="fa fa-floppy-o position-left"></i>Сохранить</button>
                
            </form>
        </div>
        
        <!-- Функции -->
        <div class="tab-pane" id="functions">
            <form action="?mod=kylshop&act=settings&config=functions" method="POST">
                <table class="table table-striped">
                    <tr>
                        <td class="col-xs-6 col-sm-6 col-md-7"><h6 class="media-heading text-semibold">Добавление в корзину:</h6><span class="text-muted text-size-small hidden-xs">Возможность добавлять товар в корзину, покупать сразу несколько товаров.<br>В противном случае останеться только кнопка <b>Купить</b> с моментальным переходом на страницу оплаты или на страницу с выбором способа оплаты, если у вас подключено несколько <a href="?mod=kylshop&act=payments">систем для оплаты</a>.</span></td>
                        <td class="col-xs-6 col-sm-6 col-md-5"><input class="switch" type="checkbox" name="config[add_to_cart]" value="1" data-switchery="true"'.is_checked($ks_config["add_to_cart"]).'></td>
                    </tr>
                    <tr>
                        <td class="col-xs-6 col-sm-6 col-md-7"><h6 class="media-heading text-semibold">Название кнопки добавления в корзину:</h6></td>
                        <td class="col-xs-6 col-sm-6 col-md-5"><input type="text" class="form-control" name="config[btn_title_add_to_cart]" value="'.$ks_config["btn_title_add_to_cart"].'"></td>
                    </tr>
                    <tr>
                        <td class="col-xs-6 col-sm-6 col-md-7"><h6 class="media-heading text-semibold">Счастливые часы:</h6><span class="text-muted text-size-small hidden-xs">На вкладке магазина добавляется функционал, который позволяет указать время когда к товару будет прибавляться автоматически вторая позиция бесплатно.</span></td>
                        <td class="col-xs-6 col-sm-6 col-md-5"><input class="switch" type="checkbox" name="config[one_plus_one]" value="1" data-switchery="true"'.is_checked($ks_config["one_plus_one"]).'></td>
                    </tr>
                    <tr>
                        <td class="col-xs-6 col-sm-6 col-md-7"><h6 class="media-heading text-semibold">Пересчет цены каждого товара:</h6><span class="text-muted text-size-small hidden-xs">Если включено, то цена в столбце цена в корзине будет умножатся на выбранное пользователем кол-во.<br>В противном случае цена будет показана за 1 шт.</span></td>
                        <td class="col-xs-6 col-sm-6 col-md-5"><input class="switch" type="checkbox" name="config[recalculation_price]" value="1" data-switchery="true"'.is_checked($ks_config["recalculation_price"]).'></td>
                    </tr>
                    <!--<tr>
                        <td class="col-xs-6 col-sm-6 col-md-7"><h6 class="media-heading text-semibold">Добавление товара с сайта (не доделана):</h6><span class="text-muted text-size-small hidden-xs">Настройка разрешает добавлять товар при создании новости на сайте.</span></td>
                        <td class="col-xs-6 col-sm-6 col-md-5">
                            <input class="switch" type="checkbox" name="config[add_shop_on_public]" value="1" data-switchery="true"'.is_checked($ks_config["add_shop_on_public"]).'>
                        </td>
                    </tr>
                    <tr>
                        <td class="col-xs-6 col-sm-6 col-md-7"><h6 class="media-heading text-semibold">Группы, которым разрешено добавлять товар:</h6><span class="text-muted text-size-small hidden-xs">Если предыдущая опция выключена и в настройках группы запрещено создавать новость выбранным группам, то данная настройка будет проигнорирована.</span></td>
                        <td class="col-xs-6 col-sm-6 col-md-5">
                            <select name="config[allow_add_group][]" id="groups" class="uniform field_type" multiple="" style="width: 100%; max-width: 350px;">
                                '.$groups.'
                            </select>
                        </td>
                    </tr>-->
                </table>
                
                <button type="submit" class="btn bg-teal btn-raised position-left legitRipple btn_m"><i class="fa fa-floppy-o position-left"></i>Сохранить</button>
                
            </form>
        </div>
        
        <!-- Вид -->
        <div class="tab-pane" id="show">
            <form action="?mod=kylshop&act=settings&config=show" method="POST">
                <h5 class="title_content">Список заказов (админ-панель)</h5>
                <table class="table table-striped">
                    <tr>
                        <td class="col-xs-6 col-sm-6 col-md-7"><h6 class="media-heading text-semibold">#</h6></td>
                        <td class="col-xs-6 col-sm-6 col-md-5"><input class="switch" type="checkbox" name="show[show_hash]" value="1" data-switchery="true"'.is_checked($ks_config["show_hash"]).'></td>
                    </tr>
                    <tr>
                        <td class="col-xs-6 col-sm-6 col-md-7"><h6 class="media-heading text-semibold">Номер заказа</h6></td>
                        <td class="col-xs-6 col-sm-6 col-md-5"><input class="switch" type="checkbox" name="show[show_number]" value="1" data-switchery="true"'.is_checked($ks_config["show_number"]).'></td>
                    </tr>
                    <tr>
                        <td class="col-xs-6 col-sm-6 col-md-7"><h6 class="media-heading text-semibold">Покупатель</h6></td>
                        <td class="col-xs-6 col-sm-6 col-md-5"><input class="switch" type="checkbox" name="show[show_payer]" value="1" data-switchery="true"'.is_checked($ks_config["show_payer"]).'></td>
                    </tr>
                    <tr>
                        <td class="col-xs-6 col-sm-6 col-md-7"><h6 class="media-heading text-semibold">Товары</h6></td>
                        <td class="col-xs-6 col-sm-6 col-md-5"><input class="switch" type="checkbox" name="show[show_goods]" value="1" data-switchery="true"'.is_checked($ks_config["show_goods"]).'></td>
                    </tr>
                    <tr>
                        <td class="col-xs-6 col-sm-6 col-md-7"><h6 class="media-heading text-semibold">Дата</h6></td>
                        <td class="col-xs-6 col-sm-6 col-md-5"><input class="switch" type="checkbox" name="show[show_date]" value="1" data-switchery="true"'.is_checked($ks_config["show_date"]).'></td>
                    </tr>
                    <tr>
                        <td class="col-xs-6 col-sm-6 col-md-7"><h6 class="media-heading text-semibold">Сумма</h6></td>
                        <td class="col-xs-6 col-sm-6 col-md-5"><input class="switch" type="checkbox" name="show[show_total]" value="1" data-switchery="true"'.is_checked($ks_config["show_total"]).'></td>
                    </tr>
                    <tr>
                        <td class="col-xs-6 col-sm-6 col-md-7"><h6 class="media-heading text-semibold">Статус</h6></td>
                        <td class="col-xs-6 col-sm-6 col-md-5"><input class="switch" type="checkbox" name="show[show_status]" value="1" data-switchery="true"'.is_checked($ks_config["show_status"]).'></td>
                    </tr>
                    <tr>
                        <td class="col-xs-6 col-sm-6 col-md-7"><h6 class="media-heading text-semibold">Выбор несколько...</h6></td>
                        <td class="col-xs-6 col-sm-6 col-md-5"><input class="switch" type="checkbox" name="show[show_many_checkbox]" value="1" data-switchery="true"'.is_checked($ks_config["show_many_checkbox"]).'></td>
                    </tr>
                </table>
                
                <input type="hidden" name="shows" value="1">
                <button type="submit" class="btn bg-teal btn-raised position-left legitRipple btn_m"><i class="fa fa-floppy-o position-left"></i>Сохранить</button>
                
            </form>
        </div>
        
        <div class="tab-pane" id="form">
            <form action="'.$_SERVER["REQUEST_URI"].'" method="POST" class="pad">
            
                <div class="row">
                    <div class="col-sm-2">
                        <select name="create_fields" class="uniform field_type">
                            <option value="input">Одна строка</option>
                            <option value="textarea">Несколько строк</option>
                            <option value="select">Список</option>
                            <option value="checkbox">Переключатель \'Да\' или \'Нет\'</option>
                            <option value="file">Файл</option>
                        </select>
                    </div>
                    <div class="col-sm-2">
                    	<a href="#" class="btn bg-teal btn-sm btn-raised position-left legitRipple add_field"><i class="fa fa-plus" aria-hidden="true"></i></a>
                    	<i class="help-button visible-lg-inline-block text-primary-600 fa fa-question-circle position-right" style="position: relative;top: -15px;" data-rel="popover" data-trigger="hover" data-placement="right" data-content="В поле атрибуты вместо одинарных кавычек указывайте *" data-original-title="" title=""></i>
                    </div>
                </div>
                
                <div class="constructor">
                
                '.$fields.'
                    
                </div>
                
                <br>
                <button type="submit" class="btn bg-teal btn-raised position-left legitRipple"><i class="fa fa-floppy-o position-left"></i>Сохранить</button>
                
                <br><br>
                <div class="is_helper" style="display: block">
                    <p><b>{form}</b> - выводит всю форму как есть.</p>
                    <p><b>{_1583857752405}</b> - тег выведет элемент формы, с идентификатором 1583857752405.</p>
                </div>
                
            </form>
        </div>
        
        <div class="tab-pane" id="method">
            <form action="?mod=kylshop&act=settings&config=method" method="POST">
                
                <div class="pad">
                	<div class="row">
	                    <div class="col-sm-2">
	                        <a href="#" class="btn bg-teal btn-sm btn-raised position-left legitRipple" id="add_method"><span class="fa fa-plus"></span> &nbsp; Добавить метод</a>
	                    </div>
	                    <div class="col-sm-10">
	                        <span class="text-muted text-size-small hidden-xs">Данный функционал будет работать, если в настройках включена опция <b>Дополнительные методы</b>.</span>
	                    </div>
	                </div>
				</div>
				
                <div class="pad method_row">
                	'.$method_result.'
				</div>
                
                <div class="clr"></div>
                
                <button type="submit" id="save_method" class="btn bg-teal btn-raised position-left legitRipple btn_m"><i class="fa fa-floppy-o position-left"></i>Сохранить</button>
                
            </form>
        </div>
        
        <div class="tab-pane" id="addon">
            <form action="?mod=kylshop&act=settings&config=addon" method="POST">
                
                <div class="pad">
                	<div class="row">
	                    <div class="col-lg-2">
	                        <a href="#" class="btn bg-teal btn-sm btn-raised position-left legitRipple" id="add_addon"><span class="fa fa-plus"></span> &nbsp; Добавить товар</a>
	                    </div>
	                    <div class="col-lg-10">
	                        <span class="text-muted text-size-small hidden-xs">Данный функционал позволит добавить обязательные дополнительные товары к определенному товару.</span>
	                    </div>
	                </div>
				</div>
				
                <div class="pad addon_row">
                	'.$addon_result.'
				</div>
                
                <div class="clr"></div>
                
                <button type="submit" id="save_addon" class="btn bg-teal btn-raised position-left legitRipple btn_m"><i class="fa fa-floppy-o position-left"></i>Сохранить</button>
                
            </form>
        </div>
        
        <div class="tab-pane" id="sale">
            <form action="?mod=kylshop&act=settings&config=sale" method="POST">
                
                <div class="pad">
                	<div class="row">
	                    <div class="col-lg-2">
	                        <a href="#" class="btn bg-teal btn-sm btn-raised position-left legitRipple" id="add_sale"><span class="fa fa-plus"></span> &nbsp; Добавить условие</a>
	                    </div>
	                    <div class="col-lg-10">
	                        <span class="text-muted text-size-small hidden-xs">Данный функционал позволяет построить условия начисления скидки.<br><b style="color:red">Начинайте с минимальных сумм, постепенно переходя к более высоким, иначе работать будет неправильно!</b></span>
	                    </div>
	                </div>
				</div>
				
                <div class="pad sale_row">
                	'.$sale_result.'
				</div>
                
                <div class="clr"></div>
                
                <button type="submit" id="save_sale" class="btn bg-teal btn-raised position-left legitRipple btn_m"><i class="fa fa-floppy-o position-left"></i>Сохранить</button>
                
            </form>
        </div>
        
    </div>
</div>
<script>
    $(function(){
        $(".categoryselect").chosen();
    })
</script>';