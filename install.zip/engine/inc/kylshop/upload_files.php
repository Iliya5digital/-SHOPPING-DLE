<?php
/**
 * @name список заказов
 */
if (!defined('DATALIFEENGINE') OR !defined('LOGGED_IN')) {
    header("HTTP/1.1 403 Forbidden");
    header('Location: ../../');
    die("Hacking attempt!");
}

if ($member_id['user_group'] != 1) msg("error", $lang['index_denied'], $lang['index_denied']);

if(!empty($_FILES["file"])){

    $result = [];
    foreach ($_FILES["file"]["name"] as $key => $name) {

        $dir_a = "/uploads/posts/" . date("Y-m") . "/";
        $dir = ROOT_DIR . "/uploads/posts/" . date("Y-m");
        if(!file_exists($dir)) mkdir($dir, 0777);

        move_uploaded_file($_FILES["file"]["tmp_name"][$key], $dir . '/' . basename($name));

        array_push($result, $dir_a . basename($name));
    }

    echo implode("=", $result);
}


if(!empty($_POST["delete_img"])){

    unlink(ROOT_DIR . trim(htmlspecialchars(strip_tags($_POST["delete_img"]))));
    echo "ok";
}

exit;