<?php
/**
 * @name список заказов
 */
if (!defined('DATALIFEENGINE') OR !defined('LOGGED_IN')) {
    header("HTTP/1.1 403 Forbidden");
    header('Location: ../../');
    die("Hacking attempt!");
}

$result_count = $db->super_query( "SELECT COUNT(*) as count FROM " . PREFIX . "_kylshop_buy");

$start_from = @ceil( $result_count['count'] / 25 );

if(isset($_GET["page"]))
    $page = $_GET['page'] - 1;
else
    $page = 0;

$start_select = abs($page * 25);


if($result_count['count'] > 25){

    $previous = $config["http_home_url"] . $config["admin_path"] . "?mod=kylshop";

    $pagination = '<ul class="pagination">';

    for ($i = 1; $i <= $start_from; $i++) {

        if($i == 1){

            if(isset($_GET["page"]) && $_GET["page"] != 1 && $_GET["page"] != 2)
                $pagination .= '<li><a href="'.$previous.'&page='.($_GET["page"]-1).'">&laquo;</a></li>';
            else
                $pagination .= '<li><a href="'.$previous.'">&laquo;</a></li>';
        } else{

            if($_GET["page"] == $i) $pagination .= '<li><a href="'.$previous.'&page='.$i.'" class="active">'.$i.'</a></li>';
            else $pagination .= '<li><a href="'.$previous.'&page='.$i.'">'.$i.'</a></li>';
        }
    }

    if(!isset($_GET["page"]))
        $pagination .= '<li><a href="'.$previous.'&page=2">&raquo;</a></li>';
    else if(isset($_GET["page"]) && $_GET["page"] != ($i-1))
        $pagination .= '<li><a href="'.$previous.'&page='.($_GET["page"]+1).'">&raquo;</a></li>';
    else
        $pagination .= '<li><a href="'.$previous.'&page='.($start_from).'">&raquo;</a></li>';

    $pagination .= '</ul>';

} else{

    $pagination = "";
}