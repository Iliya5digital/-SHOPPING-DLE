<?php
/**
 * @name шаблоны писем
 */
if (!defined('DATALIFEENGINE') OR !defined('LOGGED_IN')) {
	header("HTTP/1.1 403 Forbidden");
	header('Location: ../../');
	die("Hacking attempt!");
}

if ($member_id['user_group'] != 1) msg("error", $lang['index_denied'], $lang['index_denied']);

if(file_exists(ENGINE_DIR . "/modules/kylshop/template_email.php"))
	require_once ENGINE_DIR . "/modules/kylshop/template_email.php";

echo '<form action="?mod=kylshop&act=settings&config=template_email" method="POST" id="accordion" class="accordion pad">
    
	<div class="accordion-group">
		<div class="accordion-heading">
			<a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapseOne">Шаблон сообщения <b>при оформлении заказа без оплаты</b> (администратору)</a>
		</div>
		<div id="collapseOne" class="accordion-body collapse">
			<div class="accordion-inner mt-20">
				<b>{ID}</b> - номер заказа.<br>
				<b>{cart}</b> - содержимое заказа (товары).<br>
				<b>{total}</b> - сумма заказа.<br>
				<b>{sale}</b> - скидка.<br>
				<b>{without-sale}</b> - сумма со скидкой.<br>
				<b>{currency}</b> - валюта.<br>
				<b>{method}</b> - выбранный способ.<br>
				<b>{method-total}</b> - цена за метод.<br>
				<b>{total-all}</b> - цена с учетом скидки + доставка.<br>
				<b>{form}</b> - поля из заполненной формы.<br>
				<b>{date}</b> - дата заказа.<br>
				<b>{status}</b> - статус заказа.
				<br><br>
				<textarea class="classic" rows="15" style="width:100%;" name="email_1">'.$template_e["email_1"].'</textarea>
			</div>
		</div>
	</div>
	<div class="accordion-group">
		<div class="accordion-heading">
			<a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo">Шаблон сообщения <b>при оформлении заказа без оплаты</b> (покупателю)</a>
		</div>
		<div id="collapseTwo" class="accordion-body collapse">
			<div class="accordion-inner mt-20">
				<b>{ID}</b> - номер заказа.<br>
				<b>{cart}</b> - содержимое заказа (товары).<br>
				<b>{total}</b> - сумма заказа.<br>
				<b>{sale}</b> - скидка.<br>
				<b>{without-sale}</b> - сумма со скидкой.<br>
				<b>{currency}</b> - валюта.<br>
				<b>{method}</b> - выбранный способ.<br>
				<b>{method-total}</b> - цена за метод.<br>
				<b>{total-all}</b> - цена с учетом скидки + доставка.<br>
				<b>{form}</b> - поля из заполненной формы.<br>
				<b>{date}</b> - дата заказа.<br>
				<b>{status}</b> - статус заказа.
				<br><br>
				<textarea class="classic" rows="15" style="width:100%;" name="email_2">'.$template_e["email_2"].'</textarea>
			</div>
		</div>
	</div>
	<div class="accordion-group">
		<div class="accordion-heading">
			<a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapseThree">Шаблон сообщения <b>после оплаты заказа</b> (администратору)</a>
		</div>
		<div id="collapseThree" class="accordion-body collapse">
			<div class="accordion-inner mt-20">
				<b>{ID}</b> - номер заказа.<br>
				<b>{cart}</b> - содержимое заказа (товары).<br>
				<b>{total}</b> - сумма заказа.<br>
				<b>{sale}</b> - скидка.<br>
				<b>{without-sale}</b> - сумма со скидкой.<br>
				<b>{currency}</b> - валюта.<br>
				<b>{method}</b> - выбранный способ.<br>
				<b>{method-total}</b> - цена за метод.<br>
				<b>{total-all}</b> - цена с учетом скидки + доставка.<br>
				<b>{form}</b> - поля из заполненной формы.<br>
				<b>{date}</b> - дата заказа.<br>
				<b>{status}</b> - статус заказа.
				<br><br>
				<textarea class="classic" rows="15" style="width:100%;" name="email_3">'.$template_e["email_3"].'</textarea>
			</div>
		</div>
	</div>
	<div class="accordion-group">
		<div class="accordion-heading">
			<a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapseFour">Шаблон сообщения <b>после оплаты заказа</b> (покупателю)</a>
		</div>
		<div id="collapseFour" class="accordion-body collapse">
			<div class="accordion-inner mt-20">
				<b>{ID}</b> - номер заказа.<br>
				<b>{cart}</b> - содержимое заказа (товары).<br>
				<b>{link-success}</b> - ссылки на страницы где будут показаны товары после оплаты (для гостей).<br>
				<b>{total}</b> - сумма заказа.<br>
				<b>{sale}</b> - скидка.<br>
				<b>{without-sale}</b> - сумма со скидкой.<br>
				<b>{currency}</b> - валюта.<br>
				<b>{method}</b> - выбранный способ.<br>
				<b>{method-total}</b> - цена за метод.<br>
				<b>{total-all}</b> - цена с учетом скидки + доставка.<br>
				<b>{form}</b> - поля из заполненной формы.<br>
				<b>{date}</b> - дата заказа.<br>
				<b>{status}</b> - статус заказа.
				<br><br>
				<textarea class="classic" rows="15" style="width:100%;" name="email_4">'.$template_e["email_4"].'</textarea>
			</div>
		</div>
	</div>
	<div class="accordion-group">
		<div class="accordion-heading">
			<a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapseFive">Шаблон сообщения <b>при изменении статуса заказа в админ-панели</b> (покупателю)</a>
		</div>
		<div id="collapseFive" class="accordion-body collapse">
			<div class="accordion-inner mt-20">
				<b>{ID}</b> - номер заказа.<br>
				<b>{cart}</b> - содержимое заказа (товары).<br>
				<b>{total}</b> - сумма заказа.<br>
				<b>{sale}</b> - скидка.<br>
				<b>{without-sale}</b> - сумма со скидкой.<br>
				<b>{currency}</b> - валюта.<br>
				<b>{method}</b> - выбранный способ.<br>
				<b>{method-total}</b> - цена за метод.<br>
				<b>{total-all}</b> - цена с учетом скидки + доставка.<br>
				<b>{form}</b> - поля из заполненной формы.<br>
				<b>{date}</b> - дата заказа.<br>
				<b>{status}</b> - статус заказа.
				<br><br>
				<textarea class="classic" rows="15" style="width:100%;" name="email_5">'.$template_e["email_5"].'</textarea>
			</div>
		</div>
	</div>
    
    <br>
    <button type="submit" class="btn bg-teal btn-raised position-left legitRipple"><i class="fa fa-floppy-o position-left"></i>Сохранить</button>
    
</form>';