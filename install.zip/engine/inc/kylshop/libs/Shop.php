<?php
/**
 * Created by PhpStorm.
 * User: kylaksizov
 * Date: 22.05.2018
 * Time: 13:00
 */

class Shop{

    // создание заказа
    public function create(){

    }

}