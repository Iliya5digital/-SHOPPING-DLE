<?php
/**
 * @name статистика
 */
if (!defined('DATALIFEENGINE') OR !defined('LOGGED_IN')) {
    header("HTTP/1.1 403 Forbidden");
    header('Location: ../../');
    die("Hacking attempt!");
}

if ($member_id['user_group'] != 1) msg("error", $lang['index_denied'], $lang['index_denied']);


$statistic = $db->super_query( "SELECT status FROM " . PREFIX . "_kylshop_buy", true );

$s_all = $s_success = $s_fail = $s_wait = 0;
foreach ($statistic as $item) {
    $s_all++;

    if($item["status"] == "1") $s_success++;
    if($item["status"] == "2") $s_fail++;
    if($item["status"] == "0") $s_wait++;
}

echo '<div class="panel-heading">
    <i class="fa fa-bar-chart" aria-hidden="true"></i> <b>Статистика</b>
</div>

<table class="table table-striped">
    <tr>
        <td class="col-xs-6 col-sm-6 col-md-7">Всего заказов:</td>
        <td class="col-xs-6 col-sm-6 col-md-5 text-right">'.$s_all.'</td>
    </tr>
    <tr>
        <td class="col-xs-6 col-sm-6 col-md-7">Оплачено:</td>
        <td class="col-xs-6 col-sm-6 col-md-5 text-right">'.$s_success.'</td>
    </tr>
    <tr>
        <td class="col-xs-6 col-sm-6 col-md-7">Отказано:</td>
        <td class="col-xs-6 col-sm-6 col-md-5 text-right">'.$s_fail.'</td>
    </tr>
    <tr>
        <td class="col-xs-6 col-sm-6 col-md-7">Ожидает оплаты:</td>
        <td class="col-xs-6 col-sm-6 col-md-5 text-right">'.$s_wait.'</td>
    </tr>
</table>';