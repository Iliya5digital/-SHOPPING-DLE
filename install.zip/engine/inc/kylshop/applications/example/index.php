<?php
/**
 * @name главный, обязательный файл расширения
 * @version 1.0.0
 */
if (!defined('DATALIFEENGINE') OR !defined('LOGGED_IN')) {
    header("HTTP/1.1 403 Forbidden");
    header('Location: ../../');
    die("Hacking attempt!");
}


// далее не обязательно...

echo '<div class="panel-heading">
    '.$app_title.'
    <!--<div class="heading-elements">
        <ul class="icons-list">
            <li><a href="#" class="c_grey"><i class="fa fa-download"></i></a></li>
        </ul>
    </div>-->
</div>

<div class="panel-body">
    <p>Ваше расширение</p>
</div>';