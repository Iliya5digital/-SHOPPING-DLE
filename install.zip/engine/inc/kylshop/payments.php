<?php
/**
 * @name главный файл систем оплат
 */
if (!defined('DATALIFEENGINE') OR !defined('LOGGED_IN')) {
    header("HTTP/1.1 403 Forbidden");
    header('Location: ../../');
    die("Hacking attempt!");
}

if ($member_id['user_group'] != 1) msg("error", $lang['index_denied'], $lang['index_denied']);



$payments = '';
foreach (scandir(ENGINE_DIR . '/modules/kylshop/payments') as $file) {

    if($file != "." && $file != ".." && $file != "Example") {
        if (file_exists(ENGINE_DIR . '/modules/kylshop/payments/' . $file . '/config.json')) {

            $config_payment = json_decode(file_get_contents(ENGINE_DIR . '/modules/kylshop/payments/' . $file . '/config.json'), true);

            // если было сохранение настроек
            if(count($_POST[$file]) > 0){

                foreach ($_POST[$file] as $key => $item) {
                    $config_payment[$key] = $item;
                }

                // сохраняем настройки системы
                $sourse = ENGINE_DIR . '/modules/kylshop/payments/' . $file . '/config.json';
                $fp = fopen($sourse, "w");
                flock($fp, LOCK_EX);
                fwrite($fp, json_encode($config_payment, JSON_PRETTY_PRINT | JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP | JSON_UNESCAPED_UNICODE));
                flock($fp, LOCK_UN);

                header("Location: " . $_SERVER["HTTP_REFERER"]);
            }

            $params = "";
            foreach ($config_payment as $key => $field) {
                if($key != "name" && $key != "img"){

                    if(strripos($key, "help") === false) {

                        $help = '';
                        if(!empty($config_payment[$key . "_help"])) $help = '<i class="help-button visible-lg-inline-block text-primary-600 fa fa-question-circle position-right" data-rel="popover" data-trigger="hover" data-placement="right" data-content="'.$config_payment[$key . "_help"].'" data-original-title="" title=""></i>';

                        $params .= '<div class="row">
                            <div class="col-md-6 pad8">
                                <b>'.$key.'</b>
                                '.$help.'
                            </div>
                            <div class="col-md-6">
                                <input type="text" name="'.$file.'['.$key.']" value="'.$field.'" class="form-control">
                            </div>
                        </div>';
                    }
                }
            }

            if(!empty($config_payment["helper"])) $params .= $config_payment["helper"];


            $payments .= '<tr>
                <td class="col-xs-5 col-sm-5 col-md-5"><img src="'.$config["http_home_url"]."templates/".$config["skin"].$config_payment["img"].'" alt=""></td>
                <td class="col-xs-7 col-sm-7 col-md-7 text-right">
                    '.$params.'
                </td>
            </tr>';
        }
    }
}

echo '<div class="panel-heading">
    <i class="fa fa-credit-card-alt" aria-hidden="true"></i> <b>Платежные системы</b>
</div>

<form action="?mod=kylshop&act=payments" method="POST">

    <table class="table table-striped">
        '.$payments.'
    </table>
    
    <button type="submit" class="btn bg-teal btn-raised position-left legitRipple btn_m"><i class="fa fa-floppy-o position-left"></i>Сохранить</button>
    
</form>';