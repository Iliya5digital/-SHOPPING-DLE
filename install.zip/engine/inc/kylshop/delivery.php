<?php
/**
 * @name настройки
 */
if (!defined('DATALIFEENGINE') OR !defined('LOGGED_IN')) {
    header("HTTP/1.1 403 Forbidden");
    header('Location: ../../');
    die("Hacking attempt!");
}

function is_checked($data){
    return $data ? " checked" : "";
}

$delivery_data = $db->super_query( "SELECT * FROM " . PREFIX . "_kylshop_delivery", true );

$delivery_result = "";

if(!empty($delivery_data)){
    foreach ($delivery_data as $data_row) {

        $delivery_result .= '<div class="one_marker" id="'.$data_row["marker_id"].'">
            <input type="hidden" name="marker_id[]" value="'.$data_row["marker_id"].'">
            <input type="hidden" name="marker_coords[]" value="'.$data_row["coords"].'">
            <input type="text" name="marker_title[]" autocomplete="off" value="'.$data_row["title"].'" class="form-control" placeholder="Название места">
            <textarea name="marker_description[]" class="form-control scroll" rows="5" placeholder="Опишите место">'.$data_row["description"].'</textarea>
            <a href="#" class="fa fa-remove remove_marker" title="Удалить маркер"></a>
        </div>';
    }
}





if ($member_id['user_group'] != 1) msg("error", $lang['index_denied'], $lang['index_denied']);

echo '<script type="text/javascript" src="//maps.googleapis.com/maps/api/js?key='.$ks_config["google_maps_api_key"].'&libraries=places"></script>';

/**
 * @name настройки
 */
echo '<div class="panel-heading">
    <ul class="nav nav-tabs nav-tabs-solid">
        <li class="active"><a href="#point_of_delivery" data-toggle="tab"><i class="fa fa-dot-circle-o position-left"></i> Пункты выдачи</a></li>
        <li><a href="#city" data-toggle="tab"><i class="fa fa-cog" aria-hidden="true"></i> Города</a></li>
    </ul>
    <div class="heading-elements">
        <ul class="icons-list">
            <li><a href="#" class="panel-fullscreen"><i class="fa fa-expand"></i></a></li>
        </ul>
    </div>
</div>

<div class="form-horizontal">
    <div class="panel-tab-content tab-content">
    
        <!-- Пункты выдачи -->
        <div class="tab-pane active" id="point_of_delivery">
            <form action="?mod=kylshop&act=settings&config=delivery" method="POST">
                <table class="table table-striped">
                    <tr>
                        <td class="col-xs-6 col-sm-6 col-md-7"><h6 class="media-heading text-semibold">Включить функционал доставки:</h6><span class="text-muted text-size-small hidden-xs">Если включено, то при оформлении заказа, пользователю будет предложено выбрать способ доставки.</span></td>
                        <td class="col-xs-6 col-sm-6 col-md-5"><input class="switch" type="checkbox" name="config[delivery_power]" value="1" data-switchery="true"'.is_checked($ks_config["delivery_power"]).'></td>
                    </tr>
                </table>
                
                <br>
                <!-- GOOGLE MAPS -->
                <div class="flex">
                    <div class="w30">
                        <div class="pad10">
                            <h6 class="media-heading text-semibold">Точки выдачи</h6>
                            <div class="markers_delivery scroll">
                            
                                '.$delivery_result.'
                                
                            </div>
                        </div>
                    </div>
                    <div class="is_map pr">
                    
                        <p style="color: #4caf50;font-weight: 600;margin-bottom: 5px;">Карта будет отображаться точно так же на сайте.</p>
                    
                        <div id="maps_panel">
                            <ul>
                                <li><a href="#" id="add_location"><i class="fa fa-plus position-left"></i> Добавить точку</a></li>
                                <li><a href="#" id="get_location">Где я?</a></li>
                            </ul>
                        </div>
                        <div id="info_help"></div>
                        
                        <!-- MAPS -->
                        <div id="map"></div>
                        
                        <!--<div class="location_marker_tmp"></div>-->
                        
                    </div>
                </div>
                <br>
                
                <table class="table table-striped">
                    <tr>
                        <td class="col-xs-4 col-sm-4 col-md-4">
                            <h6 class="media-heading text-semibold">Максимальная цена с бесплатной доставкой:</h6>
                            <span class="text-muted text-size-small hidden-xs">При оформлении заказа на сумму больше указанной, к общей сумме будет прибавляться цена, указанная ниже.</span>
                        </td>
                        <td class="col-xs-8 col-sm-8 col-md-8 is_map">
                            <input type="text" class="form-control" name="config[max_total_delivery]" value="'.$ks_config["max_total_delivery"].'">
                        </td>
                    </tr>
                    <tr>
                        <td class="col-xs-4 col-sm-4 col-md-4">
                            <h6 class="media-heading text-semibold">Цена за доставку:</h6>
                        </td>
                        <td class="col-xs-8 col-sm-8 col-md-8 is_map">
                            <input type="text" class="form-control" name="config[price_delivery]" value="'.$ks_config["price_delivery"].'">
                        </td>
                    </tr>
                    <tr>
                        <td class="col-xs-4 col-sm-4 col-md-4">
                            <h6 class="media-heading text-semibold">Скидка при самовывозе:</h6>
                        </td>
                        <td class="col-xs-8 col-sm-8 col-md-8 is_map">
                            <input type="text" class="form-control" name="config[pickup_sale]" value="'.$ks_config["pickup_sale"].'">
                        </td>
                    </tr>
                    <tr>
                        <td class="col-xs-4 col-sm-4 col-md-4">
                            <h6 class="media-heading text-semibold">GOOGLE MAPS API KEY:</h6>
                            <span class="text-muted text-size-small hidden-xs">Ключ вашего проекта от сервиса <a href="https://console.developers.google.com/apis/dashboard">GOOGLE APIs</a>.</span>
                        </td>
                        <td class="col-xs-8 col-sm-8 col-md-8 is_map">
                            <input type="text" class="form-control" name="config[google_maps_api_key]" value="'.$ks_config["google_maps_api_key"].'">
                        </td>
                    </tr>
                </table>
                
                <input type="hidden" id="delivery_mapInfo" name="config[delivery_mapInfo]" value='.$ks_config["delivery_mapInfo"].'>
                
                <button type="submit" id="save_delivery" class="btn bg-teal btn-raised position-left legitRipple btn_m"><i class="fa fa-floppy-o position-left"></i>Сохранить</button>
                
            </form>
        </div>
        
        
        <div class="tab-pane" id="city">
            <form action="?mod=kylshop&act=settings&config=delivery_city" method="POST">
                <table class="table table-striped">
                    <tr>
                        <td class="col-xs-6 col-sm-6 col-md-7">
                            <h6 class="media-heading text-semibold">Города, в которые вы рассылаете товары:</h6>
                            <span class="text-muted text-size-small hidden-xs">Каждый город/нас. пункт с новой строки</span>
                        </td>
                        <td class="col-xs-6 col-sm-6 col-md-5 is_map">
                            <textarea class="form-control" name="config[delivery_city]" rows="20">'.$ks_config["delivery_city"].'</textarea>
                        </td>
                    </tr>
                </table>
                
                <button type="submit" id="save_delivery" class="btn bg-teal btn-raised position-left legitRipple btn_m"><i class="fa fa-floppy-o position-left"></i>Сохранить</button>
                
            </form>
        </div>
        
    </div>
</div>';