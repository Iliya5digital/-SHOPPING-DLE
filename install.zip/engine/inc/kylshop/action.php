<?php
/**
 * @name обработчик всех форм
 */
if (!defined('DATALIFEENGINE') OR !defined('LOGGED_IN')) {
    header("HTTP/1.1 403 Forbidden");
    header('Location: ../../');
    die("Hacking attempt!");
}

/**
 * @name сохранение  общих настроек
 */
if(!empty($_GET["config"]) && $_GET["config"] == "main"){

    if(empty($_POST["config"]["payments_power"])) $_POST["config"]["payments_power"] = "0";
    if(empty($_POST["config"]["payment_guest"])) $_POST["config"]["payment_guest"] = "0";
    if(empty($_POST["config"]["payments_balance"])) $_POST["config"]["payments_balance"] = "0";
    if(empty($_POST["config"]["notification"])) $_POST["config"]["notification"] = "0";
    if(empty($_POST["config"]["method"])) $_POST["config"]["method"] = "0";
    if(empty($_POST["config"]["moderation"])) $_POST["config"]["moderation"] = "0";
    if(empty($_POST["config"]["promo_in_sale"])) $_POST["config"]["promo_in_sale"] = "0";
    if(empty($_POST["config"]["pay_keys"])) $_POST["config"]["pay_keys"] = "0";
    if(empty($_POST["config"]["promo_for_goods"])) $_POST["config"]["promo_for_goods"] = "0";
    if(empty($_POST["config"]["add_shop_on_public"])) $_POST["config"]["add_shop_on_public"] = "0";

    if(!empty($_POST["config"]["allow_add_group"])) $_POST["config"]["allow_add_group"] = implode(",", $_POST["config"]["allow_add_group"]);
    else $_POST["config"]["allow_add_group"] = "";

    if(!empty($_POST["config"]["promo_no_cats"])) $_POST["config"]["promo_no_cats"] = implode(",", $_POST["config"]["promo_no_cats"]);
    else $_POST["config"]["promo_no_cats"] = "";

    editConfig($_POST["config"]);

    header("Location: " . $_SERVER["HTTP_REFERER"]);
}


/**
 * @name сохранение настроек функций
 */
if(!empty($_GET["config"]) && $_GET["config"] == "functions"){

    if(empty($_POST["config"]["add_to_cart"])) $_POST["config"]["add_to_cart"] = "0";
    if(empty($_POST["config"]["recalculation_price"])) $_POST["config"]["recalculation_price"] = "0";
    if(empty($_POST["config"]["one_plus_one"])) $_POST["config"]["one_plus_one"] = "0";
    if(!empty($_POST["config"]["allow_add_group"])) $_POST["config"]["allow_add_group"] = implode(",", $_POST["config"]["allow_add_group"]);
    if(empty($_POST["config"]["allow_add_group"])) $_POST["config"]["allow_add_group"] = "";

    editConfig($_POST["config"]);

    header("Location: " . $_SERVER["HTTP_REFERER"]);
}


/**
 * @name сохранение настроек вида
 */
if(!empty($_GET["config"]) && $_GET["config"] == "show"){

    if(empty($_POST["show"]["show_hash"])) $_POST["show"]["show_hash"] = "0";
    if(empty($_POST["show"]["show_number"])) $_POST["show"]["show_number"] = "0";
    if(empty($_POST["show"]["show_payer"])) $_POST["show"]["show_payer"] = "0";
    if(empty($_POST["show"]["show_goods"])) $_POST["show"]["show_goods"] = "0";
    if(empty($_POST["show"]["show_date"])) $_POST["show"]["show_date"] = "0";
    if(empty($_POST["show"]["show_total"])) $_POST["show"]["show_total"] = "0";
    if(empty($_POST["show"]["show_status"])) $_POST["show"]["show_status"] = "0";
    if(empty($_POST["show"]["show_many_checkbox"])) $_POST["show"]["show_many_checkbox"] = "0";

    editConfig($_POST["show"]);

    header("Location: " . $_SERVER["HTTP_REFERER"]);
}


// генерация промо-кодов
function generationPromoCode($countChar = 16, $divider = false){
	$chars = '12345ABCDEFGHIJKLMNOPQRSTUVWXYZ67890';
	$hashpromo = '';
	$j = 0;
	for($ichars = 0; $ichars < $countChar; ++$ichars) {
		$random = str_shuffle($chars);
		$t = '';
		if($divider != false && $j == $divider){
			$t = '-';
			$j = 0;
		}
		$hashpromo .= $t . $random[0];
		if($j != $divider) $j++;
	}
	return $hashpromo;
}

/**
 * @name удаление одного промо-кода
 */
if(!empty($_POST["delete_code"]) && ctype_digit($_POST["delete_code"])){

	$code_id = trim($_POST["delete_code"]);
	$result = $db->query( "DELETE FROM  " . PREFIX . "_promocodes WHERE `id` = '{$code_id}'" );
	if($result) echo 'ok';
	exit;
}

/**
 * @name действия для промо-кодов
 */
if(!empty($_GET["config"]) && $_GET["config"] == "action_promo" && !empty($_POST["action_code"])){

	// удаление
	if($_POST["action_code"] == "delete"){

		$where = '';
		foreach ( $_POST["code_edit"] as $key => $code ) {

			$where .= "`id` = '{$key}' OR ";
		}

		$where = substr($where, 0, -4);

		$db->query( "DELETE FROM  " . PREFIX . "_promocodes WHERE " . $where );
	}

	header("Location: " . $_SERVER["HTTP_REFERER"]);
}


/**
 * @name создание промо-кодов
 */
if(!empty($_GET["config"]) && $_GET["config"] == "create_promo"){

	$code = '';
	$countChars = 16;
	$comment = '';
	$type = 0;

	// если указано что-то в коде
	if(!empty($_POST["promo_code"])){

		if(ctype_digit($_POST["promo_code"])) $countChars = ((int)$_POST["promo_code"] <= 255) ? $_POST["promo_code"] : 255;
		else $code = $_POST["promo_code"];
	}

	// скидка
	$sale = (!empty($_POST["promo_sale"])) ? $_POST["promo_sale"] : '10%';

	// срок | по умолчанию месяц
	$term = (!empty($_POST["promo_term"])) ? strtotime($_POST["promo_term"]) : (time() + (2592000 * 12));

	if(!empty($_POST["promo_comment"])) $comment = trim(htmlspecialchars(strip_tags($_POST["promo_comment"])));
	if(!empty($_POST["type"])) $type = 1;

	if(empty($code)){

		$count = (!empty($_POST["promo_count"]) && ctype_digit($_POST["promo_count"])) ? $_POST["promo_count"] : 1;

		for ($i = 0; $i < $count; $i++){
			$code = generationPromoCode($countChars, $ks_config["divider_promocode"]);
			$db->query( "INSERT INTO  " . PREFIX . "_promocodes (code, sale, term, comment, type, status) VALUES ('{$code}', '{$sale}', '{$term}', '{$comment}', '{$type}', '1')" );
		}

	// создаем 1 промо-код
	} else{

	    if(empty($_POST["edit"]))
	        $db->query( "INSERT INTO  " . PREFIX . "_promocodes (code, sale, term, comment, type, status) VALUES ('{$code}', '{$sale}', '{$term}', '{$comment}', '{$type}', '1')" );
	    else{

            $id = (int)$_POST["edit"];
            $status = (int)$_POST["status"];

	        $db->query( "UPDATE  " . PREFIX . "_promocodes SET code = '{$code}', sale = '{$sale}', term = '{$term}', comment = '{$comment}', type = '{$type}', status = '{$status}' WHERE id = '{$id}'" );
        }
    }




    header("Location: " . $_SERVER["HTTP_REFERER"]);
}




/**
 * @name сохранение настроек доставки
 */
if(!empty($_GET["config"]) && $_GET["config"] == "delivery"){

    if(empty($_POST["config"]["delivery_power"])) $_POST["config"]["delivery_power"] = "0";

    editConfig($_POST["config"]);

    // очищаем всю таблицу
    $db->query( "TRUNCATE TABLE  " . PREFIX . "_kylshop_delivery" );

    foreach ($_POST["marker_coords"] as $key => $marker_coords) {

        if(!empty($marker_coords)){

            $db->query( "INSERT INTO " . PREFIX . "_kylshop_delivery (marker_id, coords, title, description, status) VALUES
    ('{$_POST["marker_id"][$key]}', '{$marker_coords}', '{$_POST["marker_title"][$key]}', '{$_POST["marker_description"][$key]}', '1')" );

        }
    }

    header("Location: " . $_SERVER["HTTP_REFERER"]);
}

/**
 * @name сохранение городов доставки
 */
if(!empty($_GET["config"]) && $_GET["config"] == "delivery_city"){
    editConfig($_POST["config"]);
    header("Location: " . $_SERVER["HTTP_REFERER"]);
}

/**
 * @name сохранение методов
 */
if(!empty($_GET["config"]) && $_GET["config"] == "method"){

	$data = json_encode($_POST, JSON_PRETTY_PRINT | JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP | JSON_UNESCAPED_UNICODE);
	$file = ENGINE_DIR . "/modules/kylshop/method.json";
	file_put_contents($file, $data);
    header("Location: " . $_SERVER["HTTP_REFERER"]);
}

/**
 * @name сохранение дополнительных статусов
 */
if(!empty($_GET["config"]) && $_GET["config"] == "statuses"){

	$data = serialize($_POST);
	$file = ENGINE_DIR . "/modules/kylshop/statuses.txt";
	file_put_contents($file, $data);
    header("Location: " . $_SERVER["HTTP_REFERER"]);
}

/**
 * @name сохранение дополнительных товаров
 */
if(!empty($_GET["config"]) && $_GET["config"] == "addon"){

	$data = json_encode($_POST, JSON_PRETTY_PRINT | JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP | JSON_UNESCAPED_UNICODE);
	$file = ENGINE_DIR . "/modules/kylshop/addon.json";
	file_put_contents($file, $data);
    header("Location: " . $_SERVER["HTTP_REFERER"]);
}

/**
 * @name сохранение скидок
 */
if(!empty($_GET["config"]) && $_GET["config"] == "sale"){

	$data = json_encode($_POST, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP | JSON_UNESCAPED_UNICODE);
	$file = ENGINE_DIR . "/modules/kylshop/sale.json";
	file_put_contents($file, $data);
    header("Location: " . $_SERVER["HTTP_REFERER"]);
}


/**
 * @name создание полей формы оформления заказа
 */
if(!empty($_POST["create_fields"])){

    unset($_POST["create_fields"]);


    $data = json_encode($_POST, JSON_PRETTY_PRINT | JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP | JSON_UNESCAPED_UNICODE);

    $file = ENGINE_DIR . "/modules/kylshop/fields.json";

    $fp = fopen($file, "w");
    flock($file, LOCK_EX);
    fwrite($fp, $data);
    flock($file, LOCK_UN);

    header("Location: " . $_SERVER["HTTP_REFERER"]);
}


/**
 * @name изменение статуса
 */
if(!empty($_POST["edit_status"]) && !empty($_POST["id"]) && ctype_digit($_POST["id"])){

    $new_status = $_POST["edit_status"];

    if($new_status == "success") $new_status = "1";
    if($new_status == "moder") $new_status = "2";

    $order = $db->super_query( "SELECT * FROM " . PREFIX . "_kylshop_buy WHERE id = '{$_POST["id"]}'" );


    if(file_exists(ENGINE_DIR . "/modules/kylshop/statuses.txt") && filesize(ENGINE_DIR . "/modules/kylshop/statuses.txt") != 0) {

        $statuses = '';
        $statuses_data = unserialize(file_get_contents(ENGINE_DIR . "/modules/kylshop/statuses.txt"));

        $st = array_search($_POST["edit_status"], $statuses_data["status"]["name"]);
        if($st !== false){
            $new_status = $statuses_data["status"]["name"][$st];
            $status_template = $statuses_data["status"]["email"][$st];
        }
    }

    $db->query( "UPDATE " . PREFIX . "_kylshop_buy SET status='$new_status' WHERE id = '{$_POST["id"]}'" );

	$goods = json_decode($order["goods"], true);
	$data = json_decode($order["fields"], true);

	$cart_email = '<table style="width:100%;text-align:left;">
	<tr>
		<th>Наименование</th>
		<th>Кол-во</th>
		<th>Цена</th>
	</tr>';
	foreach ( $goods as $row ) {
		$cart_email .= '<tr>
			<td><a href="'.$row["link"].'">'.$row["title"].'</a></td>
			<td>'.$row["count"].'</td>
			<td>'.$row["price"].'</td>
		</tr>';
	}
	$cart_email .= '</table>';

	$form = '<ul style="list-style:none;">';
	foreach ( $data as $form_key => $datum ) {
		$form .= '<li><b>'.$form_key.':</b> '.$datum.'</li>';
	}
	$form .= '</ul>';

	$fields = json_decode($order["fields"], true);

	$method = '';
	if(!empty($fields["Доставка"])) $method = $fields["Доставка"];

	switch ($new_status){
		case "1": $new_status = 'Утвержден'; break;
		case "2": $new_status = 'Проверяется'; break;
		default: $new_status; break;
	}
	
	$search_body = [
		"{ID}",
		"{cart}",
		"{total}",
		"{method}",
		"{form}",
		"{date}",
		"{status}"
	];

	$replace_body = [
		$order["order_code"],
		$cart_email,
		$order["total"] . ' ' . $ks_config["currency"],
		$method,
		$form,
		date("d.m.Y H:i:s", $time),
		$new_status
	];


    $status_template = !empty($status_template) ? $status_template : $template_e["email_5"];
	$body = str_replace($search_body, $replace_body, $status_template);

	include_once (DLEPlugins::Check(ENGINE_DIR . '/classes/mail.class.php'));

	// отправляем письмо админу
	/*$email_admin = $db->super_query( "SELECT * FROM " . PREFIX . "_users where user_group='1' LIMIT 0,1" );
	$mail = new dle_mail( $config, 1 );
	$mail->send( $email_admin["email"], "Статус заказа {$order["order_code"]} изменен", $body );*/

	if(!empty($order["email"]))
	    $email = $order["email"];
	else{
	    $em = json_decode($order["fields"]);
        $email = $em->email;
    }

	// отправляем письмо покупателю
	if($email){

        $mail = new dle_mail( $config, 1 );
        $mail->send( $email, "Статус заказа {$order["order_code"]} изменен", $body );
	}

    echo "Статус изменен!<br>Уведомление отправлено клиенту.";
    exit;
}




/**
 * @name сохранение  общих настроек
 */
if(!empty($_GET["config"]) && $_GET["config"] == "template_email"){

$data = '<?php

$template_e = [
'.PHP_EOL;

$data .= '  "email_1" => \''.str_replace("'", "\'", $_POST["email_1"]).'\','.PHP_EOL;
$data .= '  "email_2" => \''.str_replace("'", "\'", $_POST["email_2"]).'\','.PHP_EOL;
$data .= '  "email_3" => \''.str_replace("'", "\'", $_POST["email_3"]).'\','.PHP_EOL;
$data .= '  "email_4" => \''.str_replace("'", "\'", $_POST["email_4"]).'\','.PHP_EOL;
$data .= '  "email_5" => \''.str_replace("'", "\'", $_POST["email_5"]).'\','.PHP_EOL;

	$data .= '
];';

	$file = ENGINE_DIR . "/modules/kylshop/template_email.php";
	file_put_contents($file, $data);
	header("Location: " . $_SERVER["HTTP_REFERER"]);

	editConfig($_POST["config"]);

	header("Location: " . $_SERVER["HTTP_REFERER"]);
}