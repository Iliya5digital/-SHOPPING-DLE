<?php
/**
 * @name принимаем пост параметры при создании или редактировании новости
 * @return $kylshop
 */
if (!defined('DATALIFEENGINE') OR !defined('LOGGED_IN')) {
    header("HTTP/1.1 403 Forbidden");
    header('Location: ../../');
    die("Hacking attempt!");
}

// подключаем функции
include (DLEPlugins::Check(ENGINE_DIR . '/modules/kylshop/init.php'));

$price = 0;
$kylshop = [];

// если товар включен
if(!empty($_POST["ks_power"])){

    $kylshop = [
        "power" => "1",
        "ks_title" => $_POST["ks_title"],
        "ks_price" => $_POST["ks_price"],
        "ks_group_price" => $_POST["ks_group_price"],
        "ks_group" => $_POST["ks_group"],
        "ks_variant_price" => $_POST["ks_variant_price"],
        "ks_variant_count" => $_POST["ks_variant_count"],
        "ks_sale" => $_POST["ks_sale"],
        "ks_sale_type" => $_POST["ks_sale_type"],
        "ks_count_goods" => $_POST["ks_count_goods"],
        "ks_count" => $_POST["ks_count"],
        "ks_count_goods_minus" => $_POST["ks_count_goods_minus"],
        "related_id" => implode(",", $_POST["related_id"]),
        "after_payment" => $_POST["after_payment"],
        "after_payment_post" => $_POST["after_payment_post"],
        "after_payment_group" => $_POST["after_payment_group"]
    ];

    $price = $_POST["ks_price"];

    $filter_post = "";
    $filter_price_post = [];
    $filter_images_post = [];
    $filter_color = [];

    // если есть фильтр
    if(!empty($_POST["ks_filter_power"])){

        $filter = json_decode(file_get_contents(ENGINE_DIR . '/modules/kylshop/filter.json'), true);

        $i = 0;
        foreach ($_POST as $key => $item) {
            if(strripos($key, "filter__") !== false){

                $key = substr(strstr($key, "__"), 2); // получаем чистый ключ
                
                //$filter_post .= $filter["title"][$key][0] . ":" . implode(",", $_POST["filter__".$key]) . "||";
                foreach ($_POST["filter__".$key] as $item_min) {
                    $filter_post .= $filter["title"][$key][0] . ":" . $item_min . ",";

                }
            }
            if(strripos($key, "filter_price_") !== false){

                $key = substr(strstr($key, "_"), 7); // получаем чистый ключ

                //$filter_post .= $filter["title"][$key][0] . ":" . implode(",", $_POST["filter__".$key]) . "||";
                foreach ($_POST["filter_price_".$key] as $k => $sum) {
                    if(!empty($sum)) $filter_price_post[$key."_".$k] = $sum;
                }
            }
            if(strripos($key, "filter_color_") !== false){

                array_push($filter_color, $_POST[$key]["val"] .','. $_POST[$key]["price"]);
            }
            if(strripos($key, "filter_img_") !== false){

                $key = explode("_", $key); // получаем чистый ключ
                $key = end($key);

                $is = 0;
                $resultImages = '';
                foreach ($_POST["filter_img_".$key] as $k => $images) {

                    if(!empty($images)){
                        $resultImages = '';
                        $fimg = explode("=", $_POST["filter_img_".$key][$i]);
                        foreach ($fimg as $item) {
                            $priceImg = '';
                            if(!empty($_POST["filter_priceimg_".$key][$is])) $priceImg = '|+'.$_POST["filter_priceimg_".$key][$is];
                            $resultImages .= $filter["title"][$key][0] . ":" . $item.$priceImg . ",";
                            $is++;
                        }
                    }
                }

                $filter_post .= $resultImages;
            }
        }

        $filter_post = trim($filter_post, ",");

        $filter_post .= !empty($filter_color) ? '**'.implode(";", $filter_color) : '';
        
        if(!empty($filter_price_post)) $filter_post = $filter_post."||".json_encode($filter_price_post);
        //if(!empty($filter_images_post)) $filter_post = $filter_post."||".json_encode($filter_images_post);
    }

    // 1+1
	if(!empty($_POST["one_plus_one"])){

		$one_plus_one = [];
		foreach ( $_POST["one_plus_one"] as $time ) {
			if(!empty($time[0] && !empty($time[1])))
				$one_plus_one[] = [$time[0], $time[1]];
		}
		$kylshop["one_plus_one"] = $one_plus_one;
	}

    // дополнительные товары
	if(!empty($_POST["addon"])) $kylshop["addon"] = $_POST["addon"];

}

$kylshop = serialize($kylshop);
$kylshop_keys = !empty($_POST["pay_keys"]) ? trim($_POST["pay_keys"]) : '';