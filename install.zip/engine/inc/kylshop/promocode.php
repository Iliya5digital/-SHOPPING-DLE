<?php
/**
 * @name промо-коды
 */
if (!defined('DATALIFEENGINE') OR !defined('LOGGED_IN')) {
	header("HTTP/1.1 403 Forbidden");
	header('Location: ../../');
	die("Hacking attempt!");
}

if ($member_id['user_group'] != 1) msg("error", $lang['index_denied'], $lang['index_denied']);



$result_count = $db->super_query( "SELECT COUNT(*) as count FROM " . PREFIX . "_promocodes");

$start_from = @ceil( $result_count['count'] / 25 );
if(isset($_GET["page"])) $page = $_GET['page'] - 1;
else $page = 0;

$start_select = abs($page * 25);

if($result_count['count'] > 25){

	$previous = $config["http_home_url"] . $config["admin_path"] . "?mod=kylshop&act=promocode";

	$pagination = '<ul class="pagination">';

	for ($i = 1; $i <= $start_from; $i++) {

		if($i == 1){

			if(isset($_GET["page"]) && $_GET["page"] != 1 && $_GET["page"] != 2)
				$pagination .= '<li><a href="'.$previous.'&page='.($_GET["page"]-1).'">&laquo;</a></li>';
			else
				$pagination .= '<li><a href="'.$previous.'">&laquo;</a></li>';
		} else{

			if($_GET["page"] == $i) $pagination .= '<li><a href="'.$previous.'&page='.$i.'" class="active">'.$i.'</a></li>';
			else $pagination .= '<li><a href="'.$previous.'&page='.$i.'">'.$i.'</a></li>';
		}
	}

	if(!isset($_GET["page"]))
		$pagination .= '<li><a href="'.$previous.'&page=2">&raquo;</a></li>';
	else if(isset($_GET["page"]) && $_GET["page"] != ($i-1))
		$pagination .= '<li><a href="'.$previous.'&page='.($_GET["page"]+1).'">&raquo;</a></li>';
	else
		$pagination .= '<li><a href="'.$previous.'&page='.($start_from).'">&raquo;</a></li>';

	$pagination .= '</ul>';

} else{

	$pagination = "";
}

$codesRow = $db->super_query( "SELECT * FROM " . PREFIX . "_promocodes ORDER BY id DESC LIMIT " . $start_select . ", 25", true );

$codes = '';

foreach ( $codesRow as $row ) {

	$sale = (strripos($row["sale"], "%") !== false) ? '<span class="percent">' . $row["sale"] . '</span>' : $row["sale"] . ' ' . $ks_config["currency"];

	// 0 - активирован
	// 1 - активен

	$status = '<span class="code_active">Активен</span>';
	$status_ = 'Активен';
	if($row["status"] == '0'){
	    $status = '<span class="code_activated">Активирован</span>';
        $status_ = 'Активирован';
    }
	if($row["status"] == '2'){
	    $status = '<span class="code_no_activate">Не активный</span>';
        $status_ = 'Не активный';
    }
	else if($row["term"] < time() && $row["status"] == '1') $status = '<span class="code_expired">Просрочен</span>';

	$left = round(($row["term"] - time()) / (60 * 60 * 24));
	if($left < 0) $left = 0;

	$type = '<span class="type_0"></span>';
	if(!empty($row["type"])) $type = '<span class="type_1"></span>';

	$comment = '';
	if(!empty($row["comment"])) $comment = '<span class="promo_comment">'.$row["comment"].'</span>';

	$codes .= '<tr>
	    <td class="col-xs-4 col-sm-4 col-md-4 text-left">
	        <b>'.$row["code"].'</b>
	        <input type="text" id="code_'.$row["id"].'" class="inp_hid" value="'.$row["code"].'">
	        <a href="#" class="copy_code"></a>
	        '.$comment.'
	    </td>
	    <td class="col-xs-1 col-sm-1 col-md-1 text-left"><b>'.$sale.'</b></td>
	    <td class="col-xs-2 col-sm-2 col-md-2 text-left">
	        <p class="date">'.date("d.m.Y H:i:s", $row["term"]).'</p>
	        <span class="left_day">(осталось: '.$left.' дней)</span>
	    </td>
	    <td class="col-xs-1 col-sm-1 col-md-1 text-left">'.$type.'</td>
	    <td class="col-xs-2 col-sm-2 col-md-2 text-left">'.$status.'</td>
	    <td class="col-xs-1 col-sm-1 col-md-1 text-left">'.$row["count_pay"].'</td>
	    <td class="col-xs-2 col-sm-2 col-md-2 text-left"><b>'.$row["summ"].' '.$ks_config["currency"].'</b></td>
	    <td class="col-xs-1 col-sm-1 col-md-1 text-center">
	    	<input type="checkbox" name="code_edit['.$row["id"].']" class="code_edit">
	        <a href="#" class="fa fa-pencil edit_code" data-id="'.$row["id"].'" data-status="'.$status_.'" data-currency="'.$ks_config["currency"].'"></a>
	        <a href="#" class="fa fa-times delete_code" data-id="'.$row["id"].'"></a>
	    </td>
	</tr>';
}



echo '<div class="panel-heading">
    <ul class="nav nav-tabs nav-tabs-solid">
        <li class="active"><a href="#list_codes" data-toggle="tab"><i class="fa fa-list position-left"></i> Список кодов</a></li>
        <li><a href="#add_codes" data-toggle="tab"><i class="fa fa-plus" aria-hidden="true"></i> Создание промо-кодов</a></li>
    </ul>
    <div class="heading-elements">
        <ul class="icons-list">
            <li><a href="#" class="panel-fullscreen"><i class="fa fa-expand"></i></a></li>
        </ul>
    </div>
</div>

<div class="form-horizontal">
    <div class="panel-tab-content tab-content">
    
        <div class="tab-pane active" id="list_codes">
        	<form action="?mod=kylshop&act=settings&config=action_promo" method="POST">
	            <table class="table table-striped">
	                <tr>
	                    <th class="col-xs-4 col-sm-4 col-md-4 text-left">Промо-код</th>
	                    <th class="col-xs-1 col-sm-1 col-md-1 text-left">Скидка</th>
	                    <th class="col-xs-2 col-sm-2 col-md-2 text-left">Действует до</th>
	                    <th class="col-xs-1 col-sm-1 col-md-1 text-left text-center">Вечный</th>
	                    <th class="col-xs-2 col-sm-2 col-md-2 text-left">Статус</th>
	                    <th class="col-xs-1 col-sm-1 col-md-1 text-left">Кол-во покупок</th>
	                    <th class="col-xs-2 col-sm-2 col-md-2 text-left">Сумма</th>
	                    <th class="col-xs-1 col-sm-1 col-md-1 text-right pr">
	                        <input type="checkbox" name="" id="select_code_edit"> Действие
	                    </th>
	                </tr>
	                '.$codes.'
	            </table>
	            <div class="panel-footer">
		            <div class="pull-left">
		                
		            </div>
		            <div class="pull-right">
		                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input class="btn bg-teal btn-sm btn-raised legitRipple" type="submit" value="Выполнить">
		            </div>
		            <div class="pull-right">
		                <select name="action_code" id="" class="uniform position-left">
		                    <option value="0">-- Действие --</option>
		                    <option value="delete">Удалить</option>
		                </select>
		            </div>
		        </div>
	            '.$pagination.'
            </form>
        </div>
    
        <div class="tab-pane" id="add_codes">
            <form action="?mod=kylshop&act=settings&config=create_promo" method="POST" class="pad">
            	<br>
            	<div class="row">
			        <div class="col-lg-3 col-md-6">
			            <label>Код:</label>
			            <i class="help-button visible-lg-inline-block text-primary-600 fa fa-question-circle position-right" data-rel="popover" data-trigger="hover" data-placement="right" data-content="Укажите свой код или оставьте поле пустым для автоматической генерации. Если ввести просто цифру, например 7, то будет создан промо-код из 7-ми символов. Максимум 255 символов." data-original-title="" title=""></i>
			            <input type="text" name="promo_code" class="form-control" autocomplete="off">
			        </div>
			        <div class="col-lg-3 col-md-6">
			            <label>Скидка:</label>
			            <i class="help-button visible-lg-inline-block text-primary-600 fa fa-question-circle position-right" data-rel="popover" data-trigger="hover" data-placement="right" data-content="Укажите просто сумму, например 500 или процент скидки, например 20%" data-original-title="" title=""></i>
			            <input type="text" name="promo_sale" class="form-control" autocomplete="off" required>
			        </div>
			        <div class="col-lg-3 col-md-6">
			            <label>Действует до:</label>
			            <input data-rel="calendar" type="text" name="promo_term" class="form-control" autocomplete="off">
			        </div>
			        <div class="col-lg-3 col-md-6">
			            <label>Кол-во:</label>
			            <input type="text" name="promo_count" class="form-control" value="1" autocomplete="off">
			        </div>
			        <div class="col-lg-3 col-md-6">
			        	<br>
			            <label>Комментарий:</label>
			            <textarea name="promo_comment" class="form-control" rows="5"></textarea>
			        </div>
			        <div class="col-lg-3 col-md-6 status_">
			            <br>
			            <label>Статус:</label>
			            <select name="status" class="form-control">
			                <option value="0">Активирован</option>
			                <option value="1">Активен</option>
			                <option value="2">Не активный</option>
                        </select>
			        </div>
			        <div class="col-lg-3 col-md-6">
			        	<br>
			            <label>Вечный:</label>
			            <input type="checkbox" name="type" value="1">
			        </div>
			    </div>
			    <br>
			    <button type="submit" class="btn bg-slate-600 btn-sm btn-raised position-left legitRipple"><i class="fa fa-fire position-left"></i>Создать</button>
            </form>
        </div>
        
    </div>
</div>';