<?php
/**
 * @name вкладка МАГАЗИН при добавлении и редактировании новости
 */
if (!defined('DATALIFEENGINE') OR !defined('LOGGED_IN')) {
    header("HTTP/1.1 403 Forbidden");
    header('Location: ../../');
    die("Hacking attempt!");
}

include_once (DLEPlugins::Check(ENGINE_DIR . '/modules/kylshop/init.php'));


$filter_img = '';
$related_goods = '<div class="form-group">
    <label class="control-label col-sm-2">Похожие товары:</label>
    <div class="col-sm-10">
        <div class="related_title">
            <input type="text" class="form-control width-550 position-left" name="ks_related[]" maxlength="250" autocomplete="off">
            <input type="hidden" class="related_id" name="related_id[]">
            <a href="#" class="fa fa-remove c_red remove_related" aria-hidden="true" title="Удалить товар"></a>
            <a href="#" class="fa fa-plus add_related" aria-hidden="true" title="Добавить товар"></a>
        </div>
    </div>
</div>';

/**
 * @name добавление новости
 */
if ($_GET["mod"] == "addnews") {

    $count_buy = 0;
    //$ks_power = $ks_title = $ks_price = $ks_sale = $ks_count = $ks_count_goods = $ks_count_goods_display = $is_goods = $ks_filter_power = "";
    $ks_sale_type = '<option value="%">%</option>
    <option value="fix">цена</option>';
    $ks_count_goods_minus = " checked";


/**
* @name редактирование новости
*/
} else {
    
    if(!empty($row["kylshop"])){

        $kylshop = unserialize($row["kylshop"]);
        if(!empty($row["filter"])) $ks_filter_power = " checked";

        // если похожие товары найдены
        if(!empty($kylshop["related_id"])){
            
            $related_ids = explode(",", $kylshop["related_id"]);

            $where = '';
            foreach ($related_ids as $rid) {
                $where .= "id = '{$rid}' OR ";
            }
            $where = substr($where, 0, -4);
            $news_rel = $db->super_query("SELECT id, title FROM " . PREFIX . "_post WHERE " . $where . " GROUP BY id", true);

            $related_goods = '<div class="form-group">
                    <label class="control-label col-sm-2">Похожие товары:</label>
                    <div class="col-sm-10">';

            foreach ($news_rel as $related_id) {

                $related_goods .= '<div class="related_title">
                    <input type="text" class="form-control width-550 position-left" name="ks_related[]" value="'.$related_id["title"].'" maxlength="250" autocomplete="off">
                    <input type="hidden" class="related_id" name="related_id[]" value="'.$related_id["id"].'">
                    <a href="#" class="fa fa-remove c_red remove_related" aria-hidden="true" title="Удалить товар"></a>
                    <a href="#" class="fa fa-plus add_related" aria-hidden="true" title="Добавить товар"></a>
                </div>';
            }

            $related_goods .= '</div>
                </div>';
        }

        if(is_array($kylshop)){

            $is_goods = '';
            $ks_power = '';
            if($kylshop["power"] == true){
                $ks_power = " checked";
                $is_goods = ' style="display: block;"';
            }
            if(!empty($kylshop["ks_count_goods"])){
                $ks_count_goods = " checked";
                $ks_count_goods_display = ' style="display: block;"';
            }
            if(!empty($kylshop["ks_count_goods_minus"])) $ks_count_goods_minus = " checked";
            $ks_title = $kylshop["ks_title"];
            $ks_price = $kylshop["ks_price"];
            $ks_sale = $kylshop["ks_sale"];
            $ks_count = $kylshop["ks_count"];

            //$count_buy = $kylshop["ks_count"];

            $fix = " checked";
            if($kylshop["ks_sale_type"] == "fix") $fix = " selected";
            $ks_sale_type = '<option value="%">%</option>
            <option value="fix"'.$fix.'>цена</option>';

        } else{

            $count_buy = 0;
            $ks_sale_type = '<option value="%">%</option>
            <option value="fix">цена</option>';
            $ks_count_goods_minus = " checked";
        }

    } else{

        $ks_power = "";
        $ks_sale_type = '<option value="%">%</option>
            <option value="fix">цена</option>';
    }

}


// группы пользователей
$groups_sourse = $db->super_query( "SELECT id, group_name FROM " . PREFIX . "_usergroups WHERE id != 5", true );
$groups = '';
foreach ($groups_sourse as $item) {
    if($kylshop["after_payment_group"] == $item["id"])
        $groups .= '<option value="'.$item["id"].'" selected>'.$item["group_name"].'</option>';
    else
        $groups .= '<option value="'.$item["id"].'">'.$item["group_name"].'</option>';
}

$group_prices = '';
if(!empty($kylshop["ks_group"])){

    foreach ($kylshop["ks_group"] as $id => $item) {

        $group_prices .= '<div class="fx">
            <div>
                <input type="text" class="form-control position-left" style="width: 155px;" name="ks_group_price[]" value="'.$kylshop["ks_group_price"][$id].'" placeholder="Цена для группы" maxlength="50">
            </div>
            <div>
                <select name="ks_group[]" class="uniform">
                    <option value="">-- Выберете группу --</option>';

        foreach ($groups_sourse as $item2) {
            if($item == $item2["id"])
                $group_prices .= '<option value="'.$item2["id"].'" selected>'.$item2["group_name"].'</option>';
            else
                $group_prices .= '<option value="'.$item2["id"].'">'.$item2["group_name"].'</option>';
        }

        $group_prices .= '</select>
            </div>
            <a href="#" class="fa fa-remove c_red remove_group"></a>
        </div>';
    }
}

$variant_prices = '';
if(!empty($kylshop["ks_variant_price"])){

    foreach ($kylshop["ks_variant_price"] as $id => $item) {

        $variant_prices .= '<div class="fx">
            <div>
                <input type="text" class="form-control position-left" style="width: 155px;" name="ks_variant_price[]" value="'.$kylshop["ks_variant_price"][$id].'" placeholder="Новая цена" maxlength="50">
            </div>
            <div>
                <input type="text" class="form-control position-left" style="width: 155px;" name="ks_variant_count[]" value="'.$kylshop["ks_variant_count"][$id].'" placeholder="Если кол-во >= чем" maxlength="50">
            </div>
            <a href="#" class="fa fa-remove c_red remove_variant"></a>
        </div>';
    }
}

// группы
echo '<script>
let groups = \''.$groups.'\';
</script>';



// 1+1
$one_plus_one = '';
if($ks_config["one_plus_one"] == true){

	$one_plus_one = '<div class="form-group">
        <label class="control-label col-sm-2">Счастливые часы:</label>
        <div class="col-sm-10">
            <p>Часы активации: <a href="#" class="fa fa-plus add_one_plus_one"></a></p>
            <div class="description_min">В указанное время к одной позиции будет прибавляться вторая позиция бесплатно.</div>
            <div class="one_plus_one">';

	if(!empty($kylshop["one_plus_one"])){

		$i = 1;
		foreach ( $kylshop["one_plus_one"] as $one_plus_one_datum ) {

			$start = (!empty($one_plus_one_datum[0])) ? $one_plus_one_datum[0] : '';
			$finish = (!empty($one_plus_one_datum[1])) ? $one_plus_one_datum[1] : '';

			$one_plus_one .= '<div>
                    с: <input type="text" name="one_plus_one['.$i.'][]" class="form-control time_select" style="width: 50px;" value="'.$start.'"> &nbsp;&nbsp;&nbsp;
                    до: <input type="text" name="one_plus_one['.$i.'][]" class="form-control time_select" style="width: 50px;" value="'.$finish.'">
                    <a href="#" class="fa fa-remove remove_one_plus_one"></a>
				</div>';
			$i++;
		}
	}

			$one_plus_one .= '</div>
		</div>
    </div>';
}



$addon = '';
if(file_exists(ENGINE_DIR . "/modules/kylshop/addon.json")) {

	$addon_data = json_decode(file_get_contents(ENGINE_DIR . "/modules/kylshop/addon.json"), true);

	if(!empty($addon_data)){

		$addon = '<div class="form-group">
            <label class="control-label col-sm-2">Дополнительные товары:</label>
            <div class="col-sm-10">
            <select name="addon_goods" id="addon_goods" onchange="onCategoryChange(this)" class="categoryselect">
            	<option value="" data-price="0" data-image="">Добавить новый товар</option>';

		foreach ( $addon_data["addon_name"] as $addon_key => $addon_datum ) {

			$addon .= '<option value="'.$addon_datum.'" data-price="'.$addon_data["addon_price"][$addon_key].'" data-image="'.$addon_data["addon_image"][$addon_key].'">'.$addon_datum.'</option>';
		}

		$addon .= '</select>
				<a href="#" class="fa fa-plus add_addon"></a>
				<div class="clr"></div>
				<br>
				<div id="addons" style="max-width:700px;">';

		if(!empty($kylshop["addon"])){

			foreach ( $kylshop["addon"]["name"] as $addon_key => $addon_item ) {

				$addon .= '<div class="row pr">
						<div class="col-sm-4">
							<input type="text" name="addon[name][]" class="form-control" value="'.$addon_item.'">
						</div>
						<div class="col-sm-3">
							<input type="text" name="addon[price][]" class="form-control" value="'.$kylshop["addon"]["price"][$addon_key].'">
						</div>
						<div class="col-sm-5">
							<input type="text" name="addon[image][]" class="form-control" value="'.$kylshop["addon"]["image"][$addon_key].'">
						</div>
						<a href="#" class="fa fa-remove c_red remove_addon"></a>
					</div>';
			}

		}

		$addon .= '</div>
			</div>
        </div>';
	}
}




// вывод на экран
echo '<div class="row">

    <div class="checkbox">
        <label><input class="icheck" type="checkbox" id="ks_power" name="ks_power" value="1"'.$ks_power.'> Сделать платным</label>
    </div>

    <div class="is_goods"'.$is_goods.'>
    
        <div class="form-group">
            <label class="control-label col-sm-2">Название товара:</label>
            <div class="col-sm-10">
                <input type="text" class="form-control width-550 position-left" name="ks_title" id="ks_title" value="'.$ks_title.'" maxlength="250">
                <a href="#" id="source_title" class="fa fa-reply" aria-hidden="true" title="Взять из названия новости"></a>
            </div>
        </div>
        
        <div class="form-group">
            <label class="control-label col-sm-2">Цена:</label>
            <div class="col-sm-10">
            
                <div class="fx">
                    <div>
                        <input type="text" class="form-control position-left" style="width: 155px;" name="ks_price" id="ks_price" value="'.$ks_price.'" maxlength="50">
                    </div>
                    <div>
                        <label for="ks_sale">Скидка:</label>
                        <input type="text" class="form-control position-left" style="width: 55px;" name="ks_sale" id="ks_sale" value="'.$ks_sale.'" maxlength="10">
                    </div>
                    <div>
                        <label for="sale_type">Тип скидки:</label>
                        <select name="ks_sale_type" id="ks_sale_type" class="uniform">
                            '.$ks_sale_type.'
                        </select>
                        <a href="#" class="add_price"><span class="fa fa-plus"></span> добавить цену</a> | 
                        <a href="#" class="add_variant"><span class="fa fa-plus"></span> добавить условие</a>
                    </div>
                </div>
                
                <br>
                <div class="group_prices">
                    '.$group_prices.'
                </div>
                
                <br>
                <div class="variant_prices">
                    '.$variant_prices.'
                </div>
                
                
            </div>
        </div>
        
        <div class="form-group">
            <label class="control-label col-sm-2">Количество:</label>
            <div class="col-sm-10">
            
                <div class="checkbox">
                    <label><input class="icheck" type="checkbox" id="ks_count_goods" name="ks_count_goods" value="1"'.$ks_count_goods.'> Задать кол-во</label>
                </div>
                
                <div id="count_goods"'.$ks_count_goods_display.'>
                    
                    <div class="fx">
                        <div>
                            <label for="ks_sale">Количество:</label>
                            <input type="text" class="form-control position-left" style="width: 80px;" name="ks_count" id="ks_count" value="'.$ks_count.'" maxlength="10">
                        </div>
                        <div class="checkbox" style="margin-top: 5px;">
                            <label><input class="icheck" type="checkbox" id="ks_count_goods_minus" name="ks_count_goods_minus" value="1"'.$ks_count_goods_minus.'> Отнимать кол-во после покупки</label>
                        </div>
                    </div>
                    
                </div>
                
            </div>
        </div>
        
        <!-- Фильтры -->
        <div class="form-group">
            <label class="control-label col-sm-2">Фильтры:</label>
            <div class="col-sm-10">
            
                <div class="checkbox">
                    <label><input class="icheck" type="checkbox" id="ks_filter_power" name="ks_filter_power" value="1"'.$ks_filter_power.'> вкл.</label>
                </div>
                
                <div id="filter">
                    
                    <div class="fx">';


$filter_file = ENGINE_DIR . '/modules/kylshop/filter.json';
$filter = file_get_contents($filter_file);
$fields = "";
$filter_colors = [];

// перебираем поля
if(!empty($filter)){

    $filter_source = explode("||", $row["filter"]);
    if(strripos($filter_source[0], "**") !== false){
        $filter_colors_ = explode("**", $filter_source[0]);
        $filter_source[0] = $filter_colors_[0];
        $filter_colors_ = explode(";", $filter_colors_[1]);
        foreach ($filter_colors_ as $c) {
            $c = explode(",", $c);
            $filter_colors[$c[0]] = $c[1];
        }
    }
    $filter_prices = json_decode($filter_source[1], true);

    // если фильтр был задан
    if(!empty($filter_source[0])){
        $filter_row = explode(",", $filter_source[0]);
        $filter_data = [];
        foreach ($filter_row as $item2) {
            $exp = explode(":", $item2);
            if(!empty($exp[1])) $filter_data[$exp[0]][] = $exp[1];
        }
    }


    $filter = json_decode($filter, true);


    foreach ($filter["title"] as $key => $row1) {

        $selectedCats = '';
        if(!empty($filter["categories"][$key])){

            $selectedCats = ' filter_cat';
            foreach ($filter["categories"][$key] as $category) {
                $selectedCats .= ' filter_cat_'.$category;
            }
        }

        echo '<div class="w33'.$selectedCats.'">
            <label for="filter_color">'.$row1[0].'</label>
            <ul>';
        
        if(!empty($filter["img"][$key])){

            $imagesResult = '';
            $filter_img = '';

            if(!empty($filter_data[$row1[0]])){

                foreach ($filter_data[$row1[0]] as $filter_datum) {

                    $is = 0;
                    
                    $imagesDatum = explode("|+", $filter_datum);
                    $priceImg = !empty($imagesDatum[1]) ? $imagesDatum[1] : '';

                    $imagesResult .= '<div class="f_img">
                        <img src="'.$imagesDatum[0].'" alt="">
                        <input type="text" class="form-control img_price" name="filter_priceimg_'.$key.'[]" value="'.$priceImg.'" placeholder="добавить к цене">
                        <a href="#" class="delete_img"></a>
                    </div>';

                    $filter_img .= $imagesDatum[0]."=";

                    $is++;
                }
                $filter_img = trim($filter_img, "=");
            }


            echo '<li>
                <div class="FileUploadProgress"><span></span><p></p></div>
                <label for="upload_files_'.$key.'" class="upload_files" data-placement="top">+ фото
                    <input type="file" multiple="" name="" data-id="'.$key.'" id="upload_files_'.$key.'" class="upload_inp">
                </label>
                <div class="f_images">
                    '.$imagesResult.'
                </div>
                <input type="text" name="filter_img_'.$key.'[]" class="form-control filter_price" value="'.$filter_img.'">
            </li>';

        } else if(!empty($filter["color"][$key])){

            $filter_color = '';

            if(!empty($filter_colors)){

                $colorI = 0;
                foreach ($filter_colors as $f_color => $f_price) {
                    $filter_color .= '<div class="box_color">
                        <div class="colorHelp" id="c_'.$colorI.'" style="background:'.$f_color.'"></div>
                        <input type="text" name="filter_color_'.$colorI.'[val]" class="form-control colorPicker" value="'.$f_color.'" placeholder="цвет">
                        <input type="text" name="filter_color_'.$colorI.'[price]" class="form-control" value="'.$f_price.'" placeholder="+ цена">
                    </div>';
                    $colorI++;
                }
            }

            echo '<li>
                <a href="#" class="add_color" data-id="'.$key.'">+ цвет</a>
                <div class="f_colors">
                    '.$filter_color.'
                </div>
            </li>';

        } else{

            $i = 0;
            foreach ($filter["value"][$key] as $row2) {

                $price_show = $filter_price = '';
                if(!empty($filter_prices[$key."_".$i])){
                    $price_show = ' style="display: inline-block;"';
                    $filter_price = $filter_prices[$key."_".$i];
                }

                $checked = "";
                if(!empty($row["filter"]) && !empty($filter_data[$row1[0]]) && array_search($row2, $filter_data[$row1[0]]) !== false) $checked = ' checked';

                echo '<li>
                    <div class="checkbox">
                        <label><input class="icheck check_filter" type="checkbox" name="filter__'.$key.'[]" value="'.$row2.'"'.$checked.'> '.$row2.'</label>
                        <input type="text" name="filter_price_'.$key.'[]" class="form-control filter_price"'.$price_show.' value="'.$filter_price.'">
                    </div>
                </li>';

                $i++;
            }
        }


        echo '</ul>
        </div>';

    }
}


$pay_keys = '';

if(!empty($ks_config["pay_keys"])){

    $pay_keys = '<div class="form-group">
        <label class="control-label col-sm-2">Ключи:</label>
        <div class="col-sm-10">
        
            <div class="row">
                <div class="col-sm-12">
                    <textarea name="pay_keys" id="pay_keys" class="form-control" rows="10">'.$row["keys"].'</textarea>
                    <p class="description_min">Каждый ключ с новой строки</p>
                </div>
            </div>
            
        </div>
    </div>';
}

                    echo '</div>

                    <p class="description">Если оставить поле цены пустым, то на сайте цена будет указана по умолчанию.</p>
                    
                </div>
                
                <!--<select name="ks_filter_start" id="ks_filter_start" class="uniform" style="width: 100%; max-width: 350px;">
                    <option value="color">Цвет</option>
                    <option value="type">Тип</option>
                </select>-->
                
            </div>
        </div>
        <!-- Фильтры .-->
        
        
        <!-- 1+1 -->
        '.$one_plus_one.'
        <!-- 1+1 .-->
        
        <!-- Дополнительные товары -->
        '.$addon.'
        <!-- Дополнительные товары .-->
        
        <!-- Похожие товары -->
        '.$related_goods.'
        
        <!-- Продажа промокодов -->
        '.$pay_keys.'
        
        <br><br>
        
        <!-- Действия после оплаты -->
        <div class="form-group">
            <label class="control-label col-sm-2">После оплаты:</label>
            <div class="col-sm-10">
            
                <div class="row">
                    <div class="col-sm-6">
                        <label for="after_payment">Содержимое, будет показано после оплаты, тег <b>{product}</b>:</label>
                        <textarea name="after_payment" id="after_payment" class="form-control" rows="4">'.$kylshop["after_payment"].'</textarea>
                        <p class="description_min">Если оставить пустым, никаких изменений в товаре происходить не будет. Пользователь сможет купить товар повторно. Можно использовать html.</p>
                    </div>
                    <div class="col-sm-6">
                        <label for="after_payment">Отправить на почту (не работает):</label>
                        <textarea name="after_payment_post" id="after_payment_post" class="form-control" rows="4">'.$kylshop["after_payment_post"].'</textarea>
                        <p class="description_min">Если оставить пустым, сообщение на почту отправляться не будет. Можно использовать html.</p>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-sm-5">
                        <label for="after_payment">Переводить в группу: &nbsp;&nbsp;</label>
                        <select name="after_payment_group" id="after_payment_group" class="uniform">
                            <option value="">-- Выбрать --</option>
                            '.$groups.'
                        </select>
                    </div>
                </div>
                
            </div>
        </div>
        
        <!--<div class="form-group">
            <label class="control-label col-sm-2">Кол-во покупок:</label>
            <div class="col-sm-10">
                <b>'.$count_buy.'</b>
                <input type="text" class="form-control position-left" style="width: 55px;" name="ks_count_buy" id="ks_count_buy" value="'.$count_buy.'" maxlength="50" title="Сколько раз купили этот товар">
            </div>
        </div>-->
    </div>
    
</div>


<link href="engine/skins/kylshop/spectrum.min.css" rel="stylesheet" type="text/css">
<script src="engine/skins/kylshop/spectrum.min.js"></script>
<link href="engine/skins/kylshop/addnews.css" rel="stylesheet" type="text/css">
<script src="engine/skins/kylshop/addnews.js"></script>';