<?php
/**
 * @name список заказов
 */
if (!defined('DATALIFEENGINE') OR !defined('LOGGED_IN')) {
	header("HTTP/1.1 403 Forbidden");
	header('Location: ../../');
	die("Hacking attempt!");
}

if ($member_id['user_group'] != 1) msg("error", $lang['index_denied'], $lang['index_denied']);

// если включена настройка
if($ks_config["notification"] == true){

	// если есть куки о последней покупке
	if(!empty($_COOKIE["new_orders"])){

		$new_orders = explode(",", $_COOKIE["new_orders"]);
		sort($new_orders);

		$where = '(';
		if(count($new_orders) > 1){
			foreach ( $new_orders as $new_order ) {
				$new_order = trim($new_order);
				$where .= "id = '{$new_order}' OR ";
			}
		}
		$end_order = trim(end($new_orders));
		$where .= "id > '{$end_order}') AND `see` != '1'";

		// получаем все новые заказы от указаного
		$orders = $db->super_query("SELECT id, order_id, order_code, total, time FROM " . PREFIX . "_kylshop_buy WHERE {$where} ORDER BY id ASC", true);

		if(!empty($orders)){

			array_push($orders, ["currency" => $ks_config["currency"]]);
			echo json_encode($orders, JSON_UNESCAPED_UNICODE);
		}

	} else{

		// получаем последний заказ если он есть и заносим в память
		$orders = $db->super_query("SELECT id, order_id, order_code, total, time FROM " . PREFIX . "_kylshop_buy ORDER BY id DESC");

		SetCookie("new_orders", $orders["id"], time() + 3600 * 24 * 7, "/");
	}
}

exit;