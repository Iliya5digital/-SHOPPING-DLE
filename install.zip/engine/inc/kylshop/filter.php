<?php
/**
 * @name фильтр
 */
if (!defined('DATALIFEENGINE') OR !defined('LOGGED_IN')) {
    header("HTTP/1.1 403 Forbidden");
    header('Location: ../../');
    die("Hacking attempt!");
}

$filter_file = ENGINE_DIR . '/modules/kylshop/filter.json';

if(!empty($_POST["save_filter"])){

    // сохраняем фильтра
    $fp = fopen($filter_file, "w");
    flock($fp, LOCK_EX);
    fwrite($fp, json_encode($_POST, JSON_PRETTY_PRINT | JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP | JSON_UNESCAPED_UNICODE));
    flock($fp, LOCK_UN);

    header("Location: " . $_SERVER["HTTP_REFERER"]);

}

$filter = file_get_contents($filter_file);
$fields = '<script>
    $(function(){
        $(".categoryselect").chosen();
    })
</script>';

$categories_list = CategoryNewsSelection( 0, 0 );

// перебираем поля
if(!empty($filter)){

    $filter = json_decode($filter, true);

    foreach ($filter["title"] as $key => $row) {


        $selectedCats = '';
        if(!empty($filter["categories"][$key])) $selectedCats = implode(",", $filter["categories"][$key]);

        $fields .= '<div class="row">
            <div class="col-md-6 cats_filter">
                <select name="categories['.$key.'][]" data-selected="'.$selectedCats.'" data-placeholder="Выберете" class="categoryselect" multiple style="width:100%;max-width:350px;">
                    '.$categories_list.'
                </select>
            </div>
            <div class="col-md-6 fields_filter">
                <input type="text" name="title['.$key.'][]" class="form-control" value="'.$row[0].'" placeholder="Название фильтра"><a href="#" class="fa fa-remove remove_filter"></a>
            </div>
            <div class="col-md-6 fields">';


        if(count($filter["value"][$key]) > 0){

            foreach ($filter["value"][$key] as $rows) {
                $fields.= '<input type="text" name="value['.$key.'][]" class="form-control" value="'.$rows.'" placeholder="Значение"><a href="#" class="fa fa-remove remove_field"></a>';
            }

        } else $fields.= '<input type="text" name="value['.$key.'][]" class="form-control" placeholder="Значение"><a href="#" class="fa fa-remove remove_field"></a>';


        $isSlider = !empty($filter["slider"][$key]) ? ' checked' : '';
        $isImg = !empty($filter["img"][$key]) ? ' checked' : '';
        $isColor = !empty($filter["color"][$key]) ? ' checked' : '';

        $sliderStep = !empty($filter["slider_step"][$key][0]) ? $filter["slider_step"][$key][0] : '';

        $fields.= '<a href="#" class="fa fa-plus add_val" data-unique_id="'.$key.'"></a>
            </div>
            <div class="col-md-6 slider_filter">
                <input class="switch" type="checkbox" name="slider['.$key.'][]" id="is_slider_'.$key.'"'.$isSlider.' value="1" data-switchery="true"> &nbsp; 
                <label for="is_slider_'.$key.'"><b>слайдер</b></label>
                 с шагом: <input type="number" name="slider_step['.$key.'][]" min="1" value="'.$sliderStep.'" class="form-control" style="width:40px">
            </div>
            <div class="col-md-3 img_filter">
                <input class="switch" type="checkbox" name="color['.$key.'][]" id="is_color_'.$key.'"'.$isColor.' value="1" data-switchery="true"> &nbsp; 
                <label for="is_color_'.$key.'"><b>цвет</b></label>
            </div>
            <div class="col-md-3 img_filter">
                <input class="switch" type="checkbox" name="img['.$key.'][]" id="is_img_'.$key.'"'.$isImg.' value="1" data-switchery="true"> &nbsp; 
                <label for="is_img_'.$key.'"><b>изображения</b></label>
            </div>
        </div>';
    }
}


echo '<div class="panel-heading">
    <div class="categoriesOptions" style="display:none">'.$categories_list.'</div>
    <i class="fa fa-filter" aria-hidden="true"></i> <b>Фильтр</b>
</div>

<div class="pad10 filter_pad">

    <a href="#" id="add_filter"><i class="fa fa-plus"></i> Добавить фильтр</a>
    
    <form action="?mod=kylshop&act=filter" method="POST">
        <div class="filters">'.$fields.'</div>
        <input type="hidden" name="save_filter" value="name">
        <button type="submit" class="btn bg-teal btn-raised position-left legitRipple"><i class="fa fa-floppy-o position-left"></i>Сохранить</button>
        <br><br>
    </form>
    
</div>';