<?php
/**
 * @name список заказов
 */
if (!defined('DATALIFEENGINE') OR !defined('LOGGED_IN')) {
    header("HTTP/1.1 403 Forbidden");
    header('Location: ../../');
    die("Hacking attempt!");
}

if ($member_id['user_group'] != 1) msg("error", $lang['index_denied'], $lang['index_denied']);

/**
 * statuses:
 * ==============
 * 1 - success
 * 2 - moderation
 * ... - other
 */


if(!empty($_POST["order_comment"])){

    $comment = trim(htmlspecialchars(strip_tags(addslashes($_POST["order_comment"]))));
    $db->query( "UPDATE " . PREFIX . "_kylshop_buy SET comment = '{$comment}' WHERE order_id='{$_GET["order"]}'" );
    exit;
}

// удаление заказа
if(!empty($_GET["remove_order"]) && ctype_digit($_GET["remove_order"])){
    $db->query( "DELETE FROM " . PREFIX . "_kylshop_buy WHERE order_id='{$_GET["remove_order"]}'" );
    header("Location: " . $_SERVER["HTTP_REFERER"]);
}


if(!isset($_POST["search"]))
    echo '<div class="panel panel-default">';

// один заказ
if(!empty($_GET["order"]) && ctype_digit($_GET["order"])){

    // получаем все покупки
    $buy = $db->super_query( "SELECT k.*, u.name, u.email, u.fullname FROM " . PREFIX . "_kylshop_buy k LEFT JOIN " . USERPREFIX . "_users u ON (u.user_id=k.user_id) WHERE k.order_id = '{$_GET["order"]}'" );

    if(!empty($_COOKIE["new_orders"]))
        if($buy["see"] == '0')
            $db->query("UPDATE " . PREFIX . "_kylshop_buy SET `see` = '1' WHERE `id` = '{$buy["id"]}'");

    // статусы
    $status_success = $status_moder = '';

    // дополнительные
    $statuses = '';
    if(file_exists(ENGINE_DIR . "/modules/kylshop/statuses.txt") && filesize(ENGINE_DIR . "/modules/kylshop/statuses.txt") != 0){
        $statuses_data = unserialize(file_get_contents(ENGINE_DIR . "/modules/kylshop/statuses.txt"));
        foreach ( $statuses_data['status']['name'] as $item ) {
            $statuses .= '<option value="'.$item.'">'.$item.'</option>'."\n";
        }
    }

    if($buy["status"] == "1") $status_success = ' selected';
    else if($buy["status"] == "2") $status_moder = ' selected';
    else{
        // дополнительные

        if(file_exists(ENGINE_DIR . "/modules/kylshop/statuses.txt") && filesize(ENGINE_DIR . "/modules/kylshop/statuses.txt") != 0){

            $statuses = '';
            $statuses_data = unserialize(file_get_contents(ENGINE_DIR . "/modules/kylshop/statuses.txt"));

            $statuses_result = '';
            foreach ( $statuses_data['status']['name'] as $item ) {
                if($item == $buy["status"])
                    $statuses .= '<option value="'.trim(htmlspecialchars(strip_tags(addslashes($item)))).'" selected>'.trim(htmlspecialchars(strip_tags(addslashes($item)))).'</option>'."\n";
                else
                    $statuses .= '<option value="'.trim(htmlspecialchars(strip_tags(addslashes($item)))).'">'.trim(htmlspecialchars(strip_tags(addslashes($item)))).'</option>'."\n";
            }
        }
    }

    $wait = '';
    if($buy["status"] == "0") $wait = '<option value="" selected disabled>Ожидает оплаты</option>';

    // если заполнено имя
    if(!empty($buy["fullname"])) $buy["fullname"] = "(".$buy["fullname"].")";

    // пользователь или гость
    $name = '<a href="/user/'.$buy["name"].'/" target="_blank">'.$buy["name"].$buy["fullname"].'</a>';
    if(empty($buy["name"])) $name = "Гость";

    $params = '';
    if(!empty($buy["params"])){
        $params = unserialize($buy["params"]);
    }


    // товары
    $goods_source = json_decode($buy["goods"], true);

    $goods = '<table class="table table-striped table-xs table-hover table-bordered" id="cart_table">
            <tr class="header_table">
                <th>Название товара</th>
                <th class="text-center">Кол-во</th>
                <th>Фильтр</th>
                <th class="text-right">Цена</th>
            </tr>';
    $total = 0;
    $addon_price = 0;
    foreach ($goods_source as $row) {

        $filter_params = ''; // если есть фильтр
        if(!empty($row["filter"])){

            foreach ($row["filter"] as $filter_name => $filter_value) {

                $filter_value = is_array($filter_value) ? $filter_value[0] : $filter_value;

                if(strripos($filter_value, ".png") !== false || strripos($filter_value, ".jpg") !== false || strripos($filter_value, ".jpeg") !== false)
                    $filter_value = '<img src="'.$filter_value.'" alt="">';

                if($filter_name == "color"){
                    $filter_name = 'Цвет';
                    $filter_value = '<span class="color_is" style="background:' . $filter_value . '"></span>';
                }

                $filter_params .= '<b>'.$filter_name.'</b>' . $filter_value . '<br>';
            }
        }

        $present = '';
        if(!empty($row["take"]) && $row["take"] > 0) $present = '<span class="present">+'.$row["count"].' в подарок</span>';

        $goods .= '<tr>
                <td>
                    <a href="'.$row["link"].'"><span class="goods_preview"><img src="'.$row["img"].'" alt=""></span> '.$row["title"].'</a>
                </td>
                <td class="text-center">
                    '.$row["count"].'
                    '.$present.'
                </td>
                <td class="text-right">
                    '.$filter_params.'
                </td>
                <td class="text-right">
                    <b>'.round($row["price"], 2).' '.$ks_config["currency"].'</b>
                </td>
            </tr>';


        if(!empty($row["addon"])){
            foreach ( $row["addon"]["name"] as $addon_key => $item ) {
                $goods .= '<tr>
	                <td>
	                    <p><span class="goods_preview"><img src="'.$row["addon"]["image"][$addon_key].'" alt=""></span> '.$item.'</a>
	                </td>
	                <td class="text-center">
	                    '.$row["addon"]["count"][$addon_key].'
	                </td>
	                <td class="text-right"></td>
	                <td class="text-right">
	                    <b>'.round($row["addon"]["price"][$addon_key], 2).' '.$ks_config["currency"].'</b>
	                </td>
	            </tr>';

                $addon_price += round((floatval($row["addon"]["price"][$addon_key]) * (int)$row["addon"]["count"][$addon_key]), 2);
            }
        }


        $total = $total + ((float)$row["price"] * (int)$row["count"]);
    }
    $goods .= '
        </table>';


    // данные
    $data_source = json_decode($buy["fields"], true);

    if(file_exists(ENGINE_DIR . "/modules/kylshop/fields.json")) {

        $fields_source = json_decode(file_get_contents(ENGINE_DIR . "/modules/kylshop/fields.json"), true);

        $data = '<ul class="list2">';
        foreach ($data_source as $key => $item) {

            foreach ($fields_source as $ft) {

                if($ft["type"] == "file" && $ft["title"] == $key){

                    $files = explode("|", $item);
                    $item = '';
                    foreach ($files as $file) {
                        if(strripos($file, ".jpg") !== false || strripos($file, ".jpeg") !== false || strripos($file, ".png") !== false || strripos($file, ".gif") !== false || strripos($file, ".bmp") !== false || strripos($file, ".svg") !== false)
                            $item .= '<br><a href="/uploads/kylshop/'.$file.'" target="_blank"><img src="/uploads/kylshop/'.$file.'" width="150px"></a>';
                        else
                            $item .= '<br><a href="/uploads/kylshop/'.$file.'">'.$file.'</a> ';
                    }
                }
            }

            $data .= '<li><span>'.$key.':</span> <b>'.$item.'</b></li>';
        }
        $data .= '</ul>';
    }

    $method_total = (!empty($params["method_total"])) ? $params["method_total"] : 0;

    $without_sale = '';
    if(!empty($params["promo_code"]["sale"])){

        $total_without_sale = '';

        if(strripos($params["promo_code"]["sale"], "%") != false) $total_without_sale = $buy["total"] - ($buy["total"] * trim($params["promo_code"]["sale"], "%") / 100);
        else $total_without_sale = $buy["total"] - $params["promo_code"]["sale"];

        $without_sale = '<p class="total_sale">Всего со скидкой <span>('.$params["promo_code"]["sale"].')</span>: <b class="total_with_sale">'.$total_without_sale.' '.$ks_config["currency"].'</b></p>';
    }

    echo '<div class="panel-heading">
            Заказ #'.$buy["order_id"].'
            <div class="heading-elements">
                <ul class="icons-list">
                    <li><a href="'.$_SERVER["REQUEST_URI"].'&remove_order='.$row["order_id"].'" class="c_red delete_order"><i class="fa fa-remove position-left"></i>Удалить</a></li>
                </ul>
            </div>
        </div>
        <div class="panel-body">
        
            <div class="row">
                <div class="col-md-2">
                    <b>Товары:</b>
                </div>
                <div class="col-md-10">
                    '.$goods.'
                    <br>
                    <p class="total">Всего: <b>'.($total + $addon_price).' '.$ks_config["currency"].'</b></p>
                    '.$without_sale.'
                    '.((!empty($params["method"]) && !empty($params["method_total"])) ? '<p class="total_method">'.key($params["method"]).' ('.$params["method"][key($params["method"])].'): <b>'.$params["method_total"].' '.$ks_config["currency"].'</b></p>' : '');

    if($buy["total"] == $params["without_sale"]){
        echo '<p class="total_result">Итого: <b>'.((!empty($params["without_sale"])) ? floatval($params["without_sale"]) + floatval($params["method_total"]) + $addon_price : $buy["total"]).' '.$ks_config["currency"].'</b></p>';
    } else{
        
        echo '<p class="total_result">Итого со скидкой: <b>'.$params["without_sale"].' '.$ks_config["currency"].'</b></p>';
    }

    echo '</div>
            </div>
            <br>
            
            <div class="row">
                <div class="col-md-2">
                    <b>Информация о заказе:</b>
                </div>
                <div class="col-md-8">
                    <ul class="list">
                        <li><span>Номер заказа:</span> '.$buy["order_code"].'</li>
                        <li><span>Покупатель:</span> '.$name.'</li>
                        <li><span>E-mail:</span> <a href="mailto:'.$buy["email"].'">'.$buy["email"].'</a></li>
                        <li><span>Дата:</span> '.date("d.m.Y H:i:s", $buy["time"]).'</li>
                    </ul>
                </div>
                <div class="col-md-2">
                    <br>
                    <select name="status" class="uniform position-left select_status" data-id="'.$buy["id"].'">
                        '.$wait.'
                        <option value="success"'.$status_success.'>Одобрено</option>
                        <option value="moder"'.$status_moder.'>На модерации</option>
                        '.$statuses.'
                    </select>
                </div>
            </div>
            <br>
            
            <div class="row">
                <div class="col-md-2">
                    <b>Данные:</b>
                </div>
                <div class="col-md-10">
                    '.$data.'
                </div>
            </div>
            
            <textarea name="comment" id="order_comment" rows="4" class="form-control" placeholder="Заметка для администратора">'.$buy["comment"].'</textarea>
            
            <a href="'.$_SERVER["REQUEST_URI"].'&print=1" target="_blank" class="print_invoice">Печать накладной</a>
            
        </div>';




    if(!empty($_GET["print"])){

        ob_end_clean();

        $doc = file_get_contents(ENGINE_DIR . '/inc/kylshop/print.tpl');
        /*
        {ID} - номер заказа.
        {cart} - содержимое заказа (товары).
        {total} - сумма заказа.
        {sale} - скидка.
        {without-sale} - сумма со скидкой.
        {currency} - валюта.
        {method} - выбранный способ.
        {method-total} - цена за метод.
        {total-all} - цена с учетом скидки + доставка.
        {form} - поля из заполненной формы.
        {date} - дата заказа.
        {status} - статус заказа.
        */

        switch ($buy["status"]){
            case "0":
                $status = 'Ожидает оплаты';
                break;
            case "1":
                $status = 'Оплачен';
                break;
            case "2":
                $status = 'Проверяется';
                break;
            case "3":
                $status = 'Одобрен';
                break;
            default:
                $status = $buy["status"];
        }

        $doc = str_replace(
            [
                "{goods}",
                "{order}",
                "{date-print}",
                "{total}",
                "{total-all}",
                "{without-sale}",
                "{method}",
                "{form}",
                "{date}",
                "{payer}",
                "{status}",
            ],
            [
                $goods,
                $buy["order_code"],
                date("d.m.Y H:i:s", time()),
                'Всего: <b>'.round($total, 2).' '.$ks_config["currency"].'</b>',
                (!empty($params["without_sale"])) ? 'Итого: <b>'.((!empty($params["without_sale"])) ? floatval($params["without_sale"]) + floatval($params["method_total"]) : $buy["total"]).' '.$ks_config["currency"].'</b>' : '',
                (!empty($params["promo_code"]["sale"])) ? 'Всего со скидкой <span>('.$params["promo_code"]["sale"].'): <b class="total_with_sale">'.$total_without_sale.' '.$ks_config["currency"].'</b>' : '',
                (!empty($params["method"])) ? key($params["method"]).' ('.$params["method"][key($params["method"])].'): <b>'.$params["method_total"].' '.$ks_config["currency"].'</b>' : '',
                $data,
                date("d.m.Y H:i:s", $buy["time"]),
                $name,
                $status
            ],
            $doc);

        echo $doc;
    }



    // список заказов
} else {

    $searchWhere = $searchWhereTotal = '';
    if(!empty($_GET["search"])){
        $search = trim(htmlspecialchars(strip_tags($_GET["search"])));
        $searchWhere = " WHERE k.order_code LIKE '%{$search}%' OR k.email LIKE '%{$search}%' OR k.goods LIKE '%{$search}%' OR k.fields LIKE '%{$search}%'";
        $searchWhereTotal = " AND (order_code LIKE '%{$search}%' OR email LIKE '%{$search}%' OR goods LIKE '%{$search}%' OR fields LIKE '%{$search}%')";
    }

    $pagination = '';

    include_once (DLEPlugins::Check(ENGINE_DIR . '/inc/kylshop/pagination.php'));

    // получаем все покупки
    $buy = $db->super_query( "SELECT k.*, u.name, u.email, u.fullname FROM " . PREFIX . "_kylshop_buy k LEFT JOIN " . USERPREFIX . "_users u ON (u.user_id=k.user_id){$searchWhere} ORDER BY id DESC LIMIT " . $start_select . ", 25", true );

    // получим общуюю заработанную сумму
    $total_all = $db->super_query( "SELECT total FROM " . PREFIX . "_kylshop_buy WHERE status = 1{$searchWhereTotal}", true );

    $main_total = 0;
    foreach ($total_all as $sum) {
        $main_total = (float)$main_total + (float)$sum["total"];
    }

    if(!isset($_POST["search"])){

        echo '<div class="panel-heading">
            Список заказов
            <div class="heading-elements">
                <ul class="icons-list">
                    <li><input type="search" name="search_orders" class="search_orders" placeholder="Поиск заказов"></li>
                    <!--<li><a href="#" data-toggle="modal" data-target="#newcats"><i class="fa fa-plus-circle position-left"></i>Добавить заказ</a></li>-->
                </ul>
            </div>
        </div>';
    }

    echo '<table class="table table-striped table-xs table-hover" id="orders">
            <tr>';
    echo $ks_config["show_hash"] ? '<th class="hidden-xs hidden-sm c_g" width="50"><b>#</b></th>' : '';
    echo $ks_config["show_number"] ? '<th width="120">Номер заказа</th>' : '';
    echo $ks_config["show_payer"] ? '<th width="120">Покупатель</th>' : '';
    echo $ks_config["show_goods"] ? '<th>Товары</th>' : '';
    echo $ks_config["show_date"] ? '<th>Дата</th>' : '';
    echo $ks_config["show_total"] ? '<th>Сумма</th>' : '';
    echo $ks_config["show_status"] ? '<th width="100">Статус</th>' : '';
    echo '<th width="100" class="text-center">Действия</th>';
    echo $ks_config["show_many_checkbox"] ? '<th style="width: 40px"><input type="checkbox" name="master_box" class="icheck"></th>' : '';
    echo '</tr>';

    foreach ($buy as $row) {


        // статусы
        $status_success = $status_moder = '';

        // дополнительные
        $statuses = '';
        if(file_exists(ENGINE_DIR . "/modules/kylshop/statuses.txt") && filesize(ENGINE_DIR . "/modules/kylshop/statuses.txt") != 0){
            $statuses_data = unserialize(file_get_contents(ENGINE_DIR . "/modules/kylshop/statuses.txt"));
            foreach ( $statuses_data['status']['name'] as $item ) {
                $statuses .= '<option value="'.$item.'">'.$item.'</option>'."\n";
            }
        }
        if($row["status"] == "1") $status_success = ' selected';
        else if($row["status"] == "2") $status_moder = ' selected';
        else{
            // дополнительные
            if(file_exists(ENGINE_DIR . "/modules/kylshop/statuses.txt") && filesize(ENGINE_DIR . "/modules/kylshop/statuses.txt") != 0){

                $statuses_data = unserialize(file_get_contents(ENGINE_DIR . "/modules/kylshop/statuses.txt"));

                $statuses = '';
                foreach ( $statuses_data['status']['name'] as $item ) {
                    if($item == $row["status"])
                        $statuses .= '<option value="'.$item.'" selected>'.$item.'</option>'."\n";
                    else
                        $statuses .= '<option value="'.$item.'">'.$item.'</option>'."\n";
                }
            }
        }

        $wait = '';
        if($row["status"] == "0") $wait = '<option value="" selected disabled>Ожидает оплаты</option>';

        $name = '<a href="/user/'.$row["name"].'/" target="_blank">'.$row["name"].'</a>';
        if(empty($row["name"])) $name = "Гость";

        // перебор новостей
        $goods = '<ul>';
        $g = json_decode($row["goods"], true);
        foreach ($g as $item) {

            $filter_params = ''; // если есть фильтр
            if(!empty($item["filter"])){

                foreach ($item["filter"] as $filter_name => $filter_value) {

                    $filter_value = is_array($filter_value) ? $filter_value[0] : $filter_value;

                    if(strripos($filter_value, ".png") !== false || strripos($filter_value, ".jpg") !== false || strripos($filter_value, ".jpeg") !== false)
                        $filter_value = '<img src="'.$filter_value.'" alt="">';

                    if($filter_name == "color"){
                        $filter_name = 'Цвет:';
                        $filter_value = '<span class="color_is" style="background:' . $filter_value . '"></span>';
                    }

                    $filter_params .= '<br><b>'.$filter_name.' </b>' . $filter_value . '';
                }
            }

            /*if($filter_name == "color"){
                $filter_name = 'Цвет';
                $filter_value = '<span class="color_is" style="background:' . $filter_value . '"></span>';
            }

            $filter_params .= '<b>'.$filter_name.'</b>' . $filter_value . '<br>';*/

            $img = "";
            if(!empty($item["img"])) $img = '<img src="'.$item["img"].'" alt="">';

            if($item["link"] == "balance")
                $goods .= '<li>Пополнение баланса</li>';
            else
                $goods .= '<li><a href="'.$item["link"].'" target="_blank">'.$img.' '.$item["title"].' ( '.$item["count"].' шт. )'.$filter_params.'</a></li>';
        }
        $goods .= '</ul>';


        // если есть доп параметры
        $sale_label = '';
        if(!empty($row["params"])){
            $params = unserialize($row["params"]);

            if(!empty($params["promo_code"]["sale"])){
                if(strripos($params["promo_code"]["sale"], "%") === false)
                    $params["promo_code"]["sale"] .= ' ' . $ks_config["currency"];
                $sale_label = '<span class="sale_label">-'.$params["promo_code"]["sale"].'</span>';
            }
        }

        echo '<tr class="status_'.$row["status"].'" title="'.$row["comment"].'">';
        echo $ks_config["show_hash"] ? '<td class="hidden-xs hidden-sm c_g">'.$row["order_id"].'</td>' : '';
        echo $ks_config["show_number"] ? '<td><a href="'.$_SERVER["REQUEST_URI"].'&order='.$row["order_id"].'" class="order_number">'.$row["order_code"].'</a></td>' : '';
        echo $ks_config["show_payer"] ? '<td>'.$name.'</td>' : '';
        echo $ks_config["show_goods"] ? '<td>'.$goods.'</td>' : '';
        echo $ks_config["show_date"] ? '<td>'.date("d.m.Y H:i:s", $row["time"]).'</td>' : '';
        echo $ks_config["show_total"] ? '<td class="pr"><b>'.round($row["total"], 2).' '.$ks_config["currency"].'</b>'.$sale_label.'</td>' : '';
        echo $ks_config["show_status"] ? '<td>
                    <select class="uniform select_status" data-id="'.$row["id"].'" name="reglevel">
                        '.$wait.'
                        <option value="success"'.$status_success.'>Одобрено</option>
                        <option value="moder"'.$status_moder.'>На модерации</option>
                        '.$statuses.'
                    </select>
                </td>' : '';
        echo '<td class="text-center">
                    <ul class="actions">
                        <li><a href="'.$_SERVER["REQUEST_URI"].'&remove_order='.$row["order_id"].'" class="fa fa-times delete_order" aria-hidden="true" title="Удалить"></a></li>
                    </ul>
                </td>';
        echo $ks_config["show_many_checkbox"] ? '<td style="text-align: center"><input name="selected_news[]" value="" type="checkbox" class="icheck"></td>' : '';
        echo '</tr>';
    }


    // дополнительные
    $statuses = '';
    if(file_exists(ENGINE_DIR . "/modules/kylshop/statuses.txt") && filesize(ENGINE_DIR . "/modules/kylshop/statuses.txt") != 0){
        $statuses_data = unserialize(file_get_contents(ENGINE_DIR . "/modules/kylshop/statuses.txt"));
        $statuses_result = '';
        foreach ( $statuses_data['status']['name'] as $item ) {
            $statuses .= '<option value="'.$item.'">'.$item.'</option>'."\n";
        }
    }

    if(!isset($_POST["search"])){

        echo '</table>
        
        <div class="panel-footer">
            <div class="pull-left">
                <p>Всего заработано: <b>'.round($main_total, 2).' '.$ks_config["currency"].'</b></p>
            </div>
            <div class="pull-right">
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input class="btn bg-teal btn-sm btn-raised legitRipple" type="submit" value="Выполнить">
            </div>
            <div class="pull-right">
                <select name="" id="" class="uniform position-left">
                    <option value="0">-- Действие --</option>
                    <option value="success">Одобрено</option>
                    <option value="success">На модерации</option>
                    '.$statuses.'
                </select>
            </div>
        </div>' . $pagination;
    }

}

echo '</div>';