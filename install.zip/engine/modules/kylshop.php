<?php
/**
 * ГЛАВНЫЙ ФАЙЛ МОДУЛЯ
 * @name этот файл подключается из modules/main.php в начале
 * */
if( !defined('DATALIFEENGINE') ) {
    header( "HTTP/1.1 403 Forbidden" );
    header ( 'Location: ../../' );
    die( "Hacking attempt!" );
}

// подключаем функции
include (DLEPlugins::Check(ENGINE_DIR . '/modules/kylshop/init.php'));

if(!empty($_GET["payment"])){
    include (DLEPlugins::Check(ENGINE_DIR . '/modules/kylshop/payment.php'));
}

$sale = (file_exists(ENGINE_DIR . '/modules/kylshop/sale.json')) ? file_get_contents(ENGINE_DIR . '/modules/kylshop/sale.json') : '';

// Таблица с товарами
$goods = '<table class="cart_table_min"></table>
<p class="ks_total_cart">Всего: <b>0</b></p>';

// Настройки для скрипта
$scripts_settings = '<script>
$(function(){
    let settings = {
        "currency": "'.$ks_config["currency"].'",
        "minPrice": "'.$ks_config["minPrice"].'",
        "maxPrice": "'.$ks_config["maxPrice"].'",
        "recalculation_price": "'.$ks_config["recalculation_price"].'",
        "payment_guest": "'.$ks_config["payment_guest"].'",
        "user_group": "'.$member_id["user_group"].'",
        "delivery_power": "'.$ks_config["delivery_power"].'",
        "max_total_delivery": "'.$ks_config["max_total_delivery"].'",
        "price_delivery": "'.$ks_config["price_delivery"].'",
        "pickup_sale": "'.$ks_config["pickup_sale"].'",
        "sale": \''.$sale.'\',
        "promo_in_sale": "'.$ks_config["promo_in_sale"].'",
        "promo_for_goods": "'.$ks_config["promo_for_goods"].'",
        "promo_no_cats": "'.$ks_config["promo_no_cats"].'"
    };
    localStorage.setItem("config", JSON.stringify(settings));
})
</script>';


/**
 * @name CART
 * если добавление в корзину включено
 * ============
 */
if($ks_config["add_to_cart"] == true){

    // если это гость и запрещено покупать
    if($member_id["user_group"] == "5" && $ks_config["payment_guest"] == "0") $cart_min_content = "";
    else{
        // получим шаблон с мини-корзиной
        $cart_min = new dle_template();
        $cart_min -> dir = TEMPLATE_DIR . "/kylshop";
        $cart_min -> load_template( 'cart_min.tpl' );
        $cart_min -> set('{count}', '<span class="ks_count">0</span>'); // кол-во в корзине - обертка
        $cart_min -> set('{total}', '<span class="ks_total">0</span>'); // общая цена - обертка
        $cart_min -> set('{goods}', $goods); // товары в корзине
        $cart_min -> set('{unit}', $ks_config["unit"]); // единица измерения
        $cart_min -> set('{ccy}', $ks_config["currency"]); // валюта
        $cart_min -> set('{link-cart}', $config["http_home_url"] . "?do=cart"); // ссылка на корзину
        $cart_min -> compile( 'content' );
        $cart_min_content = $cart_min->result["content"];
    }


    // если тег {cart} есть в шаблоне, то заменяем его
    if (stripos ( $tpl->copy_template, "{cart}" ) !== false) {
        $tpl->set("{cart}", $cart_min_content);
        $cart_min_content = "";
    }

// если добавление в корзину выключено
} else{

    $tpl->set("{cart}", $cart_min_content);
    $cart_min_content = "";
}

/**
 * @name FILTER
 * ============
 */
$filter_source = json_decode(file_get_contents(ENGINE_DIR . '/modules/kylshop/filter.json'), true);

$filter = '<div id="ks_filter">
    <ul>
        <li>
            <p>Цена:</p>
            <div class="ks_filter_price">
                <span class="ks_filter_from">от: <b></b></span>
                <span class="ks_filter_to">до: <b>50000 '.$ks_config["currency"].'</b></span>
            </div>
            <div id="ks_filter_price"></div>
        </li>';

    foreach ($filter_source["title"] as $key => $row1) {

        if($do == 'cat' && !empty($filter_source["categories"][$key]) && array_search($category_id, $filter_source["categories"][$key]) === false) continue;
            
        $filter .= '<li><p>'.$row1[0].':</p>
                <ul>';

        if(!empty($filter_source["slider"][$key])){

            $sliderStep = !empty($filter_source["slider_step"][$key][0]) ? $filter_source["slider_step"][$key][0] : '1';

            $filter .= '<div class="ks_filter_slider_box">
                <span class="ks_slider_from">от: <b>'.$filter_source["value"][$key][0].'</b></span>
                <span class="ks_slider_to">до: <b>'.$filter_source["value"][$key][count($filter_source["value"][$key])-1].'</b></span>
            </div>
            <div class="ks_filter_slider" data-min="'.$filter_source["value"][$key][0].'" data-max="'.$filter_source["value"][$key][count($filter_source["value"][$key])-1].'" data-name="'.$row1[0].'" data-step="'.$sliderStep.'"></div>';

        } else{

            foreach ($filter_source["value"][$key] as $j => $row2) {
                $filter .= '<li><input type="checkbox" class="filter_check" id="'.$key.$j.'" data-filter="'.$row1[0].':'.$row2.'"> <label for="'.$key.$j.'">'.$row2.'</label></li>';
            }
        }

        $filter .= '</ul>
            </li>';
}
$filter .= '</ul>
    <a href="#" id="clear_filter">Сбросить</a>
</div>';

$tpl->set("{filter}", $filter);
// FILTER END


$tpl->set("{balance}", $member_id['balance']);
$tpl->set("{currency}", $ks_config["currency"]);






/**
 * @name DELIVERY
 * если доставка включена
 * ============
 */
$googleMapsScript = "";

if($ks_config["delivery_power"] == true){

    if (stripos ( $tpl->copy_template, "{map}" ) !== false) {

        if($delivery_map){
            $tpl->set("{map}", '<script type="text/javascript" src="//maps.googleapis.com/maps/api/js?key='.$ks_config["google_maps_api_key"].'&libraries=places"></script>');
        } else{
            if(empty($delivery_data)){
                $delivery_data = $db->super_query( "SELECT marker_id, coords, title, description FROM " . PREFIX . "_kylshop_delivery", true );
                $delivery_data = json_encode($delivery_data, JSON_UNESCAPED_UNICODE);
            }

            $tpl->set("{map}", '<div id="ks_map" data-config=\''.$ks_config["delivery_mapInfo"].'\' data-markers=\''.$delivery_data.'\'></div>');
            $googleMapsScript = '<script type="text/javascript" src="//maps.googleapis.com/maps/api/js?key='.$ks_config["google_maps_api_key"].'&libraries=places"></script>';
        }
    }

} else{

    $tpl->set("{map}", '');
}

$tpl->set('{addBalance}', '<span class="my_price"><input name="pay_my_balance" placeholder="На какую сумму пополнить?"></span><a href="/?do=cart" class="go_to_cart" data-goods="1|Пополнить баланс|0|9999|balance|unique">Пополнить</a>');
//$tpl->result['content'] = str_replace('{addBalance}', '<span class="my_price"><input name="pay_my_balance" placeholder="На какую сумму пополнить?"></span><a href="#" class="add_to_cart" data-goods="1|Пополнить баланс|0|9999|balance|unique">Пополнить</a>', $tpl->result['content']);


$tpl->copy_template = preg_replace('/{pay="([0-9]+)\|(.+?)"}/is', '<a href="#" class="add_to_cart" data-goods="1|$2|$1|9999|'.$_SERVER["REQUEST_URI"].'|unique">$2</a>', $tpl->copy_template);

$tpl->copy_template = preg_replace('/{pay="(.+?)"}/is', '<span class="my_price"><input name="my_price" placeholder="Введите сумму"></span><a href="#" class="add_to_cart" data-goods="1|$1|0|9999|'.$_SERVER["REQUEST_URI"].'|unique">$1</a>', $tpl->copy_template);


// добавлено в версии 3.7
if(!empty($_GET["do"]) && $_GET["do"] == "cart"){
    $tpl->set("{map}", '<div id="ks_map" data-config=\''.$ks_config["delivery_mapInfo"].'\' data-markers=\''.$delivery_data.'\'></div>');
    $googleMapsScript = '<script type="text/javascript" src="//maps.googleapis.com/maps/api/js?key='.$ks_config["google_maps_api_key"].'&libraries=places"></script>';
}

// JQUERY UI
$jquery_ui = '
<link rel="stylesheet" href="' . $config['http_home_url'] . 'templates/' . $config['skin'] . '/css/jquery-ui.min.css">
<script src="' . $config['http_home_url'] . 'templates/' . $config['skin'] . '/js/jquery-ui.min.js"></script>
<script src="' . $config['http_home_url'] . 'templates/' . $config['skin'] . '/js/jquery.ui.touch-punch.min.js"></script>';

// скрипты подключаемые после {AJAX}
// $cart_min - содержит миникорзину
$kylshop_scripts .= $scripts_settings . '
<link href="' . $config['http_home_url'] . 'templates/' . $config['skin'] . '/css/kylshop.css?v='.$ks_config["version"].'" type="text/css" rel="stylesheet">'.$jquery_ui.$googleMapsScript.'
<script src="' . $config['http_home_url'] . 'templates/' . $config['skin'] . '/js/kylshop.js?v='.$ks_config["version"].'"></script>' . $cart_min_content;