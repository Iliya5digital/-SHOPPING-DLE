<?php
/**
 * @name добавление заказа в базу, формирование платежных форм
 */
if( !defined('DATALIFEENGINE') ) {
    header( "HTTP/1.1 403 Forbidden" );
    header ( 'Location: ../../' );
    die( "Hacking attempt!" );
}


header("Content-Type: text/html; charset=utf-8");

require_once ENGINE_DIR . "/modules/kylshop/template_email.php";

function setLog($data, $file){
    $data = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    file_put_contents(ENGINE_DIR . '/modules/kylshop/payments/' . $file . '.json', $data);
}

$one_plus_one = [];

// значит пользователь только собирается перейти на страницу с выбором способа оплаты
if(!empty($_POST["payment_start"])){

    // payment_delivery - самовывоз - название выбранного маркера
    // delivery_city - выбранный город

    unset($_POST["payment_start"]);

    // номер покупки
    $order_id = file_get_contents(ENGINE_DIR . '/modules/kylshop/order_id.txt');
    $order_number = (int)$order_id + 1;
    $order_file = ENGINE_DIR . '/modules/kylshop/order_id.txt';
    $fp = fopen($order_file, "w");
    flock($order_file, LOCK_EX);
    fwrite($fp, $order_number);
    flock($order_file, LOCK_UN);

    // получаем существующие поля
    $fields_source = json_decode(file_get_contents(ENGINE_DIR . "/modules/kylshop/fields.json"), true);

    //$_POST["goods"] = str_replace("'", '\\"', $_POST["goods"]);

    $goods = json_decode($_POST["goods"], true);

    // в первую очередь заносим выбранные пользователем товары в переменную goods
    $goods = '';
    if(!empty($_POST["goods"])){
        $goods = json_decode($_POST["goods"], true);
        if(!is_array($goods)) die("Sorry! Invalid parameters of goods");
    }
    unset($_POST["goods"]);

    // перебираем все товары из корзины и проверяем на правильность отправки данных
    $where = "";
    $addBalance = false;
    foreach ($goods as $key => $good) {

        if($good["link"] == "balance") $addBalance = true;

        $g_id = explode("_", $good["id"]);
        $where .= "id='{$g_id[0]}' OR ";

        if(!empty($good["filter"])){
            $goods[$key]["filter"] = json_decode($good["filter"], true);
            unset($goods[$key]["filter"]["Цвет:"]);
        }
    }

    $goods = trim(json_encode($goods, JSON_UNESCAPED_UNICODE), '"');
    $goods = json_decode($goods, true);


    unset($g_id);
    $where = substr($where, 0, -4);

    // получаем массив новостей из базы
    $news = $db->super_query( "SELECT id, kylshop, filter FROM " . PREFIX . "_post WHERE " . $where, true );

    // v 3.4
    $filter_file = json_decode(file_get_contents(ENGINE_DIR . '/modules/kylshop/filter.json'), true);

    // если были доп товары
    $addon_goods = [];
    if(!empty($_POST["addon_goods"])){

        $addon_goods_ = explode(";", $_POST["addon_goods"]);
        foreach ( $addon_goods_ as $addon_row ) {
            if(!empty($addon_row)){
                $tmp_addon = explode(":", $addon_row);
                $addon_goods[$tmp_addon[0]][] = $tmp_addon[1];
            }
        }
    }


    foreach ($news as $row) {

        $kylshop = unserialize($row["kylshop"]);

        // 1+1
        if(!empty($kylshop["one_plus_one"])){

            foreach ( $kylshop["one_plus_one"] as $item ) {

                if($item[0] < date("H:i", time()) && $item[1] > date("H:i", time())){
                    $one_plus_one[$row["id"]] = 1;
                }
            }
        }

        // смотрим доп товары
        if(!empty($kylshop["addon"])){

            $kylshop["addon"]["count"] = $addon_goods[$row["id"]];
            $goods[$row["id"]]["addon"] = $kylshop["addon"];

        }


        $price = $kylshop["ks_price"];

        // если есть скидка
        if(!empty($kylshop["ks_sale"])){
            if($kylshop["ks_sale_type"] == "%") $price = (float)$price - ((float)$price * (int)$kylshop["ks_sale"]) / 100;
            else $price = (float)$price - (int)$kylshop["ks_sale"];
        }
        $price = round($price, 2);


        // v 3.4
        $filter_source = explode("||", $row["filter"]);
        $filter_prices = json_decode($filter_source[1], true);

        $tmp_filter = [];
        foreach ($filter_file["value"] as $key_title => $item) {
            $j = 0;
            foreach ($item as $it) {

                if(!empty($filter_prices[$key_title."_".$j])){
                    $tmp_filter[$it] = ["title" => $it, "price" => $filter_prices[$key_title."_".$j]];
                } else{
                    $tmp_filter[$it] = ["title" => $it, "price" => $price];
                }
                $j++;
            }
        }

        // обходим товары с фильтрами, и если цена не совпадает, значит покупатель ковырял код и пытался изменить цену товара через код, в таком случае можно послать его на ...
        /*foreach ($goods as $good) {
            if(!empty($good["filter_val"]) && $tmp_filter[$good["filter_val"]]["price"] != $good["price"]) die("Извините, что-то пошло не так!");
        }*/
        // v 3.4 end

    }

    $total = 0; // общая сумма
    foreach ($goods as $good) {
        $total = $total + (str_replace(",", ".", $good["price"]) * (int)$good["count"]);
    }
    $total = round($total, 2);

    $data = [];

    // доставка по умолчанию false
    $delivery = false;

    // заносим данные в базу
    foreach ($_POST as $key => $item) {

        // если был выбран пункт самовывоза
        if(!empty($_POST["payment_delivery"])){
            $data["Пункт выдачи"] = trim(htmlspecialchars(strip_tags($_POST["payment_delivery"])));
            unset($_POST["payment_delivery"]);
        }


        // включена ли доставка
        // если включена и доставка - город и сумма превышает допустимую
        if($ks_config["delivery_power"] == true){
            if($key == "delivery_city"){
                $data["Город"] = trim(htmlspecialchars(strip_tags($_POST["delivery_city"])));
                $delivery = true;
            }
            // если самовывоз
            /*if(trim(mb_strtolower($item, 'UTF-8')) == "самовывоз"){

            }*/
        }

        if(!empty($fields_source[$key]["admin"])) $title = $fields_source[$key]["admin"];
        else $title = $fields_source[$key]["title"];
        $title = str_replace("*", "", $title);

        if(!empty($title)) $data[$title] = str_replace("\r\n", "", trim($item));
    }

    // если доставка в другой город и сумма заказа превышает допустимую
    if($delivery === true && $total > $ks_config["max_total_delivery"]){
        $total = $total + str_replace(",", ".", $ks_config["price_delivery"]);
    }

    if(!empty($_POST["email"])) $data["email"] = $_POST["email"];

    // Сумма со скидкой
    $without_sale = $total;
    $code_row = [];
    if(!empty($_POST["promo-code"])){

        $promo_code = trim(htmlspecialchars(strip_tags($_POST["promo-code"])));
        $code_row = $db->super_query("SELECT id, code, sale, type FROM " . PREFIX . "_promocodes WHERE `code` = '{$promo_code}' AND `status` != '0' AND term >= '".time()."'");

        if(!empty($code_row["sale"]) && $code_row["type"] == '0') // деактивируем промокод если он не вечный
            $db->query("UPDATE " . PREFIX . "_promocodes SET status = 0 WHERE `id` = '{$code_row["id"]}'");

        $db->query("UPDATE " . PREFIX . "_promocodes SET count_pay = count_pay+1 WHERE `id` = '{$code_row["id"]}'");

        if(strripos($code_row["sale"], "%") !== false)
            $without_sale = floatval($total) - ((floatval($total) * trim((int)$code_row["sale"], "%")) / 100);
        else
            $without_sale = floatval($total) - floatval($code_row["sale"]);
    }


    // если включены методы
    $method_name = []; // для params
    $method_total = 0;
    if($ks_config["method"] == true && !empty($_POST["extra_method"]) && file_exists(ENGINE_DIR . "/modules/kylshop/method.json")) {

        $method_data = json_decode( file_get_contents( ENGINE_DIR . "/modules/kylshop/method.json" ), true );


        foreach ( $method_data["method_name"] as $method_key => $method_datum ) {

            if($method_datum == $_POST["extra_method"]){

                // если %
                if(strripos($method_data["method_price"][$method_key], "%") !== false){

                    $method_total = ($total * trim($method_data["method_price"][$method_key], "%")) / 100;

                } else $method_total = $method_data["method_price"][$method_key];

                if(!empty($method_data["method_max_price"][$method_key]) && $total >= $method_data["method_max_price"][$method_key]) $method_total = 0;

                break;
            }
        }

        $method_title = "Метод";
        if(!empty($ks_config["method_title"]))
            $method_title = explode("|", $ks_config["method_title"])[2];

        // для params
        $method_name[trim($method_title)] = trim(htmlspecialchars(strip_tags(addslashes($_POST["extra_method"]))));

        if($ks_config["extra_method_to_mail"])
            $data[trim($method_title)] = $method = trim(htmlspecialchars(strip_tags(addslashes($_POST["extra_method"])))) . ' (' . $method_total . ' ' . $ks_config["currency"] . ')';

        $without_sale = $without_sale/* + $method_total*/;
    }


    $total = str_replace(",", ".", $total);
    $without_sale = str_replace(",", ".", $without_sale);

    if(!empty($_POST["pickup"])){
        $without_sale = $without_sale - (($without_sale * (int)$ks_config["pickup_sale"]) / 100);
    }

    $form = '<ul style="list-style:none;">';
    foreach ( $data as $form_key => $datum ) {
        $form .= '<li><b>'.$form_key.':</b> '.$datum.'</li>';
    }
    $form .= '</ul>';

    if(!empty($_POST["promo-code"])) $data["promo-code"] = $_POST["promo-code"];

    $data = json_encode($data, JSON_UNESCAPED_UNICODE);

    // код покупки
    if(!empty($ks_config["order_code"])) $order_code = $ks_config["prefix_order"] . date($ks_config["order_code"], time());
    else $order_code = $ks_config["prefix_order"] . round(microtime(true) * 1000);

    // id пользователя
    // если разрешено покупать гостям
    if($ks_config["payment_guest"] == true){

        // если это гость
        if($member_id["user_group"] == "5") $user_id = "0";
        $user_id = $member_id["user_id"];

        // если не разрешено покупать гостям
    } else{

        // если это гость
        if($member_id["user_group"] == "5") die("Sorry! Guests are not allowed to buy goods!");
        $user_id = $member_id["user_id"];
    }


    $time = time();
    $secret_key = sha1($order_id + $ks_config["secret_key_payment"] . ":kylaksizov");


    $cart_email = '<table style="width:100%;text-align:left;">
	<tr>
		<th>Наименование</th>
		<th>Кол-во</th>
		<th>Цена</th>
	</tr>';
    foreach ( $goods as $key => $row ) {

        $one_plus_one = '';
        if(!empty($one_plus_one[$row["id"]])){
            $goods[$key]["present"] = $row["count"];
            $one_plus_one = '<span>+'.$row["count"].' шт.</span>';
        }

        $cart_email .= '<tr>
			<td><a href="'.$row["link"].'">'.$row["title"].'</a></td>
			<td>'.$row["count"].'</td>
			<td>'.$row["price"].'</td>
		</tr>';
    }
    $cart_email .= '</table>';

    $goods_info = json_decode($goods, true);
    if(count($goods_info) == 1) $goods_title = "(" . array_shift($goods_info)["title"] . ")";
    else $goods_title = "№" . $order_id;


    /**
     * @name важные параметры
     */
    $params = [
        "without_sale" => $without_sale
    ];

    // если есть метод
    if(!empty($method_name)){
        $params = array_merge($params, ["method" => $method_name, "method_total" => $method_total]);
    }

    // если была задана скидка
    if(!empty($code_row) && !empty($_POST["promo-code"])){
        $params = array_merge($params, ["promo_code" => $code_row]);
    }

    $params = serialize($params);

    $goods = json_encode($goods, JSON_UNESCAPED_UNICODE);

    // заносим данные в базу
    $db->query("INSERT INTO " . PREFIX . "_kylshop_buy (order_id, order_code, user_id, fields, params, goods, total, time, secret_key, status)
		VALUES ('{$order_id}', '{$order_code}', '{$user_id}', '{$data}', '{$params}', '{$goods}', '{$total}', '{$time}', '{$secret_key}', '0')");

    $id = $db->insert_id();

    $search_body = [
        "{ID}",
        "{cart}",
        "{total}",
        "{sale}",
        "{without-sale}",
        "{currency}",
        "{method}",
        "{method-total}",
        "{total-all}",
        "{form}",
        "{date}",
        "{status}"
    ];

    $replace_body = [
        $order_code,
        $cart_email,
        $total,
        $sale,
        $without_sale,
        $ks_config["currency"],
        (!empty($method_name[trim($method_title)])) ? $method_name[trim($method_title)] : '',
        $method_total,
        floatval($without_sale) + floatval($method_total),
        $form,
        date("d.m.Y H:i:s", time()),
        "Новый"
    ];

    $body = str_replace($search_body, $replace_body, $template_e["email_1"]);

    # TODO одинаковый функционал!
    // отправляем информацию о заказе на почту администратору
    include_once (DLEPlugins::Check(ENGINE_DIR . '/classes/mail.class.php'));

    // отправляем письмо админу
    $email_admin = $db->super_query( "SELECT * FROM " . PREFIX . "_users where user_group='1' LIMIT 0,1" );
    $mail = new dle_mail( $config, 1 );
    $mail->send( $email_admin["email"], "Новый заказ", $body );

    // отправляем письмо покупателю
    if(!empty($_POST["email"])){

        $body = str_replace($search_body, $replace_body, $template_e["email_2"]);

        $mail2 = new dle_mail( $config, 1 );
        $mail2->send( $_POST["email"], "Новый заказ", $body );
    }

    //if( $mail->send_error ) msgbox( "Ошибка!", "Failed" );
    // Таблица с товарами
    //$goods .= '<script>$(function(){localStorage.clear();})</script>';


    /**
     * @name выводим все подключаемые модули оплаты,
     * если включен прием платежей на сайте
     */
    if($ks_config["payments_power"] == true){


        $payment_init = '<div id="payments">';

        if($ks_config["payments_balance"] && $member_id['user_group'] != '5' && $without_sale <= $member_id['balance'] && !$addBalance){

            $payment_init = '<div id="payments">
                <div>
                    <p class="pay_by_balance">На балансе: <b>'.$member_id['balance'].' '.$ks_config['currency'].'</b></p>
                    <form action method="POST">
                        <input type="hidden" name="pay_balance" value="ok">
                        <input type="hidden" name="pay_id" value="'.$id.'">
                        <input type="hidden" name="pay_sum" value="'.$without_sale.'">
                        <input type="submit" class="payment_btn" value="Списать с баланса">
                    </form>
                </div>';
        }

        foreach (scandir(ENGINE_DIR . '/modules/kylshop/payments') as $file) {
            $config_app = "";
            if($file != "." && $file != ".." && $file != "Example"){
                if(file_exists(ENGINE_DIR . '/modules/kylshop/payments/' . $file . '/config.json')){

                    $config_payment = json_decode(file_get_contents(ENGINE_DIR . '/modules/kylshop/payments/' . $file . '/config.json'));

                    // подключаем главный класс системы оплаты
                    include (DLEPlugins::Check(ENGINE_DIR . '/modules/kylshop/payments/' . $file . '/'.$file.'.php'));

                    // если класс существует
                    if(class_exists($file)){

                        $payment = new $file($config_payment, $config);

                        // если метод вывода кнопки или формы существует
                        if(method_exists($payment, "init")){

                            // выводим форму или кнопку для перехода на страницу оплаты и передаем id добавленой записи и общую сумму
                            $payment_init .= '<div>
                                <img src="'.$config["http_home_url"]."templates/".$config["skin"].$config_payment->img.'" alt="'.$config_payment->name.'" class="payment_img">
                                '.$payment->init($id, $without_sale, $secret_key, $data, $goods)/* $data - данные с формы */.'
                            </div>';
                        }
                    }
                }
            }
        }
        $payment_init .= '</div><script>$(function(){localStorage.clear();})</script>';

        // если оплата выключена
    } else{

        // если оплата выключена и есть ссылка куда направлять пользователя...
        if($ks_config["payments_power"] == false && !empty($ks_config["order_redirect"])){
            header("Location: " . $ks_config["order_redirect"]);
            die();
        }

        // замена тегов
        $ks_config["order_text"] = str_replace(
            [
                "{id}",
                "{order}"
            ],
            [
                $id,
                $order_code
            ],
            $ks_config["order_text"]
        );

        $payment_init = $ks_config["order_text"] . '<script>$(function(){localStorage.clear();})</script>';
    }

}

// Обрабатываем скрытые платежы
if(!empty($_GET["payment"])) {

    $payment_param = explode("_", $_GET["payment"]);

    $config_payment = json_decode(file_get_contents(ENGINE_DIR . '/modules/kylshop/payments/' . $payment_param[0] . '/config.json'));

    // подключаем главный класс системы оплаты
    include(DLEPlugins::Check(ENGINE_DIR . '/modules/kylshop/payments/' . $payment_param[0]. '/' . $payment_param[0] . '.php'));

    $method = $payment_param[1];

    // если класс существует
    if (class_exists($payment_param[0])) {

        $payment = new $payment_param[0]($config_payment, $config);
        // если метод вывода кнопки или формы существует
        if ($method == "success" && method_exists($payment, "success")) {

            setLog(["success"], 1);
            $result = $payment->success();

            setLog([$result], 7);
            /**
             * @name УСПЕШНАЯ ОПЛАТА
             * ===========================
             */
            // если метод вернул ID заказа
            if(is_numeric($result)){


                // получаем заказ из базы
                $order = $db->super_query( "SELECT * FROM " . PREFIX . "_kylshop_buy WHERE id = '{$result}'" );
                $db->query( "UPDATE  " . PREFIX . "_kylshop_buy set status='1' WHERE id = '{$result}'" );

                $goods = json_decode($order["goods"], true);
                $fields = json_decode($order["fields"], true);
                $params = unserialize($order["params"]);

                // если был промо-код, добавляем сумму
                if(!empty($params['promo_code']['code'])){

                    if($params['promo_code']['type'] == "%") $price = (float)$order["total"] - ((float)$order["total"] * (int)$params['promo_code']['sale']) / 100;
                    else $price = (float)$order["total"] - (int)$params['promo_code']['sale'];

                    $db->query("UPDATE " . PREFIX . "_promocodes SET summ = summ+{$price} WHERE `code` = '{$params['promo_code']['code']}'");
                }

                $link_success = '';

                $cart_email = '<table style="width:100%;text-align:left;">
					<tr>
						<th>Наименование</th>
						<th>Кол-во</th>
						<th>Цена</th>
					</tr>';

                $i = 1;
                $link = '';
                foreach ( $goods as $row ) {

                    $link .= $row["link"].'<br>';
                    //$link_success .= '<a href="'.$row["link"].'?order='.$order["secret_key"].'-'.$order["order_code"].'">Товар '.$i.'</a><br>';

                    $cart_email .= '<tr>
						<td><a href="'.$row["link"].'">'.$row["title"].'</a></td>
						<td>'.$row["count"].'</td>
						<td>'.$row["price"].'</td>
					</tr>';

                    $i++;
                }
                $cart_email .= '</table>';

                $data = json_decode($order, true);
                $form = '<ul style="list-style:none;">';
                foreach ( $data as $form_key => $datum ) {
                    $form .= '<li><b>'.$form_key.':</b> '.$datum.'</li>';
                }
                $form .= '</ul>';

                # TODO одинаковый функционал!
                // отправляем информацию о заказе на почту администратору
                include_once (DLEPlugins::Check(ENGINE_DIR . '/classes/mail.class.php'));

                $search_body = [
                    "{ID}",
                    "{cart}",
                    "{total}",
                    "{without-sale}",
                    "{sale}",
                    "{currency}",
                    "{method}",
                    "{link-success}",
                    "{method-total}",
                    "{form}",
                    "{date}",
                    "{status}"
                ];

                $replace_body = [
                    $order["order_code"],
                    $cart_email,
                    $order["total"],
                    (!empty($params["without_sale"])) ? $params["without_sale"] : '',
                    (!empty($params["promo_code"]["sale"])) ? $params["promo_code"]["sale"] : '',
                    $ks_config["currency"],
                    (!empty($params["method"])) ? $params["method"][key($params["method"])] : '',
                    $link_success,
                    (!empty($params["method_total"])) ? $params["method_total"] : '',
                    $form,
                    date("d.m.Y H:i:s", time()),
                    "Новый"
                ];

                $body_admin = str_replace($search_body, $replace_body, $template_e["email_3"]);

                $mail_admin = new dle_mail( $config, 1 );
                $mail_admin->send( $config["admin_mail"], "Поступила оплата заказа №".$order["order_code"], $body_admin );


                // если email покупателя есть, отправляем ему сообщение
                if(!empty($fields["email"])){

                    /*if($order["user_id"] != '0'){
                        unset($search_body[7], $replace_body[7]);
                    }*/
                    $body_user = str_replace($search_body, $replace_body, $template_e["email_4"]);

                    $mail_user = new dle_mail( $config, 1 );
                    $mail_user->send( $fields["email"], "Заказ №".$order["order_code"], $body_user );
                }

                $where = "";
                foreach ($goods as $news_id) {
                    if(ctype_digit($news_id["id"]))
                        $where .= " id = '{$news_id["id"]}' OR ";
                }

                if(!empty($where)){
                    $where = substr($where, 0, -4);
                    $news = $db->super_query( "SELECT id, kylshop FROM " . PREFIX . "_post WHERE" . $where, true );

                    file_put_contents(ROOT_DIR . "/-news.txt", json_encode($news, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT), FILE_APPEND);

                    foreach ($news as $key => $goods_info) {

                        $goods_params = unserialize($goods_info["kylshop"]);

                        $link_success .= $goods_params["after_payment_post"].'<br>';

                        file_put_contents(ROOT_DIR . "/-tests.txt", $goods_info["kylshop"], FILE_APPEND);

                        if(!empty($fields["email"])){

                            preg_match_all('/\[attachment=([0-9]+):(.+?)\]/i', $goods_params["after_payment_post"], $attachments);

                            file_put_contents(ROOT_DIR . "/-tests_.txt", json_encode($goods_params, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT), FILE_APPEND);
                            /*$links = '';
                            if(!empty($attachments[2])){
                                foreach ($attachments[2] as $id => $attachment) {

                                    $links .= '<a href="'.$config['http_home_url'].'index.php?do=download&id='.$attachments[1][$id].'">-'.$attachments[2][$id].'</a><br>';
                                }
                            } else{

                                $links = $goods_params["after_payment_post"];
                            }

                            file_put_contents(ROOT_DIR . "/-links.txt", $links, FILE_APPEND);*/

                            file_put_contents(ROOT_DIR . "/-tests_2.txt", json_encode($fields, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT), FILE_APPEND);

                        }

                        // если есть запрос на перевод в группу
                        if(!empty($goods_params["after_payment_group"]) && ctype_digit($goods_params["after_payment_group"])){

                            // обновляем группу пользователя
                            $db->query( "UPDATE  " . USERPREFIX . "_users set user_group='{$goods_params["after_payment_group"]}' WHERE user_id = '{$order["user_id"]}'" );
                        }


                        // если нужно отнять кол-во товара
                        if(!empty($goods_params["ks_count_goods"]) && $goods_params["ks_count_goods_minus"] == "1"){

                            // отнимаем
                            $result_count = (int)$goods_params["ks_count"] - (int)$goods[$goods_info["id"]]["count"];

                            if($result_count < 0) $result_count = 0;

                            $goods_params["ks_count"] = $result_count;
                            $goods_params = serialize($goods_params);
                            $db->query( "UPDATE  " . USERPREFIX . "_post set kylshop='{$goods_params}' WHERE id = '{$goods_info["id"]}'" );
                        }


                        // если задано сообщение на почту
                        //if(!empty($goods_params["after_payment_post"])){

                        //}
                    }

                    // отправляем сообщение на почту владельцу новости
                    $mail_sendPaer = new dle_mail($config, 1);
                    $mail_sendPaer->send($fields["email"], "Заказ №" . $order["order_code"], "<h3>Спасибо за покупку Ваша ссылка на скачивание:</h3><br>" . $link_success);
                }

                if($_GET["payment"] == 'robokassa_success') die("OK$result\n");
                if($_GET["payment"] == 'freekassa_success') die("YES");

                // перенаправляем клиента по адресу в конфиге модуля оплаты
                if(!empty($config_payment->success_url)) header("Location: " . $config_payment->success_url);
                else header("Location: /");

                // если false
            } else{

                if(!empty($config_payment->fail_url)) header("Location: " . $config_payment->fail_url);
                else header("Location: /");
            }

            // если метода такого нет, просто перенаправляем пользователя на главную
        } else header("Location: " . $config_payment->success_url);
    }
}