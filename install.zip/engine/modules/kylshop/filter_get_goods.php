<?php
/**
 * ГЛАВНЫЙ ФАЙЛ МОДУЛЯ
 * @name этот файл подключается из modules/main.php в начале
 * */
if( !defined('DATALIFEENGINE') ) {
    header( "HTTP/1.1 403 Forbidden" );
    header ( 'Location: ../../' );
    die( "Hacking attempt!" );
}

header("Content-Type: text/html; charset=utf-8");

if(strripos($_SERVER["REQUEST_URI"], "?filter=") !== false && empty($_GET["filter"])){
    $_GET["filter"] = urldecode(explode("?filter=", $_SERVER["REQUEST_URI"])[1]);
}

if(!empty($_POST["get_goods"]) || !empty($_GET["filter"])){
    preg_match( '/WHERE(.+?)ORDER/i', $sql_select, $matches );
    $matches_count = explode("WHERE", $sql_count);

// $matches[1] - approve=1 AND allow_main=1 AND date < '2018-06-25 09:25:20'
    $matches[1] = trim($matches[1]);
    $matches_count[1] = trim($matches_count[1]);
    $filter_get = "";
    $filter_tmp = "";
    $filter_count = "";


    if(!empty($_POST["get_goods"])) $params = explode(";", $_POST["get_goods"]);
    else if(!empty($_GET["filter"])) $params = explode(";", $_GET["filter"]);

    $allow = true;
    $allow_other_params = false;
    $counter = count($params)-2;

    $i = 0;
    foreach ($params as $param) {

        if(!empty($param)){

            //$param = str_replace(["(", ")"], ["\(", "\)"], $param);

            $field = explode(":", $param);

            if($field[0] == "price"){

                $price = explode("-", $field[1]);
                $filter_get .= $matches[1] . " AND price >= '" . $price[0] . "' AND price <= '" . $price[1] . "'";
                $filter_count .= $matches_count[1] . " AND price >= '" . $price[0] . "' AND price <= '" . $price[1] . "'";

            } else{

                $allow_other_params = true;

                $field[1] = str_replace("-", "*", $field[1]);
                $isSlider = preg_match('/[0-9]+\-[0-9]+/i', $field[1], $match);

                if($isSlider){

                    $sliderParams = explode("-", $field[1]);

                    if($allow === true){
                        $filter_tmp .= " AND (";
                        $allow = false;
                    }

                    $sliderParams[0] = str_replace("*", "-", $sliderParams[0]);
                    $sliderParams[1] = str_replace("*", "-", $sliderParams[1]);

                    $filterName = strstr($param, ":", true);

                    for ($j = (int)(trim($sliderParams[0])); $j <= (int)(trim($sliderParams[1])); $j++) {

                        $filter_tmp .= "filter LIKE '%{$filterName}:{$j},%' OR ";
                    }

                } else{

                    if($allow === true){
                        $filter_tmp .= " AND (";
                        $allow = false;
                    }

                    $filter_tmp .= "filter LIKE '%{$param}%' OR ";
                }
            }

            if($allow_other_params === true){
                if($i == $counter) $filter_get .= substr($filter_tmp, 0, -4) . ")";
                if($i == $counter) $filter_count .= substr($filter_tmp, 0, -4) . ")";
            }
        }
        $i++;
    }

    /*echo "<pre>";
    print_r($sql_select);*/

    $sql_select = preg_replace( '/WHERE (.*?)ORDER/is', "WHERE $filter_get ORDER" , $sql_select );
    $sql_count = preg_replace( '/WHERE(.*?)$/i', "WHERE $filter_count" , $sql_count );

    /*echo "<br>";
    print_r($sql_select);
    echo "</pre>";
    exit;*/
//SELECT p.id, p.autor, p.date, p.short_story, CHAR_LENGTH(p.full_story) as full_story, p.xfields, p.title, p.category, p.alt_name, p.comm_num, p.allow_comm, p.fixed, p.tags, p.kylshop, p.filter, p.price, e.news_read, e.allow_rate, e.rating, e.vote_num, e.votes, e.view_edit, e.editdate, e.editor, e.reason FROM dle_post p INNER JOIN (SELECT DISTINCT(dle_post_extras_cats.news_id) FROM dle_post_extras_cats WHERE cat_id IN ('1','2','3','4')) c ON (p.id=c.news_id) LEFT JOIN dle_post_extras e ON (p.id=e.news_id) WHERE approve=1 AND date < '2020-02-21 19:35:31' AND price >= 0 AND price <= 5000 ORDER BY fixed desc, date DESC LIMIT 0,19


//    echo "<pre>";
//    print_r($sql_select);
//    echo "</pre>";
//    exit;
}