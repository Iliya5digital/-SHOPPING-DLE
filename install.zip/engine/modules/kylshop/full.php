<?php
/**
 * @name краткая новость
 */
if( !defined('DATALIFEENGINE') ) {
    header( "HTTP/1.1 403 Forbidden" );
    header ( 'Location: ../../' );
    die( "Hacking attempt!" );
}

header("Content-Type: text/html; charset=utf-8");

include (DLEPlugins::Check(ENGINE_DIR . '/modules/kylshop/config.php'));

$price = $price_sale = $sale = $sale_type = $filter = $related_goods = "";
$count = 1;
$count_orders = 0;
$counter_cart = '';

// если новость является платной
if(!empty($row["kylshop"]) && $member_id["user_group"] != "5" || $member_id["user_group"] == "5"){

    if(!empty($member_id["user_id"]) || (strrpos(strstr($_SERVER["REQUEST_URI"], "order"), "order") !== false)){

        $order_params = explode("-", trim(strstr($_SERVER["REQUEST_URI"], "order"), "order="));
        // [0] - secret_key
        // [1] - order_code

        if(!empty($order_params[0])){

            //$ks_config["order_guest_timer"] = 300;
            $order_guest_timer = explode("*", $ks_config["order_guest_timer"]);
            $seconds = 1;
            foreach ( $order_guest_timer as $time ) {
                $seconds = (int)$seconds * (int)$time;
            }
            $time_now = time();
            //$seconds = time() + $seconds;

            $goods = $db->super_query( "SELECT status, time FROM " . PREFIX . "_kylshop_buy WHERE order_code = '{$order_params[1]}' AND secret_key = '{$order_params[0]}' AND goods LIKE '%\"id\":\"{$row["id"]}\"%' AND (status = '1' OR status = '2')" );

            if(!empty($goods["time"]) && ($time_now - $goods["time"]) >= $seconds){
                unset($goods);
            }

        } else{

            # TODO нужно как-то продумать этот запрос поставить раньше, что бы он обрабатывался один раз
            # !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
            $goods = $db->super_query( "SELECT * FROM " . PREFIX . "_kylshop_buy WHERE user_id = '{$member_id["user_id"]}' AND goods LIKE '%\"id\":\"{$row["id"]}\"%' AND (status = '1' OR status = '2')" );
        }

    } else{
        $goods = ["status" => 0];
    }

    if(!empty($row["kylshop"])){

        $counter_cart = '<div class="ks_counter">
            <input type="number" name="ks_counter" data-ksid="'.$row["id"].'" min="1" value="1">
        </div>';

        $count_orders_ = $db->super_query( "SELECT COUNT(id) AS count FROM " . PREFIX . "_kylshop_buy WHERE goods LIKE '%\"id\":\"{$row["id"]}\"%' AND status = '1'" );
        $count_orders = $count_orders_["count"];

        $kylshop = unserialize($row["kylshop"]);


        // если пользователь не гость и есть другие цены для этой группы
        if($member_id["user_group"] != '5' && !empty($kylshop["ks_group"]) && array_search($member_id['user_group'], $kylshop["ks_group"]) !== false){

            $kylshop["ks_price"] = $kylshop["ks_group_price"][array_search($member_id['user_group'], $kylshop["ks_group"])];
        }

        // 1+1
        $data_params = '';
        if(!empty($kylshop["one_plus_one"])){

            $data_params = ' data-params=\''.json_encode($kylshop["one_plus_one"], JSON_UNESCAPED_UNICODE).'\'';

            $allowed_one_plus_one = false;
            foreach ( $kylshop["one_plus_one"] as $item ) {

                if($item[0] < date("H:i", time()) && $item[1] > date("H:i", time())){
                    $allowed_one_plus_one = true;
                }
            }

            if($allowed_one_plus_one === true){
                $tpl->set('[present]', "");
                $tpl->set('[/present]', "");
            } else $tpl->set_block( "'\\[present\\](.*?)\\[/present\\]'si", "" );

        } else{

            $tpl->set_block( "'\\[present\\](.*?)\\[/present\\]'si", "" );
        }

        // Дополнительные товары
        $data_addon = '';
        if(!empty($kylshop["addon"])){
            $data_addon = ' data-addon=\''.json_encode($kylshop["addon"], JSON_UNESCAPED_UNICODE).'\'';
        }

        /*echo "<pre>";
        print_r($kylshop["ks_price"]);
        echo "</pre>";
        exit;*/

        if(!empty($kylshop["related_id"])) $related_goods = $kylshop["related_id"];
        if(!empty($kylshop["ks_price"])) $price = $price_sale = $kylshop["ks_price"];

        $count = 0;

        // если есть скидка
        if(!empty($kylshop["ks_sale"])){

            $sale_type = $kylshop["ks_sale_type"];

            if($kylshop["ks_sale_type"] == "%") $price_sale = (float)$price - ((float)$price * (int)$kylshop["ks_sale"]) / 100;
            else $price_sale = (float)$price - (int)$kylshop["ks_sale"];

            $sale = (int)$kylshop["ks_sale"];
        }

        // если задано кол-во
        if(!empty($kylshop["ks_count_goods"]) && !empty($kylshop["ks_count"]))
            $count = (int)$kylshop["ks_count"];
        else $count = '-';

        $kylshop["ks_title"] = str_replace(['"', "'", "|"], "", $kylshop["ks_title"]);
        $price_sale = str_replace(['"', "'", "|"], "", $price_sale);

        // если этот товар куплен и присутствует текст после оплаты
        if($goods != null && $goods['status'] != 0 && !empty($kylshop["after_payment"])){

            // замена тегов
            $kylshop["after_payment"] = str_replace(
                [
                    "{id}",
                    "{order}",
                    "{total}"
                ],
                [
                    $goods["order_id"],
                    $goods["order_code"],
                    $goods["total"]
                ],
                $kylshop["after_payment"]
            );

            if($goods["status"] == "2"){
                $product = '<span class="on_moder">На модерации</span>';
            }
            else{
                $product = $kylshop["after_payment"];
            }

            // если товар не куплен
        } else{

            $product = '';
        }

        $variants = '|';
        if(!empty($kylshop["ks_variant_price"])){

            $variantsPrice = implode(",", $kylshop["ks_variant_price"]);
            $variantsCounter = implode(",", $kylshop["ks_variant_count"]);
            $variants .= $variantsPrice.'-'.$variantsCounter;
        }


        $link_go_payment = '<a href="/?do=cart" class="go_to_cart" data-goods="'.$row["id"].'|'.$kylshop["ks_title"].'|'.$price_sale.'|'.$count.'|'.$full_link.$variants.'"'.$data_params.$data_addon.'>Купить</a>';

        // если включена кнопка добавления товара в корзину
        if($ks_config["add_to_cart"] == true) $link_add_to_cart = '<a href="#" class="add_to_cart" id="goods_'.$row["id"].'" data-goods="'.$row["id"].'|'.$kylshop["ks_title"].'|'.$price_sale.'|'.$count.'|'.$full_link.$variants.'"'.$data_params.$data_addon.'>'.$ks_config["btn_title_add_to_cart"].'</a>';

        // если задан фильтр
        if(!empty($row["filter"])){

            $filter_colors = [];

            $filter_source = explode("||", $row["filter"]);
            if(strripos($filter_source[0], "**") !== false){
                $filter_colors_ = explode("**", $filter_source[0]);
                $filter_source[0] = $filter_colors_[0];
                $filter_colors_ = explode(";", $filter_colors_[1]);
                foreach ($filter_colors_ as $c) {
                    $c = explode(",", $c);
                    $filter_colors[$c[0]] = $c[1];
                }
            }
            $filter_prices = json_decode($filter_source[1], true);

            // если фильтр был задан
            if(!empty($filter_source[0])){
                $filter_row = explode(",", $filter_source[0]);
                $filter_data = [];
                foreach ($filter_row as $item2) {
                    $exp = explode(":", $item2);
                    if(!empty($exp[1])) $filter_data[$exp[0]][] = $exp[1];
                }
            }

            $filter_file = json_decode(file_get_contents(ENGINE_DIR . '/modules/kylshop/filter.json'), true);
            $filter_prices = json_decode($filter_source[1], true);

            $tmp_filter = [];
            foreach ($filter_file["value"] as $key_title => $item) {
                $j = 0;
                foreach ($item as $it) {

                    if(!empty($it)){
                        if(!empty($filter_prices[$key_title."_".$j])){
                            $tmp_filter[$it] = ["title" => $it, "price" => $filter_prices[$key_title."_".$j]];
                        } else{
                            $tmp_filter[$it] = ["title" => $it, "price" => $price];
                        }
                    }
                    $j++;
                }
            }

            $filter_array = [];
            $filter = '<ul class="filter_short" data-original-price="'.$price.'">';
            $filter_ = explode(",", $filter_source[0]);
            foreach ($filter_ as $filter_item) {
                if(!empty($filter_item)){
                    $filter_exp = explode(":", $filter_item);
                    $filter_array[$filter_exp[0]][] = $filter_exp[1];
                }
            }

            $i = 0;
            if(!empty($filter_array)){

                foreach ($filter_array as $key => $item_f) {
                    $filter .= '<li><p>'.$key.':</p> <ul>';

                    foreach ($item_f as $f) {

                        if($price == $tmp_filter[$f]["price"]) $tmp_filter[$f]["price"] = 0;

                        # переделать, сделано по быстрому
                        # картинки
                        if(strripos($f, "=") !== false || strripos($f, ".jpg") !== false || strripos($f, ".jpeg") !== false || strripos($f, "png") !== false){
                            $f = explode("|+", $f);
                            $img = $f[0];
                            $imgPrice = !empty($f[1]) ? $f[1] : '0';
                            $filter .= '<li data-id="'.$row["id"].'_'.$i.'" data-price="'.$imgPrice.'" class="filter_img"><img src="'.$img.'" alt=""></li>';

                        } else $filter .= '<li data-id="'.$row["id"].'_'.$i.'" data-price="'.$tmp_filter[$f]["price"].'">'.$f.'</li>';

                        $i++;
                    }
                    $filter .= '</ul></li>';
                }
            }

            if(!empty($filter_colors)){

                $filter .= '<li class="li_filter_color"><p>Цвет:</p> <ul>';

                foreach ($filter_colors as $color => $color_price) {

                    $filter .= '<li data-id="'.$row["id"].'_'.$i.'" data-price="'.$color_price.'" data-color="'.$color.'" class="filter_color"><div style="background:'.$color.'"></div></li>';
                    $i++;
                }
                $filter .= '</ul></li>';
            }


            $filter .= '</ul>';

        }
    }
}

// PRICE
if(!empty($price)){
    $tpl->set('{price}', $price);
    $tpl->set('[price]', "");
    $tpl->set('[/price]', "");
} else{
    $tpl->set_block( "'\\[price\\](.*?)\\[/price\\]'si", "" );
}
// PRICE NOT
if(!empty($price)){
    $tpl->set_block( "'\\[not-price\\](.*?)\\[/not-price\\]'si", "" );
} else{
    $tpl->set('[not-price]', "");
    $tpl->set('[/not-price]', "");
}

// SALE
if(!empty($sale)){
    $tpl->set('{sale}', $sale);
    $tpl->set('[sale]', "");
    $tpl->set('[/sale]', "");
} else{
    $tpl->set_block( "'\\[sale\\](.*?)\\[/sale\\]'si", "" );
}
// SALE NOT
if(!empty($sale)){
    $tpl->set_block( "'\\[not-sale\\](.*?)\\[/not-sale\\]'si", "" );
} else{
    $tpl->set('[not-sale]', "");
    $tpl->set('[/not-sale]', "");
}

// если есть похожие товары
if($related_goods){
    $tpl->set('[related-goods]', "");
    $tpl->set('[/related-goods]', "");
} else{
    $tpl->set_block( "'\\[related-goods\\](.*?)\\[/related-goods\\]'si", "" );
}


if(empty($price)){
    $link_add_to_cart = "";
    $link_go_payment = "";
}


$tpl->set('{price-sale}', $price_sale);
$tpl->set('{price}', $price);
$tpl->set('{sale}', $sale);
$tpl->set('{sale-type}', $sale_type);
$tpl->set('{count}', $count);
$tpl->set('{currency}', $ks_config["currency"]);
$tpl->set('{filter}', $filter);
$tpl->set('{go-payment}', $link_go_payment);
$tpl->set('{count-orders}', $count_orders);
$tpl->set('{add-cart}', $link_add_to_cart);
$tpl->set('{related-goods}', $related_goods);
$tpl->set('{counter}', $counter_cart);
$tpl->set('{product}', $product);