<?php
if( !defined('DATALIFEENGINE') ) {
    header( "HTTP/1.1 403 Forbidden" );
    header ( 'Location: ../../' );
    die( "Hacking attempt!" );
}

class Example{

    private $config_this = [];
    private $config = [];


    // такой конструктор должен быть у всех платежных модулей
    public function __construct($config_this, $config)
    {
        $this->config_this = $config_this;
        $this->config = $config;
    }


    /**
     * @param $id - id записи в таблице kylshop_buy
     * @param $total - сумма заказа
     * @return string
     */
    public function init($id, $total){

         return '<form action="" method="POST">
            <input type="submit" class="payment_btn" value="Перейти к оплате">
        </form>';
    }


    /**
     * @name метод, который проверяет прошел ли платеж или нет
     * возвращает true если платеж прошел и false если не прошел
     * @return bool
     */
    public function success(){

        return true;
    }
}