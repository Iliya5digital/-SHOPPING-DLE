<?php
if( !defined('DATALIFEENGINE') ) {
    header( "HTTP/1.1 403 Forbidden" );
    header ( 'Location: ../../' );
    die( "Hacking attempt!" );
}

class Mykassa{

    private $config_this = [];
    private $config = [];


    // такой конструктор должен быть у всех платежных модулей
    public function __construct($config_this, $config){
        $this->config_this = $config_this;
        $this->config = $config;
    }


    /**
     * @param $id - id записи в таблице kylshop_buy
     * @param $total - сумма заказа
     * @param $secret_key - секрет
     * @param $data - данные переданные с формы
     * @return string
     */
    public function init($id, $total, $secret_key, $data, $goods){

        $goods = json_decode($goods, true);
        if (count($goods) == 1) $description = "Приобретение: " . array_shift($goods)["title"];
        else $description = "Оплата заказа №" . $id;

        $data = json_decode($data, true);

        $email = "";
        if(!empty($data["email"])) $email = $data["email"];
        if(!empty($data["Email"])) $email = $data["Email"];

        return '<form action="https://my-kassa.com/kassa/pay" method= "POST"> 
        <input type="hidden" name= "amount" value= "'.$total.'">
        <input type="hidden" name= "payment" value= "'.$id.'">
        <input type="hidden" name= "merchant" value= "'.$this->config_this->merchant_id.'">
        <input type="hidden" name= "desc" value="'.$description.'">
        <input type="hidden" name= "email" value= "'.$email.'">
        
        <input type="hidden" name= "comment" value= "комментарий к заказу">
        <input type="submit" target="_blank" class="payment_btn" value="Перейти к оплате">
        </form>';
    }


    /**
     * @name метод, который проверяет прошел ли платеж или нет
     * возвращает id заказа если платеж прошел и false если не прошел
     * @return bool
     */
    public function success(){

        $postData = file_get_contents('php://input');

        if(!empty($postData)){

            function getIP() {
                if(isset($_SERVER['HTTP_X_REAL_IP'])) return $_SERVER['HTTP_X_REAL_IP'];
                return $_SERVER['REMOTE_ADDR'];
            }

            if (!in_array(getIP(), array('192.162.246.54'))) die("hacking attempt!");

            setLog($_SERVER, '_SERVER_'.time());
            setLog($this->config_this->secret, 'SECRET');

            setLog($postData, '_postData_'.time());

            $data = json_decode($postData, true);

            setLog($data, '_data_'.time());

            $array = array (

                $this->config_this->secret,
                $merchant = $data['merchant'],
                $payment  = $data['payment'],
                $amount   = $data['amount']

            );

            setLog($array, '_array_'.time());

            $sign = md5 ( implode ( ':', $array ));

            if ($sign != $data['sign']) die( 'Подпись не совпадает.' );

            setLog($sign, 'sign');

            return $data['payment'];

        }

        header("Location: /");
        die("OK");
    }
}