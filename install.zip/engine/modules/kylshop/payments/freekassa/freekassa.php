<?php
if( !defined('DATALIFEENGINE') ) {
    header( "HTTP/1.1 403 Forbidden" );
    header ( 'Location: ../../' );
    die( "Hacking attempt!" );
}

class Freekassa{

    private $config_this = [];
    private $config = [];


    // такой конструктор должен быть у всех платежных модулей
    public function __construct($config_this, $config)
    {
        $this->config_this = $config_this;
        $this->config = $config;
    }


    /**
     * @param $id - id записи в таблице kylshop_buy
     * @param $total - сумма заказа
     * @param $secret_key - секрет
     * @param $data - данные переданные с формы
     * @return string
     */
    public function init($id, $total, $secret_key, $data){

        $data = json_decode($data, true);

        $email = "";
        if(!empty($data["email"])) $email = $data["email"];
        if(!empty($data["Email"])) $email = $data["Email"];
        if(!empty($email)) $email = "&em=" . $email;

        $merchant_id = $this->config_this->shop_id;
        $secret_word = $this->config_this->freekassa_word1;
        $currency = 'RUB';
        $sign = md5($merchant_id.':'.$total.':'.$secret_word.':'.$currency.':'.$id);


        $freekassa_url = "https://pay.freekassa.ru/?m=" . $this->config_this->shop_id . "&oa=" . $total . "&o=" . $id . "&currency=$currency&s=" . $sign . "&us_key=" . $secret_key . $email;

        return '<a href="'.$freekassa_url.'" target="_blank" class="payment_btn">Перейти к оплате</a>';
    }


    /**
     * @name метод, который проверяет прошел ли платеж или нет
     * возвращает id заказа если платеж прошел и false если не прошел
     * @return bool
     */
    public function success(){

        # MERCHANT_ID - ID магазина
        # MERCHANT_ORDER_ID - номер заказа в магазине
        # AMOUNT - сумма заказа
        # SIGN - подпись
        # intid - Номер операции Free-Kassa
        if(!empty($_POST["MERCHANT_ORDER_ID"]) && !empty($_POST["AMOUNT"]) && !empty($_POST["SIGN"])) {

            //setLog($_SERVER, 3);

            function getIP() {
                if(isset($_SERVER['HTTP_X_REAL_IP'])) return $_SERVER['HTTP_X_REAL_IP'];
                return $_SERVER['REMOTE_ADDR'];
            }

            if (!in_array(getIP(), array('168.119.157.136', '168.119.60.227', '138.201.88.124', '178.154.197.79'))) die("hacking attempt!");

            // подпись
            $sign = md5($this->config_this->shop_id.':'.$_REQUEST['AMOUNT'].':'.$this->config_this->freekassa_word2.':'.$_REQUEST['MERCHANT_ORDER_ID']);

            if ($sign != $_REQUEST['SIGN']) return false;

            return $_POST["MERCHANT_ORDER_ID"];
        }

        return false;
    }
}