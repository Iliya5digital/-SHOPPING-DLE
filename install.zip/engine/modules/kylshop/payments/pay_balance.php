<?php
if( !defined('DATALIFEENGINE') ) {
    header( "HTTP/1.1 403 Forbidden" );
    header ( 'Location: ../../' );
    die( "Hacking attempt!" );
}

if(!empty($_POST["allow"]) && $_POST["allow"] == "ok" && !empty($_COOKIE["pay_id"]) && $_POST["pay_id"] == $_COOKIE["pay_id"]){


    $ne_balance = str_replace(",", ".", round(floatval($member_id['balance']) - floatval($_POST["pay_sum"]), 2));

    $db->query( "UPDATE  " . PREFIX . "_kylshop_buy set status = '1' WHERE id = '{$_POST["pay_id"]}'" );
    $db->query( "UPDATE  " . USERPREFIX . "_users set balance = '{$ne_balance}' WHERE user_id = '{$member_id["user_id"]}'" );


    SetCookie("pay_id", "", time() - (3600 * 10000), "/");
    header("Location:".$ks_config["redirect_after_balance"]);
    exit;
}

SetCookie("pay_id", (int)$_POST["pay_id"], time() + 3600 * 24 * 7, "/");

$form = '<form action method="post">
    <input type="hidden" name="pay_balance" value="ok">
    <input type="hidden" name="allow" value="ok">
    <input type="hidden" name="pay_id" value="'.$_POST["pay_id"].'">
    <input type="hidden" name="pay_sum" value="'.$_POST["pay_sum"].'">
    <input type="submit" class="payment_btn" value="Подтвердить">
</form>';

$balance = $member_id['balance'];
$minus = $_POST["pay_sum"];
$result = str_replace(",", ".", round(floatval($member_id['balance']) - floatval($_POST["pay_sum"]), 2));

$tpl -> load_template( 'kylshop/pay_balance.tpl' );
$tpl -> set('{balance}', $balance);
$tpl -> set('{minus}', $minus);
$tpl -> set('{result}', $result);
$tpl -> set('{form}', $form);
$tpl -> set('{currency}', $ks_config["currency"]);
$tpl -> compile( 'content' );
$tpl -> clear();