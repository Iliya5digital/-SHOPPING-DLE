<?php
/**
 * @name краткая новость
 */
if( !defined('DATALIFEENGINE') ) {
    header( "HTTP/1.1 403 Forbidden" );
    header ( 'Location: ../../' );
    die( "Hacking attempt!" );
}

header("Content-Type: text/html; charset=utf-8");

include (DLEPlugins::Check(ENGINE_DIR . '/modules/kylshop/config.php'));


// переменная, отображающая форму создания товара
$usertag = "";

// переменная должна содержать серриализованый массив для записи в базу в поле kylshop
$kylshop_post = "";

if(!empty($_POST["ks_power"])){

    $kylshop = [];

    // если товар включен
    if(!empty($_POST["ks_power"])){

        $kylshop_post = [
            "power" => "1",
            "ks_title" => $_POST["ks_title"],
            "ks_price" => $_POST["ks_price"],
            "ks_sale" => $_POST["ks_sale"],
            "ks_sale_type" => $_POST["ks_sale_type"],
            "ks_count_goods" => $_POST["ks_count_goods"],
            "ks_count" => $_POST["ks_count"],
            "ks_count_goods_minus" => $_POST["ks_count_goods_minus"],
            "after_payment" => $_POST["after_payment"],
            "after_payment_post" => $_POST["after_payment_post"],
            "after_payment_group" => $_POST["after_payment_group"]
        ];

    }

    $kylshop_post = serialize($kylshop_post);

    $filter_post = "";

    // если есть фильтр
    if(!empty($_POST["ks_filter_power"])){

        $filter = json_decode(file_get_contents(ENGINE_DIR . '/modules/kylshop/filter.json'), true);

        foreach ($_POST as $key => $item) {
            if(strripos($key, "filter__") !== false){

                $key = substr(strstr($key, "__"), 2); // получаем чистый ключ
                foreach ($_POST["filter__".$key] as $item_min) {
                    $filter_post .= $filter["title"][$key][0] . ":" . $item_min . ",";
                }
            }
        }
        $filter_post = substr($filter_post, 0, -1);
    }
}


// если включена настройка вывода формы в паблике
// и это админ или группа пользователей, которым разрешено...
$allow_add_group = explode(",", $ks_config["allow_add_group"]);
if($ks_config["add_shop_on_public"] == true && array_search($member_id["user_group"], $allow_add_group) !== false || $ks_config["add_shop_on_public"] == true && $member_id["user_group"] == "1"){

    // группы пользователей
    $groups_sourse = $db->super_query( "SELECT id, group_name FROM " . PREFIX . "_usergroups WHERE id != 5", true );
    $groups = '';
    foreach ($groups_sourse as $item) {
        if($kylshop["after_payment_group"] == $item["id"])
            $groups .= '<option value="'.$item["id"].'" selected>'.$item["group_name"].'</option>';
        else
            $groups .= '<option value="'.$item["id"].'">'.$item["group_name"].'</option>';
    }


    // переменная, отображающая форму создания товара
    $usertag = '<div class="checkbox">
        <label><input type="checkbox" name="ks_power" id="ks_power" value="1">Сделать платным</label>
    </div>
    
    <div class="is_goods">
    
        <div class="flex">
            <label>Название товара:</label>
            <input type="text" name="ks_title" id="ks_title" maxlength="250">
            <a href="#" id="source_title" class="fa fa-reply" aria-hidden="true" title="Взять из заголовка"></a>
        </div>
    
        <div class="flex">
            <label>Цена:</label>
            <div class="ks_right_box">
            
                <div class="flex">
                    <div>
                        <input type="text" style="width: 155px;" name="ks_price" id="ks_price" maxlength="50">
                    </div>
                    <div class="pad_min">
                        <label for="ks_sale">Скидка:</label>
                        <input type="text" style="width: 55px;" name="ks_sale" id="ks_sale" maxlength="2">
                    </div>
                    <div class="pad_min">
                        <label for="sale_type">Тип скидки:</label>
                        <select name="ks_sale_type" id="ks_sale_type">
                            <option value="%">%</option>
                            <option value="fix">цена</option>
                        </select>
                    </div>
                </div>
                
            </div>
        </div>
        
        <div class="flex">
            <label>Количество:</label>
            <div class="ks_right_box">
            
                <label><input class="icheck" type="checkbox" id="ks_count_goods" name="ks_count_goods" value="1"> Задать кол-во</label>
                
                <div id="count_goods" class="flex">
                    <div>
                        <label for="ks_sale">Количество:</label>
                        <input type="text" style="width: 80px;" name="ks_count" id="ks_count" maxlength="10">
                    </div>
                    <div class="pad_min">
                        <label><input class="icheck" type="checkbox" id="ks_count_goods_minus" name="ks_count_goods_minus" value="1"> Отнимать кол-во после покупки</label>
                    </div>
                    
                </div>
                
            </div>
        </div>';

    $usertag .= '<!-- Фильтры -->
        <div class="flex">
            <label>Фильтры:</label>
            <div class="ks_right_box">
            
                <div class="checkbox">
                    <label><input class="icheck" type="checkbox" id="ks_filter_power" name="ks_filter_power" value="1"> вкл.</label>
                </div>
                
                <div id="filter">
                    
                    <div class="flex">';


$filter_file = ENGINE_DIR . '/modules/kylshop/filter.json';
$filter = file_get_contents($filter_file);
$fields = "";

// перебираем поля
if(!empty($filter)){

    $filter = json_decode($filter, true);

    foreach ($filter["title"] as $key => $row1) {

        $usertag .= '<div class="w33">
            <label for="filter_color">'.$row1[0].'</label>
            <ul>';

        foreach ($filter["value"][$key] as $row2) {
            $usertag .= '<li>
                <div class="checkbox">
                    <label><input class="icheck" type="checkbox" name="filter__'.$key.'[]" value="'.$row2.'"> '.$row2.'</label>
                </div>
            </li>';
        }
        $usertag .= '</ul>
        </div>';

    }
}

    $usertag .= '</div>
                </div>
            </div>
        </div>
        <!-- Фильтры .-->
        
        
        
        <!-- Действия после оплаты -->
        <div class="flex">
            <label>После оплаты:</label>
            <div class="clr"></div>
            <div class="flex">
                <div class="w50">
                    <label for="after_payment">Показть вместо кнопок (купить) и (добавить в корзину):</label>
                    <textarea name="after_payment" id="after_payment" rows="4"></textarea>
                    <p class="description_min">Если оставить пустым, никаких изменений в товаре происходить не будет. Пользователь сможет купить товар повторно. Можно использовать html.</p>
                </div>
                <div class="w50">
                    <label for="after_payment">Отправить на почту:</label>
                    <textarea name="after_payment_post" id="after_payment_post" rows="4"></textarea>
                    <p class="description_min">Если оставить пустым, сообщение на почту отправляться не будет. Можно использовать html.</p>
                </div>
            </div>
            
            <div class="flex">
                <div>
                    <label for="after_payment">Переводить в группу: &nbsp;&nbsp;</label>
                    <select name="after_payment_group" id="after_payment_group" class="uniform">
                        <option value="">-- Выбрать --</option>
                        '.$groups.'
                    </select>
                </div>
            </div>
                
        </div>
        
    </div>';
}