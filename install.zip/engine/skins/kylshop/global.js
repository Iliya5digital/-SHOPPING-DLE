$(function(){

    function getNewOrders(){

        $.ajax({
            type: 'GET',
            url: '?mod=kylshop&act=get_gm',
            dataType: 'text',
            success: function(data){

                if(data){

                    data = JSON.parse(data);

                    let content = '<div class="new_orders">';
                    let count = data.length;
                    let i = 1;
                    let currency = data[count-1].currency;
                    for(let key in data){

                        if(i < count){
                            console.log(data[key]);
                            content += '<a href="?mod=kylshop&act=&order='+data[key].order_id+'" class="new_order">' +
                                '<span class="order_code">'+data[key].order_code+'</span>' +
                                '<span class="order_total"><i>'+data[key].time+'</i><b>'+data[key].total+' '+currency+'</b></span>' +
                                '<span class="order_close"></span>' +
                            '</a>';
                        }
                        i++;
                    }
                    content += '</div>';

                    if($(".new_orders").length > 0) $(".new_orders").html(content);
                    else $("body").append(content);

                    let countOrders = localStorage.getItem("countOrders");

                    if(countOrders == null || countOrders != count){
                        if(window.location.href.indexOf("&order=") + 1) return
                        else{
                            let audio = new Audio('engine/skins/kylshop/cash.mp3');
                            audio.play();
                        }
                    }

                    localStorage.setItem("countOrders", count);
                } else localStorage.setItem("countOrders", null);
            },
            error: function(data){
                console.log(data);
            }
        });
    }

    getNewOrders();

    setInterval(function(){
        getNewOrders();
    }, 10000)

})