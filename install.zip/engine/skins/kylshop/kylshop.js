/*=== Alert ===*/
// https://www.jqueryscript.net/demo/Mobile-friendly-Dialog-Toast-Plugin-With-jQuery-alert-js/
!function ($) {
    $._isalert=0,
        $.alert=function(){
            if(arguments.length){
                $._isalert=1;
                return $.confirm.apply($,arguments);
            }
        },
        $.confirm=function(){
            var args=arguments;
            if(args.length){
                var d =$('<div class="alert_overlay esc"></div><div class="alert_msg esc"><div class="alert_content">'+args[0]+'</div><div class="alert_buttons"><button class="alert_btn alert_btn_ok">Да</button><button class="alert_btn alert_btn_cancel">Отмена</button></div></div>'),
                    fn=args[1],
                    flag=1,
                    _click = function(e){
                        typeof fn=='function'?(fn.call(d,e.data.r)!=!1&&d.remove()):d.remove();
                    };
                $._isalert&&d.find('.alert_btn_cancel').hide();
                d.on('contextmenu',!1)
                    .on('click','.alert_btn_ok',{r:!0},_click)
                    .on('click','.alert_btn_cancel',{r:!1},_click)
                    .appendTo('body');
            }
            $._isalert=0;
        },
        $.tips=function(m){
            $('.alert_tips').remove();
            $('<div class="alert_tips"><div>'+m+'</div></div>').appendTo('body').one('webkitAnimationEnd animationEnd',function(){$(this).remove()})
        }
}($);



$(function(){

    var $url = window.location.href;

    $('.ks_sidebar a').each(function () {
        var location = window.location.href;
        var link = this.href;
        if(location == link) {
            $(this).addClass('active');
        }
    });

    // добавление полей для формы
    $(document).on("click", ".add_field", function(){

        var field_type = $(".field_type option:selected").val();
        var content = '';

        var unique_id = new Date();
        unique_id = unique_id.getTime();

        switch (field_type) {

            case "input":
            case "textarea":

                var title = "Одна строка";
                if(field_type == "textarea") title = "Несколько строк";

                content = '<div class="row">\n' +
                    '<p class="title_field">'+title+' <span class="code_field">{_'+unique_id+'}</span></p>' +
                    '<input type="hidden" name="'+unique_id+'[type]" value="'+field_type+'">\n' +
                    '<div class="col-md-3"><input type="text" name="'+unique_id+'[title]" class="form-control" placeholder="Название поля"></div>\n' +
                    '<div class="col-md-3"><input type="text" name="'+unique_id+'[attr]" class="form-control" placeholder="Атрибуты"></div>\n' +
                    '<div class="col-md-3"><input type="text" name="'+unique_id+'[admin]" class="form-control" placeholder="Название для админа"></div>\n' +
                    '<div class="col-md-2">\n' +
                        '<label><input type="checkbox" name="'+unique_id+'[required]"> Обязательное</label><br>\n' +
                        '<label><input type="checkbox" name="'+unique_id+'[post]"> Отправлять на почту</label>\n' +
                    '</div>\n' +
                    '<div class="col-md-1">\n' +
                        '<a href="#" class="fa fa-close delete_field"></a>\n' +
                        '<div class="arrows">\n' +
                            '<a href="#" class="fa fa-angle-up up"></a>\n' +
                            '<a href="#" class="fa fa-angle-down down"></a>\n' +
                        '</div>\n' +
                    '</div>\n' +
                '</div>';
                break;

            case "select":
                content = '<div class="row">\n' +
                    '<p class="title_field">Список <span class="code_field">{_'+unique_id+'}</span></p>' +
                    '<input type="hidden" name="'+unique_id+'[type]" value="select">\n' +
                    '<div class="col-md-3"><br><br><br><input type="text" name="'+unique_id+'[title]" class="form-control" placeholder="Название поля"></div>\n' +
                    '<div class="col-md-3"><input type="text" name="'+unique_id+'[attr]" class="form-control" placeholder="Атрибуты"></div>\n' +
                    '<div class="col-md-3"><br><br><br><input type="text" name="'+unique_id+'[admin]" class="form-control" placeholder="Название для админа"></div>\n' +
                    '<div class="col-md-1">\n' +
                        '<textarea name="'+unique_id+'[values]" class="form-control" rows="4" placeholder="Каждое новое значение с новой строки. Поставьте в этой строке звездочку *, если нужно сделать его выбранным по умолчанию."></textarea>\n' +
                    '</div>\n' +
                    '<div class="col-md-2">\n' +
                        '<label><input type="checkbox" name="'+unique_id+'[required]"> Обязательное</label><br>\n' +
                        '<label><input type="checkbox" name="'+unique_id+'[post]"> Отправлять на почту</label>\n' +
                    '</div>\n' +
                    '<div class="col-md-1">\n' +
                        '<a href="#" class="fa fa-close delete_field"></a>\n' +
                        '<div class="arrows">\n' +
                            '<a href="#" class="fa fa-angle-up up"></a>\n' +
                            '<a href="#" class="fa fa-angle-down down"></a>\n' +
                        '</div>\n' +
                    '</div>\n' +
                '</div>';
                break;

            case "checkbox":
                content = '<div class="row">\n' +
                    '<p class="title_field">Переключатель \'Да\' или \'Нет\' <span class="code_field">{_'+unique_id+'}</span></p>' +
                    '<input type="hidden" name="'+unique_id+'[type]" value="checkbox">\n' +
                    '<div class="col-md-3"><input type="text" name="'+unique_id+'[title]" class="form-control" placeholder="Название поля"></div>\n' +
                    '<div class="col-md-3"><input type="text" name="'+unique_id+'[attr]" class="form-control" placeholder="Атрибуты"></div>\n' +
                    '<div class="col-md-3"><input type="text" name="'+unique_id+'[admin]" class="form-control" placeholder="Название для админа"></div>\n' +
                    '<div class="col-md-2">\n' +
                        '<label><input type="checkbox" name="'+unique_id+'[required]"> Обязательное</label><br>\n' +
                        '<label><input type="checkbox" name="'+unique_id+'[post]"> Отправлять на почту</label><br>\n' +
                        '<label><input type="checkbox" name="'+unique_id+'[power]"> Включено</label>\n' +
                    '</div>\n' +
                    '<div class="col-md-1">\n' +
                        '<a href="#" class="fa fa-close delete_field"></a>\n' +
                        '<div class="arrows">\n' +
                            '<a href="#" class="fa fa-angle-up up"></a>\n' +
                            '<a href="#" class="fa fa-angle-down down"></a>\n' +
                        '</div>\n' +
                    '</div>\n' +
                '</div>';
                break;

            case "file":
                content = '<div class="row">\n' +
                    '<p class="title_field">Файл <span class="code_field">{_'+unique_id+'}</span></p>' +
                    '<input type="hidden" name="'+unique_id+'[type]" value="file">\n' +
                    '<div class="col-md-3"><input type="text" name="'+unique_id+'[title]" class="form-control" placeholder="Название поля"></div>\n' +
                    '<div class="col-md-6"><input type="text" name="'+unique_id+'[extension]" class="form-control" placeholder="Расширения файлов через запятую"></div>\n' +
                    '<div class="col-md-2">\n' +
                        '<label><input type="checkbox" name="'+unique_id+'[required]"> Обязательное</label>\n' +
                    '</div>\n' +
                    '<div class="col-md-1">\n' +
                        '<a href="#" class="fa fa-close delete_field"></a>\n' +
                        '<div class="arrows">\n' +
                            '<a href="#" class="fa fa-angle-up up"></a>\n' +
                            '<a href="#" class="fa fa-angle-down down"></a>\n' +
                        '</div>\n' +
                    '</div>\n' +
                '</div>';
                break;
        }

        $(".constructor").append(content);

        return false;
    })

    // удаление доп полей из формы
    $(document).on("click", ".delete_field", function(){
        $(this).parents(".row").remove();
        return false;
    })

    // перестановка блоков
    $(document).on('click', '.down', function() {
        $(this).closest('.row').insertAfter($(this).closest('.row').next());
        return false;
    });
    $(document).on('click', '.up', function() {
        $(this).closest('.row').insertBefore($(this).closest('.row').prev());
        return false;
    });

    // изменение статуса
    $(document).on("change", ".select_status", function(){

        var id = $(this).data("id");
        var status = $(this).val();

        if(status == "0"){
            $.alert("Сделайте выбор!");
            return false;
        }

        $.ajax({
            type: 'POST',
            url: $url,
            data: {
                "id": id,
                "edit_status": status
            },
            dataType: 'text',
            success: function(data){
                $.alert(data);
            },
            error: function(data){
                console.log(data);
            }
        });

        return false;
    })


    // добавление фильтра
    $(document).on("click", "#add_filter", function(){

        let unique_id = new Date();
        let categoriesOptions = $('.categoriesOptions').html();
        unique_id = unique_id.getTime();

        $(".filters").append('<div class="row">\n' +
                '<div class="col-md-6 cats_filter">\n' +
                    '<select name="categories['+unique_id+'][]" data-placeholder="Выберете" class="categoryselect" multiple style="width:100%;max-width:350px;">\n' +
                categoriesOptions +
                    '</select>\n' +
                '</div>' +
                '<div class="col-md-6 fields_filter">\n' +
                    '<input type="text" name="title['+unique_id+'][]" class="form-control" placeholder="Название фильтра"><a href="#" class="fa fa-remove remove_filter"></a>\n' +
                '</div>\n' +
                '<div class="col-md-6 fields">\n' +
                    '<input type="text" name="value['+unique_id+'][]" class="form-control" placeholder="Значение"><a href="#" class="fa fa-remove remove_field"></a>\n' +
                    '<a href="#" class="fa fa-plus add_val" data-unique_id="'+unique_id+'"></a>\n' +
                '</div>\n' +
                '<div class="col-md-6 slider_filter">\n' +
                    '<input class="switch" type="checkbox" name="slider['+unique_id+'][]" id="is_slider_'+unique_id+'" value="1" data-switchery="true"> &nbsp; \n' +
                    '<label for="is_slider_'+unique_id+'"><b>слайдер</b></label>\n' +
                '</div>\n' +
                '<div class="col-md-3 img_filter">\n' +
                    '<input class="switch" type="checkbox" name="color['+unique_id+'][]" id="is_color_'+unique_id+'" value="1" data-switchery="true"> &nbsp; \n' +
                    '<label for="is_color_'+unique_id+'"><b>цвет</b></label>\n' +
                '</div>\n' +
                '<div class="col-md-3 img_filter">\n' +
                    '<input class="switch" type="checkbox" name="img['+unique_id+'][]" id="is_img_'+unique_id+'" value="1" data-switchery="true"> &nbsp; \n' +
                    '<label for="is_img_'+unique_id+'"><b>изображения</b></label>\n' +
                '</div>\n' +
            '</div>');
        $(".categoryselect").chosen();
        return false;
    })

    // добавление значения фильтра
    $(document).on("click", ".add_val", function(){
        var unique_id = $(this).data("unique_id");
        $(this).before('<input type="text" name="value['+unique_id+'][]" class="form-control" placeholder="Значение"><a href="#" class="fa fa-remove remove_field"></a>');
        $(this).prev().prev().focus();
        return false;
    })

    // удаление фильтра
    $(document).on("click", ".remove_filter", function(){
        $(this).parents(".row").remove();
        return false;
    })

    // удаление значения фильтра
    $(document).on("click", ".remove_field", function(){
        $(this).prev().remove();
        $(this).remove();
        return false;
    })


    /**
     * @name DELIVERY (MAP)
     */

    if($("#map").length > 0){
        var locationSet = {lat: 0, lng: 0};
        var mapZoom = 5;

        var delivery_mapInfo = $("#delivery_mapInfo").val();
        if(delivery_mapInfo){
            delivery_mapInfo = JSON.parse(delivery_mapInfo);
            locationSet = {lat: delivery_mapInfo.lat, lng: delivery_mapInfo.lng};
            mapZoom = delivery_mapInfo.zoom;
        }

        map = new google.maps.Map(document.getElementById("map"), {
            zoom: mapZoom, // 7
            center: locationSet,
        });

        // получаем координаты и zoom карты в данный момент
        function getMapInfo(){
            var data = {};
            data.lat = map.getCenter().lat();
            data.lng = map.getCenter().lng();
            data.zoom = map.getZoom();
            return data;
        }

        // если браузер поддерживает геоданные, то выводим точку местоположения пользователя
        function my_location(){
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(function(position) { // watchPosition getCurrentPosition

                    var myPosition = {
                        lat: position.coords.latitude,
                        lng: position.coords.longitude
                    };

                    map.setCenter(myPosition); // установка координат центра
                    map.setZoom(16); // увеличим карту

                    // если маркер уже наш есть, двигаем его
                    if(typeof marker !== 'undefined'){

                        // marker.setPosition(myPosition);
                        // marker.setIcon('/img/local.svg');

                        // ставим маркер места положения
                        marker = new google.maps.Marker({
                            position: myPosition,
                            map: map,
                            icon: '/engine/skins/kylshop/img/local.svg',
                            //draggable: true, // разрешает перетаскивать маркер
                            animation: google.maps.Animation.DROP, // анимация (маркер падает) DROP - падает, BOUNCE - прыгает
                        });

                    } else{

                        // ставим маркер места положения
                        marker = new google.maps.Marker({
                            position: myPosition,
                            map: map,
                            icon: '/engine/skins/kylshop/img/local.svg',
                            //draggable: true, // разрешает перетаскивать маркер
                            animation: google.maps.Animation.DROP, // анимация (маркер падает) DROP - падает, BOUNCE - прыгает
                        });
                    }

                }, function() {
                    handleLocationError(true, infoWindow, map.getCenter());
                });
            } else {
                // Browser doesn't support Geolocation
                handleLocationError(false, infoWindow, map.getCenter());
            }
        }

        //my_location();

        // узнать мое местоположение
        $(document).on("click", "#get_location", function(){
            var coords = my_location();
            //history.pushState(null, null, "test.html");
            return false;
        })


        // открываем окно добавления местности
        var allow_add_marker = false;
        $(document).on("click", "#add_location", function(){
            if(allow_add_marker === false){
                $("#map").addClass("add_marker");
                $("#info_help").text("Укажите место на карте").slideDown(300);
                allow_add_marker = true;
            } else{
                $("#info_help").text("Вы уже добавили маркер!").slideDown(300);
            }
            return false;
        })

        // добавляем маркер
        google.maps.event.addListener(map, 'click', function(event) {
            if(allow_add_marker === true){
                placeMarker(event.latLng);
                $("#map").removeClass("add_marker");
            }
            allow_add_marker = false;
        });

        var markers = [];

        // добавляем маркер
        function placeMarker(location, m_id = false) {

            if(m_id ===false) unique_id = "loc_" + new Date().getTime();
            else unique_id = m_id;

            var marker = new google.maps.Marker({
                position: location,
                map: map,
                icon: '/engine/skins/kylshop/img/marker.png?v=0.1',
                animation: google.maps.Animation.DROP,
                draggable: true,
            });
            marker.set("id", unique_id);

            markers.push(marker);

            // удаление маркера
            $(document).on("click", ".remove_marker", function(){
                var mark_id = $(this).parent().attr("id");
                $(this).parent().remove();
                for (var i = 0; i < markers.length; i++) {
                    if (markers[i].id == mark_id) {
                        markers[i].setMap(null);
                        markers.splice(i, 1);
                    }
                }
                return false;
            })

            //var k = marker.get("id", "new_marker").remove();
            //console.log(k);

            $("#info_help").text("Перетащите маркер в нужное место и нажмите на него");

            marker.addListener('click', function(i, e) {

                marker_id = marker.get("id");
                $(".active_marker_info").removeClass("active_marker_info");

                //marker.setIcon('/engine/skins/kylshop/img/local.svg');

                // если маркер и его настройки уже есть
                if($("#" + marker_id).length > 0){

                    $("#" + marker_id).addClass("active_marker_info").find('input[type="text"]:first').focus();
                    return false;

                } else{ // если нет ещё инфо маркера

                    $(".markers_delivery").append('<div class="one_marker" id="'+marker_id+'">\n' +
                        '<input type="hidden" name="marker_id[]" value="'+marker_id+'">' +
                        '<input type="hidden" name="marker_coords[]" value="'+marker.getPosition().lat() + "," + marker.getPosition().lng()+'">' +
                        '<input type="text" name="marker_title[]" autocomplete="off" class="form-control" placeholder="Название места">\n' +
                        '<textarea name="marker_description[]" class="form-control scroll" rows="5" placeholder="Опишите место"></textarea>\n' +
                        '<a href="#" class="fa fa-remove remove_marker" title="Удалить маркер"></a>\n' +
                        '</div>');

                    $("#" + marker_id + ":last").addClass("active_marker_info").find('input[type="text"]:first').focus();
                }

                $("#info_help").slideUp(300);
            });


            // при перетаскивании, меняем координаты маркера
            marker.addListener('drag', function(i, e) {
                marker_id = marker.get("id");
                $(".active_marker_info").removeClass("active_marker_info");
                $("#" + marker_id).addClass("active_marker_info").find('input[type="text"]:first').focus();
                $("#" + marker_id).find('[name="marker_coords[]"]').val(marker.getPosition().lat() + "," + marker.getPosition().lng());
                return false;
            });

        }


        // выводим существующие маркеры
        $(".one_marker").each(function(){
            marker_id = $(this).attr("id");
            local = $(this).find('[name="marker_coords[]"]').val().split(",");
            var myPosition = {
                lat: parseFloat(local[0]),
                lng: parseFloat(local[1])
            };
            placeMarker(myPosition, marker_id);
        })

        // ыводим маркер в центр при клике на настройки маркера
        $(document).on("click", ".one_marker", function(){
            var local = $(this).find('input[type="hidden"]:last').val().split(",");
            $(".active_marker_info").removeClass("active_marker_info");
            $(this).addClass("active_marker_info");

            var myPosition = {
                lat: parseFloat(local[0]),
                lng: parseFloat(local[1])
            };

            map.panTo(myPosition);
        })


        // устанавливем положение карты
        $("#save_delivery").hover(function(){
            $("#delivery_mapInfo").val(JSON.stringify(getMapInfo()));
        })
    }


    $(document).on("click", "#add_method", function(){
        $(".method_row").append('<div class="row">\n' +
            '<div class="col-lg-4 col-md-6">\n' +
                '<label>Наименование</label>\n' +
                '<input type="text" name="method_name[]" class="form-control" autocomplete="off">\n' +
            '</div>\n' +
            '<div class="col-lg-4 col-md-6">\n' +
                '<label>Цена доставки</label>\n' +
                '<input type="text" name="method_price[]" class="form-control" autocomplete="off">\n' +
            '</div>\n' +
            '<div class="col-lg-4 col-md-6">\n' +
                '<label>Максимальная цена</label>\n' +
                '<input type="text" name="method_max_price[]" class="form-control" autocomplete="off">\n' +
            '</div>\n' +
            '<a href="#" class="fa fa-times delete_order del_method"></a>\n' +
        '</div>');
        return false;
    })

    $(document).on("click", "#add_addon", function(){
        $(".addon_row").append('<div class="row">\n' +
            '<div class="col-lg-4 col-md-6">\n' +
                '<label>Наименование</label>\n' +
                '<input type="text" name="addon_name[]" class="form-control" autocomplete="off">\n' +
            '</div>\n' +
            '<div class="col-lg-3 col-md-5">\n' +
                '<label>Цена товара</label>\n' +
                '<input type="text" name="addon_price[]" class="form-control" autocomplete="off">\n' +
            '</div>\n' +
            '<div class="col-lg-5 col-md-7">\n' +
                '<label>Ссылка на изображение</label>\n' +
                '<input type="text" name="addon_image[]" class="form-control" autocomplete="off">\n' +
            '</div>\n' +
            '<a href="#" class="fa fa-times delete_order del_addon"></a>\n' +
        '</div>');
        return false;
    })

    $(document).on("click", "#add_sale", function(){
        $(".sale_row").append('<div class="row">\n' +
            '<div class="col-lg-4 col-md-6">\n' +
                '<label>Если сумма заказа больше чем:</label>\n' +
                '<input type="text" name="sale_price[]" class="form-control" placeholder="только цифры" autocomplete="off">\n' +
            '</div>\n' +
            '<div class="col-lg-3 col-md-5">\n' +
                '<label>отнимать N % от общей суммы</label>\n' +
                '<input type="text" name="sale_percent[]" class="form-control" placeholder="только цифры" autocomplete="off">\n' +
            '</div>\n' +
            '<a href="#" class="fa fa-times delete_order del_sale"></a>\n' +
        '</div>');
        return false;
    })

    $(document).on("click", ".del_method, .del_addon, .del_sale", function(){
        $(this).parent().remove();
        return false;
    })

    $(document).on("click", "#add_status", function(){
        $(".statuses_row").append('<div class="row">\n' +
                '<div class="col-lg-2 col-md-2">\n' +
                    '<label>Название</label>\n' +
                    '<input type="text" name="status[name][]" class="form-control" autocomplete="off">\n' +
                '</div>\n' +
                '<div class="col-lg-9 col-md-9">\n' +
                    '<label>Шаблон email уведомления</label>\n' +
                    '<textarea name="status[email][]" class="form-control" rows="5"></textarea>\n' +
                '</div>\n' +
                '<div class="col-lg-1 col-md-1">\n' +
                    '<a href="#" class="fa fa-times delete_order del_status"></a>\n' +
                '</div>\n' +
            '</div>');
        return false;
    })

    $(document).on("click", ".del_status", function(){
        $(this).parent().parent().remove();
        return false;
    })

    // копирование ссылок на файлы
    $(document).on("click", ".copy_code", function(){
        $(this).prev().select();
        document.execCommand("Copy");
        $(this).after('<span class="copied">Скопировано!</span>');
        return false;
    })

    // удаление кода
    $(document).on("click", ".delete_code", function(){

        let this_ = $(this);
        let code_id = $(this).attr('data-id');
        
        $.confirm('Точно хотите удалить?', function(e){
            if(e === true){

                $.ajax({
                    type: 'POST',
                    url: window.location.href,
                    data: {
                        "delete_code": code_id
                    },
                    dataType: 'text',
                    success: function(data){
                        if(data == 'ok') this_.parents('tr').remove();
                    }, error: function(data){ console.log(data); }
                });
            }
        });
        
        return false;
    })

    // копирование ссылок на файлы
    $(document).on("change", "#select_code_edit", function(){
        let check = $(".code_edit").prop("checked");
        if(check) $(".code_edit").prop("checked", false);
        else $(".code_edit").prop("checked", true);
        return false;
    })

    // открытие хелпера
    $(document).on("click", ".open_helper", function(){
        $(this).stop(true, true).next().slideToggle(300);
        return false;
    })


    $(document).on("click", ".edit_code", function(){

        let id = $(this).attr("data-id");
        let currency = $(this).attr("data-currency");
        let status = $(this).attr("data-status");
        let code = $("#code_"+id).val();
        let comment = $("#code_"+id).next().next().text();
        let sale = $(this).parents("tr").find("td:eq(1) b").text().replace(' '+currency, '');
        let date = $(this).parents("tr").find("td:eq(2) .date").text();
        let type = $(this).parents("tr").find(".type_1").length;

        $("#ks_content .nav-tabs .active").removeClass('active');
        $("#ks_content .nav-tabs li:last").addClass('active');
        $("#list_codes").removeClass('active');
        $("#add_codes").addClass('active');

        $('[name="promo_code"]').val(code);
        $('[name="promo_sale"]').val(sale);
        $('[name="promo_term"]').val(date);
        $('[name="promo_count"]').attr("disabled", "disabled");
        $('[name="promo_comment"]').val(comment);
        $(".status_").show();
        $('[name="status"] option:contains("'+status+'")').attr('selected', 'true');
        if(type == 1) $('[name="type"]').attr("checked", "checked");
        else $('[name="type"]').removeAttr("checked");
        $('[name="edit"]').remove();
        $('[type="submit"]').before('<input type="hidden" name="edit" value="'+id+'">');
        $('[type="submit"]').text('Редактировать');

        return false;
    })

    $('[data-selected]').each(function(){
        let this_ = $(this);
        let catsId = $(this).attr('data-selected');
        if(catsId != ''){

            catsId = catsId.split(",");
            catsId.forEach(function(item, i, arr) {
                this_.find('option[value="'+item+'"]').attr("selected", "selected");
            });
        }
    })


    // поиск
    let timer = null;
    $(document).on('keyup', '.search_orders', function() {
        let searchVal = $(this).val();

        if(searchVal.length >= 2){
            if(timer) clearTimeout(timer);
            timer = setTimeout(function(){
                timer = null;
                $.ajax({
                    type: 'POST',
                    url: "?mod=kylshop&search="+searchVal,
                    data: {
                        "search": searchVal
                    },
                    dataType: 'text',
                    success: function(data){
                        history.pushState(null, null, "?mod=kylshop&search="+searchVal);
                        $("#orders").replaceWith(data);
                    },
                    error: function(data){
                        console.log(data);
                    }
                });
            }, 500);
        }
        return false;
    })

    // сохранение комментария к заказу
    $(document).on('keyup', '#order_comment', function() {

        let order_comment = $(this).val();

        if(timer) clearTimeout(timer);
        timer = setTimeout(function(){
            timer = null;
            $.ajax({
                type: 'POST',
                url: window.location.href,
                data: {
                    "order_comment": order_comment
                },
                dataType: 'text',
                success: function(data){
                    console.log(data);
                },
                error: function(data){
                    console.log(data);
                }
            });
        }, 500);
        return false;
    })

})