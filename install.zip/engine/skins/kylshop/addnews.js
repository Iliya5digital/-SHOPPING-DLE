$(function(){

    // берем название товара из названия новости
    $(document).on("click", "#source_title", function(){
        $("#ks_title").val($("#title").val());
        return false;
    })

    // включаем выключаем товар
    $(document).on("change", "#ks_power", function(){
        
        var power = $(this).prop("checked");
        
        if(power === true) $(".is_goods").stop(true, true).slideDown(300);
        else $(".is_goods").stop(true, true).slideUp(300);

        return false;
    })

    // открытие настроек кол-во товаров
    $("#ks_count_goods").change(function(){
        if($(this).prop("checked") === true) $("#count_goods").stop(true, true).slideDown(300);
        else $("#count_goods").stop(true, true).slideUp(300);
    })

    // открытие фильтра
    if($("#ks_filter_power").prop("checked") === true) $("#filter").stop(true, true).slideDown(300);
    $("#ks_filter_power").change(function(){
        if($(this).prop("checked") === true) $("#filter").stop(true, true).slideDown(300);
        else $("#filter").stop(true, true).slideUp(300);
    })

    $(document).on("change", ".check_filter", function(){
        if($(this).prop("checked") === true){
            $(this).parents(".checkbox").find(".filter_price").show();
        } else $(this).parents(".checkbox").find(".filter_price").fadeOut();
    })

    // добавление и удаление поля для похожих товаров
    $(document).on("click", ".add_related", function(){
        var code = $(this).parent().html();
        $(this).parent().after('<div class="related_title">'+code+'</div>');
        $(this).parent().next().find("input").val("").focus();
        return false;
    })
    $(document).on("click", ".remove_related, .remove_addon, .remove_group, .remove_variant", function(){
        $(this).parent().remove();
        return false;
    })

    var timer = null;
    $(document).on("keyup", '[name="ks_related[]"]', function(){
        var this_ = $(this);
        var word = $(this).val();
        this_.parent().find("ul").remove();
        if (timer) {
            clearTimeout(timer);
        }
        timer = setTimeout(function(){
            timer = null;
            // отправляем ajax запрос
            $.ajax({
                type: 'POST',
                url: "/engine/ajax/controller.php?mod=kylshop_search_related_goods",
                data: {
                    "search_news": word
                },
                dataType: 'text',
                success: function(data){
                    this_.parent().append(data);
                },
                error: function(data){
                    console.log(data);
                }
            });
        }, 700);
    });

    // устанавливаем выбранную новость
    $(document).on("click", ".related_title ul li a", function(){
        var id = $(this).attr("href");
        var title = $(this).text();
        $(this).parent().parent().parent().find('[name="ks_related[]"]').val(title);
        $(this).parent().parent().parent().find("input.related_id").val(id);
        $(".related_title ul").remove();
        return false;
    })

    // добавление 1+1
    $(document).on("click", ".add_one_plus_one", function(){

        let count_box = $('.one_plus_one > div').length;
        count_box++;
        
        $(".one_plus_one").append('<div>\n' +
            'с: <input type="text" name="one_plus_one['+count_box+'][]" class="form-control time_select" style="width: 50px;">\n &nbsp;&nbsp;&nbsp;&nbsp;' +
            'до: <input type="text" name="one_plus_one['+count_box+'][]" class="form-control time_select" style="width: 50px;">\n' +
            '<a href="#" class="fa fa-remove remove_one_plus_one"></a>\n' +
            '</div>');
        return false;
    })

    // выбор времени
    $(document).on("click", ".time_select", function(){
        $(".time_selected").remove();
        let time_select = '<div class="time_selected">\n' +
            '<span>00:00</span>\n' +
            '<span>00:30</span>\n' +
            '<span>01:00</span>\n' +
            '<span>01:30</span>\n' +
            '<span>02:00</span>\n' +
            '<span>02:30</span>\n' +
            '<span>03:00</span>\n' +
            '<span>03:30</span>\n' +
            '<span>04:00</span>\n' +
            '<span>04:30</span>\n' +
            '<span>05:00</span>\n' +
            '<span>05:30</span>\n' +
            '<span>06:00</span>\n' +
            '<span>06:30</span>\n' +
            '<span>07:00</span>\n' +
            '<span>07:30</span>\n' +
            '<span>08:00</span>\n' +
            '<span>08:30</span>\n' +
            '<span>09:00</span>\n' +
            '<span>09:30</span>\n' +
            '<span>10:00</span>\n' +
            '<span>10:30</span>\n' +
            '<span>11:00</span>\n' +
            '<span>11:30</span>\n' +
            '<span>12:00</span>\n' +
            '<span>12:30</span>\n' +
            '<span>13:00</span>\n' +
            '<span>13:30</span>\n' +
            '<span>14:00</span>\n' +
            '<span>14:30</span>\n' +
            '<span>15:00</span>\n' +
            '<span>15:30</span>\n' +
            '<span>16:00</span>\n' +
            '<span>16:30</span>\n' +
            '<span>17:00</span>\n' +
            '<span>17:30</span>\n' +
            '<span>18:00</span>\n' +
            '<span>18:30</span>\n' +
            '<span>19:00</span>\n' +
            '<span>19:30</span>\n' +
            '<span>20:00</span>\n' +
            '<span>20:30</span>\n' +
            '<span>21:00</span>\n' +
            '<span>21:30</span>\n' +
            '<span>22:00</span>\n' +
            '<span>22:30</span>\n' +
            '<span>23:00</span>\n' +
            '<span>23:30</span>\n' +
            '</div>';

        if($(this).parent().hasClass("pr")) $(this).after(time_select);
        else $(this).wrapAll('<span class="pr" style="width: 50px;">').after(time_select);

        return false;
    })

    // установка времени
    $(document).on("click", ".time_selected span", function(){
        let time = $(this).text();
        $(this).parent().prev().val(time);
        $(".time_selected").remove();
        return false;
    })

    // удаление 1+1
    $(document).on("click", ".remove_one_plus_one", function(){
        $(this).parent().remove();
        return false;
    })

    // добавление дополнительных товаров
    $(document).on("click", ".add_addon", function(){

        let addon_name = $("#addon_goods option:selected").val();
        let addon_price = $("#addon_goods option:selected").data("price");
        let addon_image = $("#addon_goods option:selected").data("image");

        $("#addons").append(
            '<div class="row">\n' +
            '<div class="col-sm-4">\n' +
            '<input type="text" name="addon[name][]" class="form-control" value="'+addon_name+'">\n' +
            '</div>\n' +
            '<div class="col-sm-3">\n' +
            '<input type="text" name="addon[price][]" class="form-control" value="'+addon_price+'">\n' +
            '</div>\n' +
            '<div class="col-sm-5">\n' +
            '<input type="text" name="addon[image][]" class="form-control" value="'+addon_image+'">\n' +
            '</div>\n' +
            '</div>'
        );
        console.log(addon_goods);
        return false;
    })

    // какие категории выбраны
    $("#category option:selected").each(function(){
        let catId = $(this).val();
        $(".filter_cat_"+catId).show();
    })

    // какие категории выбраны dynamic
    $(document).on("click", '[href="#shop"]', function(){
        $(".filter_cat").hide();
        $("#category option:selected").each(function(){
            let catId = $(this).val();
            $(".filter_cat_"+catId).show();
        })
    })

    // какие категории выбраны dynamic
    $(document).on("click", '.add_price', function(){
        $(".group_prices").append('<div class="fx">\n' +
            '    <div>\n' +
            '        <input type="text" class="form-control position-left" style="width: 155px;" name="ks_group_price[]" placeholder="Цена для группы" maxlength="50">\n' +
            '    </div>\n' +
            '    <div>\n' +
            '        <select name="ks_group[]" class="uniform">\n' +
            '            <option value="">-- Выберете группу --</option>\n' +
            groups +
            '        </select>\n' +
            '    </div>\n' +
            '    <a href="#" class="fa fa-remove c_red remove_group"></a>\n' +
            '</div>');
        $('select.uniform').selectpicker();
        return false;
    })

    // другие цены
    $(document).on("click", '.add_variant', function(){
        $(".variant_prices").append('<div class="fx">\n' +
            '    <div>\n' +
            '        <input type="text" class="form-control position-left" style="width: 155px;" name="ks_variant_price[]" placeholder="Новая цена" maxlength="50">\n' +
            '    </div>\n' +
            '    <div>\n' +
            '        <input type="text" class="form-control position-left" style="width: 155px;" name="ks_variant_count[]" placeholder="Если кол-во >= чем" maxlength="50">\n' +
            '    </div>\n' +
            '    <a href="#" class="fa fa-remove c_red remove_variant"></a>\n' +
            '</div>');
        return false;
    })

    function FileUploadProgress(e){
        if(e.lengthComputable){
            let p = (e.loaded * 100)/e.total;
            p = parseInt(p);
            console.log(p+"%");
            $('.FileUploadProgress').stop(true, true).fadeIn(100);
            $('.FileUploadProgress span').css("width", p + '%');
            $('.FileUploadProgress p').html( 'Загрузка - ' + p + '%');
            if(p >= 100){
                $('.FileUploadProgress').stop(true, true).fadeOut(700);
                $('.FileUploadProgress p').html('');
            }
        }
        return true;
    }


    // загрузка картинок в фильтр
    $(document).on("change", ".upload_inp", function(){

        let data = new FormData();
        let id = $(this).attr("data-id");
        let inputFiles = $('[name="filter_img_'+id+'[]"]').val();

        //data.append("title", $('[name="video_title"]').val());
        //data.append("files", $(this).prop('files')[0]);

        $.each($(this)[0].files, function(i, file) {
            data.append("file[]", file);
        });

        $.ajax({
            url: "?mod=kylshop&act=upload_files",
            type: "POST",
            data: data,
            processData: false,
            contentType: false,
            success: function(data){

                if(data){
                    if(inputFiles != '') inputFiles += "=";

                    $('[name="filter_img_'+id+'[]"]').val(inputFiles+data);
                    data = data.split("=");
                    data.forEach(function(e){
                        $('[name="filter_img_'+id+'[]"]').prev().append('<div class="f_img">\n' +
                            '<img src="'+e+'" alt="">\n' +
                            '<input type="text" class="form-control img_price" name="filter_priceimg_'+id+'[]" placeholder="добавить к цене">\n' +
                            '<a href="#" class="delete_img"></a>\n' +
                            '</div>');
                    })
                }
            },
            xhr: function() {
                var myXhr = $.ajaxSettings.xhr();
                if(myXhr.upload){
                    myXhr.upload.addEventListener('progress', FileUploadProgress, false);
                }
                return myXhr;
            },
            error: function( jqXHR, textStatus, errorThrown ){
                console.log('ОШИБКИ AJAX запроса: ' + textStatus );
            }
        });

        return false;
    })

    $(document).on("click", ".delete_img", function(){
        let this_ = $(this);
        let thisImages = $(this).parents(".f_images");
        let imgSrc = $(this).prev().prev().attr("src");
        $.ajax({
            type: 'POST',
            url: "?mod=kylshop&act=upload_files",
            data: {
                "delete_img": imgSrc
            },
            dataType: 'text',
            success: function(data){
                if(data == "ok"){
                    this_.parent().remove();
                    let resultImages = '';
                    thisImages.find("img").each(function () {
                        resultImages += $(this).attr("src")+"=";
                    })
                    resultImages = resultImages.slice(0, -1);
                    thisImages.next().val(resultImages);
                }
            },
            error: function(data){
                console.log(data);
            }
        });
        return false;
    })

    $(".colorPicker").spectrum({
        move: function(color) {
            let thisId = /filter_color_([0-9]+)\[/g.exec($(this).attr("name"));
            $('#c_'+thisId[1]).css("background", color.toRgbString());
        }
    });

    $(document).on("click", ".add_color", function(){

        let date = new Date();
        let Milliseconds = date.getTime();

        $(".f_colors").append('<div class="box_color">\n' +
            '    <div class="colorHelp" id="c_'+Milliseconds+'"></div>\n' +
            '         <input type="text" name="filter_color_'+Milliseconds+'[val]" class="form-control colorPicker" placeholder="цвет">\n' +
            '         <input type="text" name="filter_color_'+Milliseconds+'[price]" class="form-control" placeholder="+ цена">\n' +
            '</div>');
        $(".colorPicker").spectrum({
            move: function(color) {
                let thisId = /filter_color_([0-9]+)\[/g.exec($(this).attr("name"));
                $('#c_'+thisId[1]).css("background", color.toRgbString());
            }
        });
        return false;
    })

})