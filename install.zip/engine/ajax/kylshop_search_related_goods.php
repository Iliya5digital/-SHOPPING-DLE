<?php
/*
=====================================================
 DataLife Engine - by SoftNews Media Group
-----------------------------------------------------
 http://dle-news.ru/
-----------------------------------------------------
 Copyright (c) 2004-2018 SoftNews Media Group
=====================================================
 This code is protected by copyright
=====================================================
 File: allvotes.php
-----------------------------------------------------
 Use: votes
=====================================================
*/

if(!defined('DATALIFEENGINE')) {
    header( "HTTP/1.1 403 Forbidden" );
    header ( 'Location: ../../../' );
    die( "Hacking attempt!" );
}


// поиск новостей для похожих товаров
if(!empty($_POST["search_news"])){

    $word = trim(htmlspecialchars(strip_tags($_POST["search_news"])));

    $rows = $db->super_query("SELECT id, title FROM " . PREFIX . "_post  WHERE title LIKE '%{$word}%' ORDER by date DESC LIMIT 15", true);

    $result = '<ul><li><p class="error">Новость не найдена!</p></li></ul>';

    if(!empty($rows)){

        $result = '<ul>';
        foreach ($rows as $row) {
            $result .= '<li><a href="'.$row["id"].'">'.$row["title"].'</a></li>';
        }
        $result .= '</ul>';
    }

    echo $result;

    exit;
}